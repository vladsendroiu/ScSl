package vlad.xtextt.smartCar.scsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import vlad.xtextt.smartCar.scsl.services.ScSlGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalScSlParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Mission'", "'Achievements'", "'Drive_speed'", "'Turn_speed'", "'Sensor_distance_front'", "'Sensor_distance_right'", "'Sensor_color_left'", "'Sensor_color_right'", "'Motor_left_pins'", "'Motor_right_pins'", "'Tasks'", "'Trigger_Pin'", "'Echo_Pin'", "'Pin'", "'Input1_pin'", "'Input2_pin'", "'Task'", "'priority'", "'Goal'", "'Start_if'", "'Stop_when'", "'until'", "'Drive'", "'Turn'", "'Wait'", "'Mark'", "'Clear'", "'Show'", "'Play'", "'message'", "'note'", "'for'", "'ms'", "'achievement'", "'color'", "'front'", "'right'", "'time'", "'memory'", "'forward'", "'back'", "'left'", "'close'", "'none'", "'black'", "'white'", "'any'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalScSlParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalScSlParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalScSlParser.tokenNames; }
    public String getGrammarFileName() { return "InternalScSl.g"; }



     	private ScSlGrammarAccess grammarAccess;

        public InternalScSlParser(TokenStream input, ScSlGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Mission";
       	}

       	@Override
       	protected ScSlGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleMission"
    // InternalScSl.g:65:1: entryRuleMission returns [EObject current=null] : iv_ruleMission= ruleMission EOF ;
    public final EObject entryRuleMission() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMission = null;


        try {
            // InternalScSl.g:65:48: (iv_ruleMission= ruleMission EOF )
            // InternalScSl.g:66:2: iv_ruleMission= ruleMission EOF
            {
             newCompositeNode(grammarAccess.getMissionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMission=ruleMission();

            state._fsp--;

             current =iv_ruleMission; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMission"


    // $ANTLR start "ruleMission"
    // InternalScSl.g:72:1: ruleMission returns [EObject current=null] : (otherlv_0= 'Mission' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'Achievements' ( (lv_achievements_3_0= RULE_INT ) )* )? ( (lv_goals_4_0= ruleGoal ) )+ (otherlv_5= 'Drive_speed' ( (lv_drive_speed_6_0= ruleSpeed ) ) )? (otherlv_7= 'Turn_speed' ( (lv_turn_speed_8_0= ruleSpeed ) ) )? (otherlv_9= 'Sensor_distance_front' ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) ) )? (otherlv_11= 'Sensor_distance_right' ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) ) )? (otherlv_13= 'Sensor_color_left' ( (lv_sensor_color_left_14_0= ruleColor_Pin ) ) )? (otherlv_15= 'Sensor_color_right' ( (lv_sensor_color_right_16_0= ruleColor_Pin ) ) )? (otherlv_17= 'Motor_left_pins' ( (lv_motor_left_18_0= ruleMotor_Pins ) ) )? (otherlv_19= 'Motor_right_pins' ( (lv_motor_right_20_0= ruleMotor_Pins ) ) )? otherlv_21= 'Tasks' ( (lv_tasks_22_0= ruleTask ) )+ ) ;
    public final EObject ruleMission() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_achievements_3_0=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        EObject lv_goals_4_0 = null;

        EObject lv_drive_speed_6_0 = null;

        EObject lv_turn_speed_8_0 = null;

        EObject lv_sensor_dist_front_10_0 = null;

        EObject lv_sensor_dist_right_12_0 = null;

        EObject lv_sensor_color_left_14_0 = null;

        EObject lv_sensor_color_right_16_0 = null;

        EObject lv_motor_left_18_0 = null;

        EObject lv_motor_right_20_0 = null;

        EObject lv_tasks_22_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:78:2: ( (otherlv_0= 'Mission' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'Achievements' ( (lv_achievements_3_0= RULE_INT ) )* )? ( (lv_goals_4_0= ruleGoal ) )+ (otherlv_5= 'Drive_speed' ( (lv_drive_speed_6_0= ruleSpeed ) ) )? (otherlv_7= 'Turn_speed' ( (lv_turn_speed_8_0= ruleSpeed ) ) )? (otherlv_9= 'Sensor_distance_front' ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) ) )? (otherlv_11= 'Sensor_distance_right' ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) ) )? (otherlv_13= 'Sensor_color_left' ( (lv_sensor_color_left_14_0= ruleColor_Pin ) ) )? (otherlv_15= 'Sensor_color_right' ( (lv_sensor_color_right_16_0= ruleColor_Pin ) ) )? (otherlv_17= 'Motor_left_pins' ( (lv_motor_left_18_0= ruleMotor_Pins ) ) )? (otherlv_19= 'Motor_right_pins' ( (lv_motor_right_20_0= ruleMotor_Pins ) ) )? otherlv_21= 'Tasks' ( (lv_tasks_22_0= ruleTask ) )+ ) )
            // InternalScSl.g:79:2: (otherlv_0= 'Mission' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'Achievements' ( (lv_achievements_3_0= RULE_INT ) )* )? ( (lv_goals_4_0= ruleGoal ) )+ (otherlv_5= 'Drive_speed' ( (lv_drive_speed_6_0= ruleSpeed ) ) )? (otherlv_7= 'Turn_speed' ( (lv_turn_speed_8_0= ruleSpeed ) ) )? (otherlv_9= 'Sensor_distance_front' ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) ) )? (otherlv_11= 'Sensor_distance_right' ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) ) )? (otherlv_13= 'Sensor_color_left' ( (lv_sensor_color_left_14_0= ruleColor_Pin ) ) )? (otherlv_15= 'Sensor_color_right' ( (lv_sensor_color_right_16_0= ruleColor_Pin ) ) )? (otherlv_17= 'Motor_left_pins' ( (lv_motor_left_18_0= ruleMotor_Pins ) ) )? (otherlv_19= 'Motor_right_pins' ( (lv_motor_right_20_0= ruleMotor_Pins ) ) )? otherlv_21= 'Tasks' ( (lv_tasks_22_0= ruleTask ) )+ )
            {
            // InternalScSl.g:79:2: (otherlv_0= 'Mission' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'Achievements' ( (lv_achievements_3_0= RULE_INT ) )* )? ( (lv_goals_4_0= ruleGoal ) )+ (otherlv_5= 'Drive_speed' ( (lv_drive_speed_6_0= ruleSpeed ) ) )? (otherlv_7= 'Turn_speed' ( (lv_turn_speed_8_0= ruleSpeed ) ) )? (otherlv_9= 'Sensor_distance_front' ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) ) )? (otherlv_11= 'Sensor_distance_right' ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) ) )? (otherlv_13= 'Sensor_color_left' ( (lv_sensor_color_left_14_0= ruleColor_Pin ) ) )? (otherlv_15= 'Sensor_color_right' ( (lv_sensor_color_right_16_0= ruleColor_Pin ) ) )? (otherlv_17= 'Motor_left_pins' ( (lv_motor_left_18_0= ruleMotor_Pins ) ) )? (otherlv_19= 'Motor_right_pins' ( (lv_motor_right_20_0= ruleMotor_Pins ) ) )? otherlv_21= 'Tasks' ( (lv_tasks_22_0= ruleTask ) )+ )
            // InternalScSl.g:80:3: otherlv_0= 'Mission' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'Achievements' ( (lv_achievements_3_0= RULE_INT ) )* )? ( (lv_goals_4_0= ruleGoal ) )+ (otherlv_5= 'Drive_speed' ( (lv_drive_speed_6_0= ruleSpeed ) ) )? (otherlv_7= 'Turn_speed' ( (lv_turn_speed_8_0= ruleSpeed ) ) )? (otherlv_9= 'Sensor_distance_front' ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) ) )? (otherlv_11= 'Sensor_distance_right' ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) ) )? (otherlv_13= 'Sensor_color_left' ( (lv_sensor_color_left_14_0= ruleColor_Pin ) ) )? (otherlv_15= 'Sensor_color_right' ( (lv_sensor_color_right_16_0= ruleColor_Pin ) ) )? (otherlv_17= 'Motor_left_pins' ( (lv_motor_left_18_0= ruleMotor_Pins ) ) )? (otherlv_19= 'Motor_right_pins' ( (lv_motor_right_20_0= ruleMotor_Pins ) ) )? otherlv_21= 'Tasks' ( (lv_tasks_22_0= ruleTask ) )+
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getMissionAccess().getMissionKeyword_0());
            		
            // InternalScSl.g:84:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalScSl.g:85:4: (lv_name_1_0= RULE_ID )
            {
            // InternalScSl.g:85:4: (lv_name_1_0= RULE_ID )
            // InternalScSl.g:86:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getMissionAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMissionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalScSl.g:102:3: (otherlv_2= 'Achievements' ( (lv_achievements_3_0= RULE_INT ) )* )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==12) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalScSl.g:103:4: otherlv_2= 'Achievements' ( (lv_achievements_3_0= RULE_INT ) )*
                    {
                    otherlv_2=(Token)match(input,12,FOLLOW_5); 

                    				newLeafNode(otherlv_2, grammarAccess.getMissionAccess().getAchievementsKeyword_2_0());
                    			
                    // InternalScSl.g:107:4: ( (lv_achievements_3_0= RULE_INT ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==RULE_INT) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalScSl.g:108:5: (lv_achievements_3_0= RULE_INT )
                    	    {
                    	    // InternalScSl.g:108:5: (lv_achievements_3_0= RULE_INT )
                    	    // InternalScSl.g:109:6: lv_achievements_3_0= RULE_INT
                    	    {
                    	    lv_achievements_3_0=(Token)match(input,RULE_INT,FOLLOW_5); 

                    	    						newLeafNode(lv_achievements_3_0, grammarAccess.getMissionAccess().getAchievementsINTTerminalRuleCall_2_1_0());
                    	    					

                    	    						if (current==null) {
                    	    							current = createModelElement(grammarAccess.getMissionRule());
                    	    						}
                    	    						addWithLastConsumed(
                    	    							current,
                    	    							"achievements",
                    	    							lv_achievements_3_0,
                    	    							"org.eclipse.xtext.common.Terminals.INT");
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalScSl.g:126:3: ( (lv_goals_4_0= ruleGoal ) )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==29) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalScSl.g:127:4: (lv_goals_4_0= ruleGoal )
            	    {
            	    // InternalScSl.g:127:4: (lv_goals_4_0= ruleGoal )
            	    // InternalScSl.g:128:5: lv_goals_4_0= ruleGoal
            	    {

            	    					newCompositeNode(grammarAccess.getMissionAccess().getGoalsGoalParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_goals_4_0=ruleGoal();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getMissionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"goals",
            	    						lv_goals_4_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.Goal");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);

            // InternalScSl.g:145:3: (otherlv_5= 'Drive_speed' ( (lv_drive_speed_6_0= ruleSpeed ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==13) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalScSl.g:146:4: otherlv_5= 'Drive_speed' ( (lv_drive_speed_6_0= ruleSpeed ) )
                    {
                    otherlv_5=(Token)match(input,13,FOLLOW_7); 

                    				newLeafNode(otherlv_5, grammarAccess.getMissionAccess().getDrive_speedKeyword_4_0());
                    			
                    // InternalScSl.g:150:4: ( (lv_drive_speed_6_0= ruleSpeed ) )
                    // InternalScSl.g:151:5: (lv_drive_speed_6_0= ruleSpeed )
                    {
                    // InternalScSl.g:151:5: (lv_drive_speed_6_0= ruleSpeed )
                    // InternalScSl.g:152:6: lv_drive_speed_6_0= ruleSpeed
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getDrive_speedSpeedParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_drive_speed_6_0=ruleSpeed();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"drive_speed",
                    							lv_drive_speed_6_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Speed");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalScSl.g:170:3: (otherlv_7= 'Turn_speed' ( (lv_turn_speed_8_0= ruleSpeed ) ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==14) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalScSl.g:171:4: otherlv_7= 'Turn_speed' ( (lv_turn_speed_8_0= ruleSpeed ) )
                    {
                    otherlv_7=(Token)match(input,14,FOLLOW_7); 

                    				newLeafNode(otherlv_7, grammarAccess.getMissionAccess().getTurn_speedKeyword_5_0());
                    			
                    // InternalScSl.g:175:4: ( (lv_turn_speed_8_0= ruleSpeed ) )
                    // InternalScSl.g:176:5: (lv_turn_speed_8_0= ruleSpeed )
                    {
                    // InternalScSl.g:176:5: (lv_turn_speed_8_0= ruleSpeed )
                    // InternalScSl.g:177:6: lv_turn_speed_8_0= ruleSpeed
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getTurn_speedSpeedParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_turn_speed_8_0=ruleSpeed();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"turn_speed",
                    							lv_turn_speed_8_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Speed");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalScSl.g:195:3: (otherlv_9= 'Sensor_distance_front' ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==15) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalScSl.g:196:4: otherlv_9= 'Sensor_distance_front' ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) )
                    {
                    otherlv_9=(Token)match(input,15,FOLLOW_10); 

                    				newLeafNode(otherlv_9, grammarAccess.getMissionAccess().getSensor_distance_frontKeyword_6_0());
                    			
                    // InternalScSl.g:200:4: ( (lv_sensor_dist_front_10_0= ruleDistance_Pins ) )
                    // InternalScSl.g:201:5: (lv_sensor_dist_front_10_0= ruleDistance_Pins )
                    {
                    // InternalScSl.g:201:5: (lv_sensor_dist_front_10_0= ruleDistance_Pins )
                    // InternalScSl.g:202:6: lv_sensor_dist_front_10_0= ruleDistance_Pins
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getSensor_dist_frontDistance_PinsParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_sensor_dist_front_10_0=ruleDistance_Pins();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"sensor_dist_front",
                    							lv_sensor_dist_front_10_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Distance_Pins");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalScSl.g:220:3: (otherlv_11= 'Sensor_distance_right' ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==16) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalScSl.g:221:4: otherlv_11= 'Sensor_distance_right' ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) )
                    {
                    otherlv_11=(Token)match(input,16,FOLLOW_10); 

                    				newLeafNode(otherlv_11, grammarAccess.getMissionAccess().getSensor_distance_rightKeyword_7_0());
                    			
                    // InternalScSl.g:225:4: ( (lv_sensor_dist_right_12_0= ruleDistance_Pins ) )
                    // InternalScSl.g:226:5: (lv_sensor_dist_right_12_0= ruleDistance_Pins )
                    {
                    // InternalScSl.g:226:5: (lv_sensor_dist_right_12_0= ruleDistance_Pins )
                    // InternalScSl.g:227:6: lv_sensor_dist_right_12_0= ruleDistance_Pins
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getSensor_dist_rightDistance_PinsParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_sensor_dist_right_12_0=ruleDistance_Pins();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"sensor_dist_right",
                    							lv_sensor_dist_right_12_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Distance_Pins");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalScSl.g:245:3: (otherlv_13= 'Sensor_color_left' ( (lv_sensor_color_left_14_0= ruleColor_Pin ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==17) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalScSl.g:246:4: otherlv_13= 'Sensor_color_left' ( (lv_sensor_color_left_14_0= ruleColor_Pin ) )
                    {
                    otherlv_13=(Token)match(input,17,FOLLOW_13); 

                    				newLeafNode(otherlv_13, grammarAccess.getMissionAccess().getSensor_color_leftKeyword_8_0());
                    			
                    // InternalScSl.g:250:4: ( (lv_sensor_color_left_14_0= ruleColor_Pin ) )
                    // InternalScSl.g:251:5: (lv_sensor_color_left_14_0= ruleColor_Pin )
                    {
                    // InternalScSl.g:251:5: (lv_sensor_color_left_14_0= ruleColor_Pin )
                    // InternalScSl.g:252:6: lv_sensor_color_left_14_0= ruleColor_Pin
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getSensor_color_leftColor_PinParserRuleCall_8_1_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_sensor_color_left_14_0=ruleColor_Pin();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"sensor_color_left",
                    							lv_sensor_color_left_14_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Color_Pin");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalScSl.g:270:3: (otherlv_15= 'Sensor_color_right' ( (lv_sensor_color_right_16_0= ruleColor_Pin ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==18) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalScSl.g:271:4: otherlv_15= 'Sensor_color_right' ( (lv_sensor_color_right_16_0= ruleColor_Pin ) )
                    {
                    otherlv_15=(Token)match(input,18,FOLLOW_13); 

                    				newLeafNode(otherlv_15, grammarAccess.getMissionAccess().getSensor_color_rightKeyword_9_0());
                    			
                    // InternalScSl.g:275:4: ( (lv_sensor_color_right_16_0= ruleColor_Pin ) )
                    // InternalScSl.g:276:5: (lv_sensor_color_right_16_0= ruleColor_Pin )
                    {
                    // InternalScSl.g:276:5: (lv_sensor_color_right_16_0= ruleColor_Pin )
                    // InternalScSl.g:277:6: lv_sensor_color_right_16_0= ruleColor_Pin
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getSensor_color_rightColor_PinParserRuleCall_9_1_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_sensor_color_right_16_0=ruleColor_Pin();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"sensor_color_right",
                    							lv_sensor_color_right_16_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Color_Pin");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalScSl.g:295:3: (otherlv_17= 'Motor_left_pins' ( (lv_motor_left_18_0= ruleMotor_Pins ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==19) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalScSl.g:296:4: otherlv_17= 'Motor_left_pins' ( (lv_motor_left_18_0= ruleMotor_Pins ) )
                    {
                    otherlv_17=(Token)match(input,19,FOLLOW_16); 

                    				newLeafNode(otherlv_17, grammarAccess.getMissionAccess().getMotor_left_pinsKeyword_10_0());
                    			
                    // InternalScSl.g:300:4: ( (lv_motor_left_18_0= ruleMotor_Pins ) )
                    // InternalScSl.g:301:5: (lv_motor_left_18_0= ruleMotor_Pins )
                    {
                    // InternalScSl.g:301:5: (lv_motor_left_18_0= ruleMotor_Pins )
                    // InternalScSl.g:302:6: lv_motor_left_18_0= ruleMotor_Pins
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getMotor_leftMotor_PinsParserRuleCall_10_1_0());
                    					
                    pushFollow(FOLLOW_17);
                    lv_motor_left_18_0=ruleMotor_Pins();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"motor_left",
                    							lv_motor_left_18_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Motor_Pins");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalScSl.g:320:3: (otherlv_19= 'Motor_right_pins' ( (lv_motor_right_20_0= ruleMotor_Pins ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==20) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalScSl.g:321:4: otherlv_19= 'Motor_right_pins' ( (lv_motor_right_20_0= ruleMotor_Pins ) )
                    {
                    otherlv_19=(Token)match(input,20,FOLLOW_16); 

                    				newLeafNode(otherlv_19, grammarAccess.getMissionAccess().getMotor_right_pinsKeyword_11_0());
                    			
                    // InternalScSl.g:325:4: ( (lv_motor_right_20_0= ruleMotor_Pins ) )
                    // InternalScSl.g:326:5: (lv_motor_right_20_0= ruleMotor_Pins )
                    {
                    // InternalScSl.g:326:5: (lv_motor_right_20_0= ruleMotor_Pins )
                    // InternalScSl.g:327:6: lv_motor_right_20_0= ruleMotor_Pins
                    {

                    						newCompositeNode(grammarAccess.getMissionAccess().getMotor_rightMotor_PinsParserRuleCall_11_1_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_motor_right_20_0=ruleMotor_Pins();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMissionRule());
                    						}
                    						set(
                    							current,
                    							"motor_right",
                    							lv_motor_right_20_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.Motor_Pins");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_21=(Token)match(input,21,FOLLOW_19); 

            			newLeafNode(otherlv_21, grammarAccess.getMissionAccess().getTasksKeyword_12());
            		
            // InternalScSl.g:349:3: ( (lv_tasks_22_0= ruleTask ) )+
            int cnt12=0;
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==27) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalScSl.g:350:4: (lv_tasks_22_0= ruleTask )
            	    {
            	    // InternalScSl.g:350:4: (lv_tasks_22_0= ruleTask )
            	    // InternalScSl.g:351:5: lv_tasks_22_0= ruleTask
            	    {

            	    					newCompositeNode(grammarAccess.getMissionAccess().getTasksTaskParserRuleCall_13_0());
            	    				
            	    pushFollow(FOLLOW_20);
            	    lv_tasks_22_0=ruleTask();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getMissionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"tasks",
            	    						lv_tasks_22_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.Task");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt12 >= 1 ) break loop12;
                        EarlyExitException eee =
                            new EarlyExitException(12, input);
                        throw eee;
                }
                cnt12++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMission"


    // $ANTLR start "entryRuleSpeed"
    // InternalScSl.g:372:1: entryRuleSpeed returns [EObject current=null] : iv_ruleSpeed= ruleSpeed EOF ;
    public final EObject entryRuleSpeed() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSpeed = null;


        try {
            // InternalScSl.g:372:46: (iv_ruleSpeed= ruleSpeed EOF )
            // InternalScSl.g:373:2: iv_ruleSpeed= ruleSpeed EOF
            {
             newCompositeNode(grammarAccess.getSpeedRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSpeed=ruleSpeed();

            state._fsp--;

             current =iv_ruleSpeed; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSpeed"


    // $ANTLR start "ruleSpeed"
    // InternalScSl.g:379:1: ruleSpeed returns [EObject current=null] : ( (lv_s_0_0= RULE_INT ) ) ;
    public final EObject ruleSpeed() throws RecognitionException {
        EObject current = null;

        Token lv_s_0_0=null;


        	enterRule();

        try {
            // InternalScSl.g:385:2: ( ( (lv_s_0_0= RULE_INT ) ) )
            // InternalScSl.g:386:2: ( (lv_s_0_0= RULE_INT ) )
            {
            // InternalScSl.g:386:2: ( (lv_s_0_0= RULE_INT ) )
            // InternalScSl.g:387:3: (lv_s_0_0= RULE_INT )
            {
            // InternalScSl.g:387:3: (lv_s_0_0= RULE_INT )
            // InternalScSl.g:388:4: lv_s_0_0= RULE_INT
            {
            lv_s_0_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            				newLeafNode(lv_s_0_0, grammarAccess.getSpeedAccess().getSINTTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getSpeedRule());
            				}
            				setWithLastConsumed(
            					current,
            					"s",
            					lv_s_0_0,
            					"org.eclipse.xtext.common.Terminals.INT");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSpeed"


    // $ANTLR start "entryRuleDistance_Pins"
    // InternalScSl.g:407:1: entryRuleDistance_Pins returns [EObject current=null] : iv_ruleDistance_Pins= ruleDistance_Pins EOF ;
    public final EObject entryRuleDistance_Pins() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDistance_Pins = null;


        try {
            // InternalScSl.g:407:54: (iv_ruleDistance_Pins= ruleDistance_Pins EOF )
            // InternalScSl.g:408:2: iv_ruleDistance_Pins= ruleDistance_Pins EOF
            {
             newCompositeNode(grammarAccess.getDistance_PinsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDistance_Pins=ruleDistance_Pins();

            state._fsp--;

             current =iv_ruleDistance_Pins; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDistance_Pins"


    // $ANTLR start "ruleDistance_Pins"
    // InternalScSl.g:414:1: ruleDistance_Pins returns [EObject current=null] : (otherlv_0= 'Trigger_Pin' ( (lv_triggerpin_1_0= rulePind ) ) otherlv_2= 'Echo_Pin' ( (lv_echopin_3_0= rulePind ) ) ) ;
    public final EObject ruleDistance_Pins() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_triggerpin_1_0 = null;

        EObject lv_echopin_3_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:420:2: ( (otherlv_0= 'Trigger_Pin' ( (lv_triggerpin_1_0= rulePind ) ) otherlv_2= 'Echo_Pin' ( (lv_echopin_3_0= rulePind ) ) ) )
            // InternalScSl.g:421:2: (otherlv_0= 'Trigger_Pin' ( (lv_triggerpin_1_0= rulePind ) ) otherlv_2= 'Echo_Pin' ( (lv_echopin_3_0= rulePind ) ) )
            {
            // InternalScSl.g:421:2: (otherlv_0= 'Trigger_Pin' ( (lv_triggerpin_1_0= rulePind ) ) otherlv_2= 'Echo_Pin' ( (lv_echopin_3_0= rulePind ) ) )
            // InternalScSl.g:422:3: otherlv_0= 'Trigger_Pin' ( (lv_triggerpin_1_0= rulePind ) ) otherlv_2= 'Echo_Pin' ( (lv_echopin_3_0= rulePind ) )
            {
            otherlv_0=(Token)match(input,22,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getDistance_PinsAccess().getTrigger_PinKeyword_0());
            		
            // InternalScSl.g:426:3: ( (lv_triggerpin_1_0= rulePind ) )
            // InternalScSl.g:427:4: (lv_triggerpin_1_0= rulePind )
            {
            // InternalScSl.g:427:4: (lv_triggerpin_1_0= rulePind )
            // InternalScSl.g:428:5: lv_triggerpin_1_0= rulePind
            {

            					newCompositeNode(grammarAccess.getDistance_PinsAccess().getTriggerpinPindParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_21);
            lv_triggerpin_1_0=rulePind();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDistance_PinsRule());
            					}
            					set(
            						current,
            						"triggerpin",
            						lv_triggerpin_1_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.Pind");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_7); 

            			newLeafNode(otherlv_2, grammarAccess.getDistance_PinsAccess().getEcho_PinKeyword_2());
            		
            // InternalScSl.g:449:3: ( (lv_echopin_3_0= rulePind ) )
            // InternalScSl.g:450:4: (lv_echopin_3_0= rulePind )
            {
            // InternalScSl.g:450:4: (lv_echopin_3_0= rulePind )
            // InternalScSl.g:451:5: lv_echopin_3_0= rulePind
            {

            					newCompositeNode(grammarAccess.getDistance_PinsAccess().getEchopinPindParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_echopin_3_0=rulePind();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDistance_PinsRule());
            					}
            					set(
            						current,
            						"echopin",
            						lv_echopin_3_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.Pind");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDistance_Pins"


    // $ANTLR start "entryRuleColor_Pin"
    // InternalScSl.g:472:1: entryRuleColor_Pin returns [EObject current=null] : iv_ruleColor_Pin= ruleColor_Pin EOF ;
    public final EObject entryRuleColor_Pin() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleColor_Pin = null;


        try {
            // InternalScSl.g:472:50: (iv_ruleColor_Pin= ruleColor_Pin EOF )
            // InternalScSl.g:473:2: iv_ruleColor_Pin= ruleColor_Pin EOF
            {
             newCompositeNode(grammarAccess.getColor_PinRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleColor_Pin=ruleColor_Pin();

            state._fsp--;

             current =iv_ruleColor_Pin; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleColor_Pin"


    // $ANTLR start "ruleColor_Pin"
    // InternalScSl.g:479:1: ruleColor_Pin returns [EObject current=null] : (otherlv_0= 'Pin' ( (lv_pin_1_0= RULE_STRING ) ) ) ;
    public final EObject ruleColor_Pin() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_pin_1_0=null;


        	enterRule();

        try {
            // InternalScSl.g:485:2: ( (otherlv_0= 'Pin' ( (lv_pin_1_0= RULE_STRING ) ) ) )
            // InternalScSl.g:486:2: (otherlv_0= 'Pin' ( (lv_pin_1_0= RULE_STRING ) ) )
            {
            // InternalScSl.g:486:2: (otherlv_0= 'Pin' ( (lv_pin_1_0= RULE_STRING ) ) )
            // InternalScSl.g:487:3: otherlv_0= 'Pin' ( (lv_pin_1_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,24,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getColor_PinAccess().getPinKeyword_0());
            		
            // InternalScSl.g:491:3: ( (lv_pin_1_0= RULE_STRING ) )
            // InternalScSl.g:492:4: (lv_pin_1_0= RULE_STRING )
            {
            // InternalScSl.g:492:4: (lv_pin_1_0= RULE_STRING )
            // InternalScSl.g:493:5: lv_pin_1_0= RULE_STRING
            {
            lv_pin_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_pin_1_0, grammarAccess.getColor_PinAccess().getPinSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getColor_PinRule());
            					}
            					setWithLastConsumed(
            						current,
            						"pin",
            						lv_pin_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleColor_Pin"


    // $ANTLR start "entryRuleMotor_Pins"
    // InternalScSl.g:513:1: entryRuleMotor_Pins returns [EObject current=null] : iv_ruleMotor_Pins= ruleMotor_Pins EOF ;
    public final EObject entryRuleMotor_Pins() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMotor_Pins = null;


        try {
            // InternalScSl.g:513:51: (iv_ruleMotor_Pins= ruleMotor_Pins EOF )
            // InternalScSl.g:514:2: iv_ruleMotor_Pins= ruleMotor_Pins EOF
            {
             newCompositeNode(grammarAccess.getMotor_PinsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMotor_Pins=ruleMotor_Pins();

            state._fsp--;

             current =iv_ruleMotor_Pins; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMotor_Pins"


    // $ANTLR start "ruleMotor_Pins"
    // InternalScSl.g:520:1: ruleMotor_Pins returns [EObject current=null] : (otherlv_0= 'Input1_pin' ( (lv_in1_pin_1_0= rulePind ) ) otherlv_2= 'Input2_pin' ( (lv_in2_pin_3_0= rulePind ) ) ) ;
    public final EObject ruleMotor_Pins() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_in1_pin_1_0 = null;

        EObject lv_in2_pin_3_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:526:2: ( (otherlv_0= 'Input1_pin' ( (lv_in1_pin_1_0= rulePind ) ) otherlv_2= 'Input2_pin' ( (lv_in2_pin_3_0= rulePind ) ) ) )
            // InternalScSl.g:527:2: (otherlv_0= 'Input1_pin' ( (lv_in1_pin_1_0= rulePind ) ) otherlv_2= 'Input2_pin' ( (lv_in2_pin_3_0= rulePind ) ) )
            {
            // InternalScSl.g:527:2: (otherlv_0= 'Input1_pin' ( (lv_in1_pin_1_0= rulePind ) ) otherlv_2= 'Input2_pin' ( (lv_in2_pin_3_0= rulePind ) ) )
            // InternalScSl.g:528:3: otherlv_0= 'Input1_pin' ( (lv_in1_pin_1_0= rulePind ) ) otherlv_2= 'Input2_pin' ( (lv_in2_pin_3_0= rulePind ) )
            {
            otherlv_0=(Token)match(input,25,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getMotor_PinsAccess().getInput1_pinKeyword_0());
            		
            // InternalScSl.g:532:3: ( (lv_in1_pin_1_0= rulePind ) )
            // InternalScSl.g:533:4: (lv_in1_pin_1_0= rulePind )
            {
            // InternalScSl.g:533:4: (lv_in1_pin_1_0= rulePind )
            // InternalScSl.g:534:5: lv_in1_pin_1_0= rulePind
            {

            					newCompositeNode(grammarAccess.getMotor_PinsAccess().getIn1_pinPindParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_23);
            lv_in1_pin_1_0=rulePind();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMotor_PinsRule());
            					}
            					set(
            						current,
            						"in1_pin",
            						lv_in1_pin_1_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.Pind");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,26,FOLLOW_7); 

            			newLeafNode(otherlv_2, grammarAccess.getMotor_PinsAccess().getInput2_pinKeyword_2());
            		
            // InternalScSl.g:555:3: ( (lv_in2_pin_3_0= rulePind ) )
            // InternalScSl.g:556:4: (lv_in2_pin_3_0= rulePind )
            {
            // InternalScSl.g:556:4: (lv_in2_pin_3_0= rulePind )
            // InternalScSl.g:557:5: lv_in2_pin_3_0= rulePind
            {

            					newCompositeNode(grammarAccess.getMotor_PinsAccess().getIn2_pinPindParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_in2_pin_3_0=rulePind();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMotor_PinsRule());
            					}
            					set(
            						current,
            						"in2_pin",
            						lv_in2_pin_3_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.Pind");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMotor_Pins"


    // $ANTLR start "entryRulePind"
    // InternalScSl.g:578:1: entryRulePind returns [EObject current=null] : iv_rulePind= rulePind EOF ;
    public final EObject entryRulePind() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePind = null;


        try {
            // InternalScSl.g:578:45: (iv_rulePind= rulePind EOF )
            // InternalScSl.g:579:2: iv_rulePind= rulePind EOF
            {
             newCompositeNode(grammarAccess.getPindRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePind=rulePind();

            state._fsp--;

             current =iv_rulePind; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePind"


    // $ANTLR start "rulePind"
    // InternalScSl.g:585:1: rulePind returns [EObject current=null] : ( (lv_pin_0_0= RULE_INT ) ) ;
    public final EObject rulePind() throws RecognitionException {
        EObject current = null;

        Token lv_pin_0_0=null;


        	enterRule();

        try {
            // InternalScSl.g:591:2: ( ( (lv_pin_0_0= RULE_INT ) ) )
            // InternalScSl.g:592:2: ( (lv_pin_0_0= RULE_INT ) )
            {
            // InternalScSl.g:592:2: ( (lv_pin_0_0= RULE_INT ) )
            // InternalScSl.g:593:3: (lv_pin_0_0= RULE_INT )
            {
            // InternalScSl.g:593:3: (lv_pin_0_0= RULE_INT )
            // InternalScSl.g:594:4: lv_pin_0_0= RULE_INT
            {
            lv_pin_0_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            				newLeafNode(lv_pin_0_0, grammarAccess.getPindAccess().getPinINTTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getPindRule());
            				}
            				setWithLastConsumed(
            					current,
            					"pin",
            					lv_pin_0_0,
            					"org.eclipse.xtext.common.Terminals.INT");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePind"


    // $ANTLR start "entryRuleTask"
    // InternalScSl.g:613:1: entryRuleTask returns [EObject current=null] : iv_ruleTask= ruleTask EOF ;
    public final EObject entryRuleTask() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTask = null;


        try {
            // InternalScSl.g:613:45: (iv_ruleTask= ruleTask EOF )
            // InternalScSl.g:614:2: iv_ruleTask= ruleTask EOF
            {
             newCompositeNode(grammarAccess.getTaskRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTask=ruleTask();

            state._fsp--;

             current =iv_ruleTask; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTask"


    // $ANTLR start "ruleTask"
    // InternalScSl.g:620:1: ruleTask returns [EObject current=null] : (otherlv_0= 'Task' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'priority' ( (lv_priority_3_0= RULE_INT ) ) ( (lv_starting_conds_4_0= ruleStartingCondition ) )* ( (lv_stopping_conds_5_0= ruleStoppingCondition ) )* ( (lv_actions_6_0= ruleAction ) )* ) ;
    public final EObject ruleTask() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_priority_3_0=null;
        EObject lv_starting_conds_4_0 = null;

        EObject lv_stopping_conds_5_0 = null;

        EObject lv_actions_6_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:626:2: ( (otherlv_0= 'Task' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'priority' ( (lv_priority_3_0= RULE_INT ) ) ( (lv_starting_conds_4_0= ruleStartingCondition ) )* ( (lv_stopping_conds_5_0= ruleStoppingCondition ) )* ( (lv_actions_6_0= ruleAction ) )* ) )
            // InternalScSl.g:627:2: (otherlv_0= 'Task' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'priority' ( (lv_priority_3_0= RULE_INT ) ) ( (lv_starting_conds_4_0= ruleStartingCondition ) )* ( (lv_stopping_conds_5_0= ruleStoppingCondition ) )* ( (lv_actions_6_0= ruleAction ) )* )
            {
            // InternalScSl.g:627:2: (otherlv_0= 'Task' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'priority' ( (lv_priority_3_0= RULE_INT ) ) ( (lv_starting_conds_4_0= ruleStartingCondition ) )* ( (lv_stopping_conds_5_0= ruleStoppingCondition ) )* ( (lv_actions_6_0= ruleAction ) )* )
            // InternalScSl.g:628:3: otherlv_0= 'Task' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'priority' ( (lv_priority_3_0= RULE_INT ) ) ( (lv_starting_conds_4_0= ruleStartingCondition ) )* ( (lv_stopping_conds_5_0= ruleStoppingCondition ) )* ( (lv_actions_6_0= ruleAction ) )*
            {
            otherlv_0=(Token)match(input,27,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getTaskAccess().getTaskKeyword_0());
            		
            // InternalScSl.g:632:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalScSl.g:633:4: (lv_name_1_0= RULE_ID )
            {
            // InternalScSl.g:633:4: (lv_name_1_0= RULE_ID )
            // InternalScSl.g:634:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_24); 

            					newLeafNode(lv_name_1_0, grammarAccess.getTaskAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTaskRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,28,FOLLOW_7); 

            			newLeafNode(otherlv_2, grammarAccess.getTaskAccess().getPriorityKeyword_2());
            		
            // InternalScSl.g:654:3: ( (lv_priority_3_0= RULE_INT ) )
            // InternalScSl.g:655:4: (lv_priority_3_0= RULE_INT )
            {
            // InternalScSl.g:655:4: (lv_priority_3_0= RULE_INT )
            // InternalScSl.g:656:5: lv_priority_3_0= RULE_INT
            {
            lv_priority_3_0=(Token)match(input,RULE_INT,FOLLOW_25); 

            					newLeafNode(lv_priority_3_0, grammarAccess.getTaskAccess().getPriorityINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTaskRule());
            					}
            					setWithLastConsumed(
            						current,
            						"priority",
            						lv_priority_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalScSl.g:672:3: ( (lv_starting_conds_4_0= ruleStartingCondition ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==30) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalScSl.g:673:4: (lv_starting_conds_4_0= ruleStartingCondition )
            	    {
            	    // InternalScSl.g:673:4: (lv_starting_conds_4_0= ruleStartingCondition )
            	    // InternalScSl.g:674:5: lv_starting_conds_4_0= ruleStartingCondition
            	    {

            	    					newCompositeNode(grammarAccess.getTaskAccess().getStarting_condsStartingConditionParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_25);
            	    lv_starting_conds_4_0=ruleStartingCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTaskRule());
            	    					}
            	    					add(
            	    						current,
            	    						"starting_conds",
            	    						lv_starting_conds_4_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.StartingCondition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            // InternalScSl.g:691:3: ( (lv_stopping_conds_5_0= ruleStoppingCondition ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==31) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalScSl.g:692:4: (lv_stopping_conds_5_0= ruleStoppingCondition )
            	    {
            	    // InternalScSl.g:692:4: (lv_stopping_conds_5_0= ruleStoppingCondition )
            	    // InternalScSl.g:693:5: lv_stopping_conds_5_0= ruleStoppingCondition
            	    {

            	    					newCompositeNode(grammarAccess.getTaskAccess().getStopping_condsStoppingConditionParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_26);
            	    lv_stopping_conds_5_0=ruleStoppingCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTaskRule());
            	    					}
            	    					add(
            	    						current,
            	    						"stopping_conds",
            	    						lv_stopping_conds_5_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.StoppingCondition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            // InternalScSl.g:710:3: ( (lv_actions_6_0= ruleAction ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=33 && LA15_0<=39)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalScSl.g:711:4: (lv_actions_6_0= ruleAction )
            	    {
            	    // InternalScSl.g:711:4: (lv_actions_6_0= ruleAction )
            	    // InternalScSl.g:712:5: lv_actions_6_0= ruleAction
            	    {

            	    					newCompositeNode(grammarAccess.getTaskAccess().getActionsActionParserRuleCall_6_0());
            	    				
            	    pushFollow(FOLLOW_27);
            	    lv_actions_6_0=ruleAction();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTaskRule());
            	    					}
            	    					add(
            	    						current,
            	    						"actions",
            	    						lv_actions_6_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.Action");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTask"


    // $ANTLR start "entryRuleGoal"
    // InternalScSl.g:733:1: entryRuleGoal returns [EObject current=null] : iv_ruleGoal= ruleGoal EOF ;
    public final EObject entryRuleGoal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGoal = null;


        try {
            // InternalScSl.g:733:45: (iv_ruleGoal= ruleGoal EOF )
            // InternalScSl.g:734:2: iv_ruleGoal= ruleGoal EOF
            {
             newCompositeNode(grammarAccess.getGoalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGoal=ruleGoal();

            state._fsp--;

             current =iv_ruleGoal; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGoal"


    // $ANTLR start "ruleGoal"
    // InternalScSl.g:740:1: ruleGoal returns [EObject current=null] : (otherlv_0= 'Goal' ( (lv_cond_1_0= ruleCondition ) )+ ) ;
    public final EObject ruleGoal() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_cond_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:746:2: ( (otherlv_0= 'Goal' ( (lv_cond_1_0= ruleCondition ) )+ ) )
            // InternalScSl.g:747:2: (otherlv_0= 'Goal' ( (lv_cond_1_0= ruleCondition ) )+ )
            {
            // InternalScSl.g:747:2: (otherlv_0= 'Goal' ( (lv_cond_1_0= ruleCondition ) )+ )
            // InternalScSl.g:748:3: otherlv_0= 'Goal' ( (lv_cond_1_0= ruleCondition ) )+
            {
            otherlv_0=(Token)match(input,29,FOLLOW_28); 

            			newLeafNode(otherlv_0, grammarAccess.getGoalAccess().getGoalKeyword_0());
            		
            // InternalScSl.g:752:3: ( (lv_cond_1_0= ruleCondition ) )+
            int cnt16=0;
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=44 && LA16_0<=49)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalScSl.g:753:4: (lv_cond_1_0= ruleCondition )
            	    {
            	    // InternalScSl.g:753:4: (lv_cond_1_0= ruleCondition )
            	    // InternalScSl.g:754:5: lv_cond_1_0= ruleCondition
            	    {

            	    					newCompositeNode(grammarAccess.getGoalAccess().getCondConditionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_29);
            	    lv_cond_1_0=ruleCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getGoalRule());
            	    					}
            	    					add(
            	    						current,
            	    						"cond",
            	    						lv_cond_1_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.Condition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt16 >= 1 ) break loop16;
                        EarlyExitException eee =
                            new EarlyExitException(16, input);
                        throw eee;
                }
                cnt16++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGoal"


    // $ANTLR start "entryRuleStartingCondition"
    // InternalScSl.g:775:1: entryRuleStartingCondition returns [EObject current=null] : iv_ruleStartingCondition= ruleStartingCondition EOF ;
    public final EObject entryRuleStartingCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStartingCondition = null;


        try {
            // InternalScSl.g:775:58: (iv_ruleStartingCondition= ruleStartingCondition EOF )
            // InternalScSl.g:776:2: iv_ruleStartingCondition= ruleStartingCondition EOF
            {
             newCompositeNode(grammarAccess.getStartingConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStartingCondition=ruleStartingCondition();

            state._fsp--;

             current =iv_ruleStartingCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStartingCondition"


    // $ANTLR start "ruleStartingCondition"
    // InternalScSl.g:782:1: ruleStartingCondition returns [EObject current=null] : (otherlv_0= 'Start_if' ( (lv_cond_1_0= ruleCondition ) )+ ) ;
    public final EObject ruleStartingCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_cond_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:788:2: ( (otherlv_0= 'Start_if' ( (lv_cond_1_0= ruleCondition ) )+ ) )
            // InternalScSl.g:789:2: (otherlv_0= 'Start_if' ( (lv_cond_1_0= ruleCondition ) )+ )
            {
            // InternalScSl.g:789:2: (otherlv_0= 'Start_if' ( (lv_cond_1_0= ruleCondition ) )+ )
            // InternalScSl.g:790:3: otherlv_0= 'Start_if' ( (lv_cond_1_0= ruleCondition ) )+
            {
            otherlv_0=(Token)match(input,30,FOLLOW_28); 

            			newLeafNode(otherlv_0, grammarAccess.getStartingConditionAccess().getStart_ifKeyword_0());
            		
            // InternalScSl.g:794:3: ( (lv_cond_1_0= ruleCondition ) )+
            int cnt17=0;
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>=44 && LA17_0<=49)) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalScSl.g:795:4: (lv_cond_1_0= ruleCondition )
            	    {
            	    // InternalScSl.g:795:4: (lv_cond_1_0= ruleCondition )
            	    // InternalScSl.g:796:5: lv_cond_1_0= ruleCondition
            	    {

            	    					newCompositeNode(grammarAccess.getStartingConditionAccess().getCondConditionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_29);
            	    lv_cond_1_0=ruleCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getStartingConditionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"cond",
            	    						lv_cond_1_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.Condition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt17 >= 1 ) break loop17;
                        EarlyExitException eee =
                            new EarlyExitException(17, input);
                        throw eee;
                }
                cnt17++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStartingCondition"


    // $ANTLR start "entryRuleStoppingCondition"
    // InternalScSl.g:817:1: entryRuleStoppingCondition returns [EObject current=null] : iv_ruleStoppingCondition= ruleStoppingCondition EOF ;
    public final EObject entryRuleStoppingCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStoppingCondition = null;


        try {
            // InternalScSl.g:817:58: (iv_ruleStoppingCondition= ruleStoppingCondition EOF )
            // InternalScSl.g:818:2: iv_ruleStoppingCondition= ruleStoppingCondition EOF
            {
             newCompositeNode(grammarAccess.getStoppingConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStoppingCondition=ruleStoppingCondition();

            state._fsp--;

             current =iv_ruleStoppingCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStoppingCondition"


    // $ANTLR start "ruleStoppingCondition"
    // InternalScSl.g:824:1: ruleStoppingCondition returns [EObject current=null] : (otherlv_0= 'Stop_when' ( (lv_cond_1_0= ruleCondition ) )+ ) ;
    public final EObject ruleStoppingCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_cond_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:830:2: ( (otherlv_0= 'Stop_when' ( (lv_cond_1_0= ruleCondition ) )+ ) )
            // InternalScSl.g:831:2: (otherlv_0= 'Stop_when' ( (lv_cond_1_0= ruleCondition ) )+ )
            {
            // InternalScSl.g:831:2: (otherlv_0= 'Stop_when' ( (lv_cond_1_0= ruleCondition ) )+ )
            // InternalScSl.g:832:3: otherlv_0= 'Stop_when' ( (lv_cond_1_0= ruleCondition ) )+
            {
            otherlv_0=(Token)match(input,31,FOLLOW_28); 

            			newLeafNode(otherlv_0, grammarAccess.getStoppingConditionAccess().getStop_whenKeyword_0());
            		
            // InternalScSl.g:836:3: ( (lv_cond_1_0= ruleCondition ) )+
            int cnt18=0;
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>=44 && LA18_0<=49)) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalScSl.g:837:4: (lv_cond_1_0= ruleCondition )
            	    {
            	    // InternalScSl.g:837:4: (lv_cond_1_0= ruleCondition )
            	    // InternalScSl.g:838:5: lv_cond_1_0= ruleCondition
            	    {

            	    					newCompositeNode(grammarAccess.getStoppingConditionAccess().getCondConditionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_29);
            	    lv_cond_1_0=ruleCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getStoppingConditionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"cond",
            	    						lv_cond_1_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.Condition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt18 >= 1 ) break loop18;
                        EarlyExitException eee =
                            new EarlyExitException(18, input);
                        throw eee;
                }
                cnt18++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStoppingCondition"


    // $ANTLR start "entryRuleUntilCondition"
    // InternalScSl.g:859:1: entryRuleUntilCondition returns [EObject current=null] : iv_ruleUntilCondition= ruleUntilCondition EOF ;
    public final EObject entryRuleUntilCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUntilCondition = null;


        try {
            // InternalScSl.g:859:55: (iv_ruleUntilCondition= ruleUntilCondition EOF )
            // InternalScSl.g:860:2: iv_ruleUntilCondition= ruleUntilCondition EOF
            {
             newCompositeNode(grammarAccess.getUntilConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUntilCondition=ruleUntilCondition();

            state._fsp--;

             current =iv_ruleUntilCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUntilCondition"


    // $ANTLR start "ruleUntilCondition"
    // InternalScSl.g:866:1: ruleUntilCondition returns [EObject current=null] : (otherlv_0= 'until' ( (lv_cond_1_0= ruleCondition ) )+ ) ;
    public final EObject ruleUntilCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_cond_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:872:2: ( (otherlv_0= 'until' ( (lv_cond_1_0= ruleCondition ) )+ ) )
            // InternalScSl.g:873:2: (otherlv_0= 'until' ( (lv_cond_1_0= ruleCondition ) )+ )
            {
            // InternalScSl.g:873:2: (otherlv_0= 'until' ( (lv_cond_1_0= ruleCondition ) )+ )
            // InternalScSl.g:874:3: otherlv_0= 'until' ( (lv_cond_1_0= ruleCondition ) )+
            {
            otherlv_0=(Token)match(input,32,FOLLOW_28); 

            			newLeafNode(otherlv_0, grammarAccess.getUntilConditionAccess().getUntilKeyword_0());
            		
            // InternalScSl.g:878:3: ( (lv_cond_1_0= ruleCondition ) )+
            int cnt19=0;
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( ((LA19_0>=44 && LA19_0<=49)) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalScSl.g:879:4: (lv_cond_1_0= ruleCondition )
            	    {
            	    // InternalScSl.g:879:4: (lv_cond_1_0= ruleCondition )
            	    // InternalScSl.g:880:5: lv_cond_1_0= ruleCondition
            	    {

            	    					newCompositeNode(grammarAccess.getUntilConditionAccess().getCondConditionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_29);
            	    lv_cond_1_0=ruleCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getUntilConditionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"cond",
            	    						lv_cond_1_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.Condition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt19 >= 1 ) break loop19;
                        EarlyExitException eee =
                            new EarlyExitException(19, input);
                        throw eee;
                }
                cnt19++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUntilCondition"


    // $ANTLR start "entryRuleAction"
    // InternalScSl.g:901:1: entryRuleAction returns [EObject current=null] : iv_ruleAction= ruleAction EOF ;
    public final EObject entryRuleAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAction = null;


        try {
            // InternalScSl.g:901:47: (iv_ruleAction= ruleAction EOF )
            // InternalScSl.g:902:2: iv_ruleAction= ruleAction EOF
            {
             newCompositeNode(grammarAccess.getActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAction=ruleAction();

            state._fsp--;

             current =iv_ruleAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAction"


    // $ANTLR start "ruleAction"
    // InternalScSl.g:908:1: ruleAction returns [EObject current=null] : ( (otherlv_0= 'Drive' this_DriveAction_1= ruleDriveAction ) | (otherlv_2= 'Turn' this_TurnAction_3= ruleTurnAction ) | (otherlv_4= 'Wait' this_WaitAction_5= ruleWaitAction ) | (otherlv_6= 'Mark' this_MarkAction_7= ruleMarkAction ) | (otherlv_8= 'Clear' this_ClearAction_9= ruleClearAction ) | (otherlv_10= 'Show' this_MessageAction_11= ruleMessageAction ) | (otherlv_12= 'Play' this_SoundAction_13= ruleSoundAction ) ) ;
    public final EObject ruleAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        EObject this_DriveAction_1 = null;

        EObject this_TurnAction_3 = null;

        EObject this_WaitAction_5 = null;

        EObject this_MarkAction_7 = null;

        EObject this_ClearAction_9 = null;

        EObject this_MessageAction_11 = null;

        EObject this_SoundAction_13 = null;



        	enterRule();

        try {
            // InternalScSl.g:914:2: ( ( (otherlv_0= 'Drive' this_DriveAction_1= ruleDriveAction ) | (otherlv_2= 'Turn' this_TurnAction_3= ruleTurnAction ) | (otherlv_4= 'Wait' this_WaitAction_5= ruleWaitAction ) | (otherlv_6= 'Mark' this_MarkAction_7= ruleMarkAction ) | (otherlv_8= 'Clear' this_ClearAction_9= ruleClearAction ) | (otherlv_10= 'Show' this_MessageAction_11= ruleMessageAction ) | (otherlv_12= 'Play' this_SoundAction_13= ruleSoundAction ) ) )
            // InternalScSl.g:915:2: ( (otherlv_0= 'Drive' this_DriveAction_1= ruleDriveAction ) | (otherlv_2= 'Turn' this_TurnAction_3= ruleTurnAction ) | (otherlv_4= 'Wait' this_WaitAction_5= ruleWaitAction ) | (otherlv_6= 'Mark' this_MarkAction_7= ruleMarkAction ) | (otherlv_8= 'Clear' this_ClearAction_9= ruleClearAction ) | (otherlv_10= 'Show' this_MessageAction_11= ruleMessageAction ) | (otherlv_12= 'Play' this_SoundAction_13= ruleSoundAction ) )
            {
            // InternalScSl.g:915:2: ( (otherlv_0= 'Drive' this_DriveAction_1= ruleDriveAction ) | (otherlv_2= 'Turn' this_TurnAction_3= ruleTurnAction ) | (otherlv_4= 'Wait' this_WaitAction_5= ruleWaitAction ) | (otherlv_6= 'Mark' this_MarkAction_7= ruleMarkAction ) | (otherlv_8= 'Clear' this_ClearAction_9= ruleClearAction ) | (otherlv_10= 'Show' this_MessageAction_11= ruleMessageAction ) | (otherlv_12= 'Play' this_SoundAction_13= ruleSoundAction ) )
            int alt20=7;
            switch ( input.LA(1) ) {
            case 33:
                {
                alt20=1;
                }
                break;
            case 34:
                {
                alt20=2;
                }
                break;
            case 35:
                {
                alt20=3;
                }
                break;
            case 36:
                {
                alt20=4;
                }
                break;
            case 37:
                {
                alt20=5;
                }
                break;
            case 38:
                {
                alt20=6;
                }
                break;
            case 39:
                {
                alt20=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }

            switch (alt20) {
                case 1 :
                    // InternalScSl.g:916:3: (otherlv_0= 'Drive' this_DriveAction_1= ruleDriveAction )
                    {
                    // InternalScSl.g:916:3: (otherlv_0= 'Drive' this_DriveAction_1= ruleDriveAction )
                    // InternalScSl.g:917:4: otherlv_0= 'Drive' this_DriveAction_1= ruleDriveAction
                    {
                    otherlv_0=(Token)match(input,33,FOLLOW_30); 

                    				newLeafNode(otherlv_0, grammarAccess.getActionAccess().getDriveKeyword_0_0());
                    			

                    				newCompositeNode(grammarAccess.getActionAccess().getDriveActionParserRuleCall_0_1());
                    			
                    pushFollow(FOLLOW_2);
                    this_DriveAction_1=ruleDriveAction();

                    state._fsp--;


                    				current = this_DriveAction_1;
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:931:3: (otherlv_2= 'Turn' this_TurnAction_3= ruleTurnAction )
                    {
                    // InternalScSl.g:931:3: (otherlv_2= 'Turn' this_TurnAction_3= ruleTurnAction )
                    // InternalScSl.g:932:4: otherlv_2= 'Turn' this_TurnAction_3= ruleTurnAction
                    {
                    otherlv_2=(Token)match(input,34,FOLLOW_31); 

                    				newLeafNode(otherlv_2, grammarAccess.getActionAccess().getTurnKeyword_1_0());
                    			

                    				newCompositeNode(grammarAccess.getActionAccess().getTurnActionParserRuleCall_1_1());
                    			
                    pushFollow(FOLLOW_2);
                    this_TurnAction_3=ruleTurnAction();

                    state._fsp--;


                    				current = this_TurnAction_3;
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalScSl.g:946:3: (otherlv_4= 'Wait' this_WaitAction_5= ruleWaitAction )
                    {
                    // InternalScSl.g:946:3: (otherlv_4= 'Wait' this_WaitAction_5= ruleWaitAction )
                    // InternalScSl.g:947:4: otherlv_4= 'Wait' this_WaitAction_5= ruleWaitAction
                    {
                    otherlv_4=(Token)match(input,35,FOLLOW_32); 

                    				newLeafNode(otherlv_4, grammarAccess.getActionAccess().getWaitKeyword_2_0());
                    			

                    				newCompositeNode(grammarAccess.getActionAccess().getWaitActionParserRuleCall_2_1());
                    			
                    pushFollow(FOLLOW_2);
                    this_WaitAction_5=ruleWaitAction();

                    state._fsp--;


                    				current = this_WaitAction_5;
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalScSl.g:961:3: (otherlv_6= 'Mark' this_MarkAction_7= ruleMarkAction )
                    {
                    // InternalScSl.g:961:3: (otherlv_6= 'Mark' this_MarkAction_7= ruleMarkAction )
                    // InternalScSl.g:962:4: otherlv_6= 'Mark' this_MarkAction_7= ruleMarkAction
                    {
                    otherlv_6=(Token)match(input,36,FOLLOW_33); 

                    				newLeafNode(otherlv_6, grammarAccess.getActionAccess().getMarkKeyword_3_0());
                    			

                    				newCompositeNode(grammarAccess.getActionAccess().getMarkActionParserRuleCall_3_1());
                    			
                    pushFollow(FOLLOW_2);
                    this_MarkAction_7=ruleMarkAction();

                    state._fsp--;


                    				current = this_MarkAction_7;
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalScSl.g:976:3: (otherlv_8= 'Clear' this_ClearAction_9= ruleClearAction )
                    {
                    // InternalScSl.g:976:3: (otherlv_8= 'Clear' this_ClearAction_9= ruleClearAction )
                    // InternalScSl.g:977:4: otherlv_8= 'Clear' this_ClearAction_9= ruleClearAction
                    {
                    otherlv_8=(Token)match(input,37,FOLLOW_33); 

                    				newLeafNode(otherlv_8, grammarAccess.getActionAccess().getClearKeyword_4_0());
                    			

                    				newCompositeNode(grammarAccess.getActionAccess().getClearActionParserRuleCall_4_1());
                    			
                    pushFollow(FOLLOW_2);
                    this_ClearAction_9=ruleClearAction();

                    state._fsp--;


                    				current = this_ClearAction_9;
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalScSl.g:991:3: (otherlv_10= 'Show' this_MessageAction_11= ruleMessageAction )
                    {
                    // InternalScSl.g:991:3: (otherlv_10= 'Show' this_MessageAction_11= ruleMessageAction )
                    // InternalScSl.g:992:4: otherlv_10= 'Show' this_MessageAction_11= ruleMessageAction
                    {
                    otherlv_10=(Token)match(input,38,FOLLOW_34); 

                    				newLeafNode(otherlv_10, grammarAccess.getActionAccess().getShowKeyword_5_0());
                    			

                    				newCompositeNode(grammarAccess.getActionAccess().getMessageActionParserRuleCall_5_1());
                    			
                    pushFollow(FOLLOW_2);
                    this_MessageAction_11=ruleMessageAction();

                    state._fsp--;


                    				current = this_MessageAction_11;
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalScSl.g:1006:3: (otherlv_12= 'Play' this_SoundAction_13= ruleSoundAction )
                    {
                    // InternalScSl.g:1006:3: (otherlv_12= 'Play' this_SoundAction_13= ruleSoundAction )
                    // InternalScSl.g:1007:4: otherlv_12= 'Play' this_SoundAction_13= ruleSoundAction
                    {
                    otherlv_12=(Token)match(input,39,FOLLOW_35); 

                    				newLeafNode(otherlv_12, grammarAccess.getActionAccess().getPlayKeyword_6_0());
                    			

                    				newCompositeNode(grammarAccess.getActionAccess().getSoundActionParserRuleCall_6_1());
                    			
                    pushFollow(FOLLOW_2);
                    this_SoundAction_13=ruleSoundAction();

                    state._fsp--;


                    				current = this_SoundAction_13;
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAction"


    // $ANTLR start "entryRuleMessageAction"
    // InternalScSl.g:1024:1: entryRuleMessageAction returns [EObject current=null] : iv_ruleMessageAction= ruleMessageAction EOF ;
    public final EObject entryRuleMessageAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMessageAction = null;


        try {
            // InternalScSl.g:1024:54: (iv_ruleMessageAction= ruleMessageAction EOF )
            // InternalScSl.g:1025:2: iv_ruleMessageAction= ruleMessageAction EOF
            {
             newCompositeNode(grammarAccess.getMessageActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMessageAction=ruleMessageAction();

            state._fsp--;

             current =iv_ruleMessageAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMessageAction"


    // $ANTLR start "ruleMessageAction"
    // InternalScSl.g:1031:1: ruleMessageAction returns [EObject current=null] : (otherlv_0= 'message' ( (lv_m_1_0= RULE_STRING ) ) ) ;
    public final EObject ruleMessageAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_m_1_0=null;


        	enterRule();

        try {
            // InternalScSl.g:1037:2: ( (otherlv_0= 'message' ( (lv_m_1_0= RULE_STRING ) ) ) )
            // InternalScSl.g:1038:2: (otherlv_0= 'message' ( (lv_m_1_0= RULE_STRING ) ) )
            {
            // InternalScSl.g:1038:2: (otherlv_0= 'message' ( (lv_m_1_0= RULE_STRING ) ) )
            // InternalScSl.g:1039:3: otherlv_0= 'message' ( (lv_m_1_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,40,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getMessageActionAccess().getMessageKeyword_0());
            		
            // InternalScSl.g:1043:3: ( (lv_m_1_0= RULE_STRING ) )
            // InternalScSl.g:1044:4: (lv_m_1_0= RULE_STRING )
            {
            // InternalScSl.g:1044:4: (lv_m_1_0= RULE_STRING )
            // InternalScSl.g:1045:5: lv_m_1_0= RULE_STRING
            {
            lv_m_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_m_1_0, grammarAccess.getMessageActionAccess().getMSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMessageActionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"m",
            						lv_m_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMessageAction"


    // $ANTLR start "entryRuleSoundAction"
    // InternalScSl.g:1065:1: entryRuleSoundAction returns [EObject current=null] : iv_ruleSoundAction= ruleSoundAction EOF ;
    public final EObject entryRuleSoundAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSoundAction = null;


        try {
            // InternalScSl.g:1065:52: (iv_ruleSoundAction= ruleSoundAction EOF )
            // InternalScSl.g:1066:2: iv_ruleSoundAction= ruleSoundAction EOF
            {
             newCompositeNode(grammarAccess.getSoundActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSoundAction=ruleSoundAction();

            state._fsp--;

             current =iv_ruleSoundAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSoundAction"


    // $ANTLR start "ruleSoundAction"
    // InternalScSl.g:1072:1: ruleSoundAction returns [EObject current=null] : (otherlv_0= 'note' ( (lv_n_1_0= RULE_STRING ) ) otherlv_2= 'for' ( (lv_t_3_0= RULE_INT ) ) otherlv_4= 'ms' ) ;
    public final EObject ruleSoundAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_n_1_0=null;
        Token otherlv_2=null;
        Token lv_t_3_0=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalScSl.g:1078:2: ( (otherlv_0= 'note' ( (lv_n_1_0= RULE_STRING ) ) otherlv_2= 'for' ( (lv_t_3_0= RULE_INT ) ) otherlv_4= 'ms' ) )
            // InternalScSl.g:1079:2: (otherlv_0= 'note' ( (lv_n_1_0= RULE_STRING ) ) otherlv_2= 'for' ( (lv_t_3_0= RULE_INT ) ) otherlv_4= 'ms' )
            {
            // InternalScSl.g:1079:2: (otherlv_0= 'note' ( (lv_n_1_0= RULE_STRING ) ) otherlv_2= 'for' ( (lv_t_3_0= RULE_INT ) ) otherlv_4= 'ms' )
            // InternalScSl.g:1080:3: otherlv_0= 'note' ( (lv_n_1_0= RULE_STRING ) ) otherlv_2= 'for' ( (lv_t_3_0= RULE_INT ) ) otherlv_4= 'ms'
            {
            otherlv_0=(Token)match(input,41,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getSoundActionAccess().getNoteKeyword_0());
            		
            // InternalScSl.g:1084:3: ( (lv_n_1_0= RULE_STRING ) )
            // InternalScSl.g:1085:4: (lv_n_1_0= RULE_STRING )
            {
            // InternalScSl.g:1085:4: (lv_n_1_0= RULE_STRING )
            // InternalScSl.g:1086:5: lv_n_1_0= RULE_STRING
            {
            lv_n_1_0=(Token)match(input,RULE_STRING,FOLLOW_36); 

            					newLeafNode(lv_n_1_0, grammarAccess.getSoundActionAccess().getNSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSoundActionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"n",
            						lv_n_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,42,FOLLOW_7); 

            			newLeafNode(otherlv_2, grammarAccess.getSoundActionAccess().getForKeyword_2());
            		
            // InternalScSl.g:1106:3: ( (lv_t_3_0= RULE_INT ) )
            // InternalScSl.g:1107:4: (lv_t_3_0= RULE_INT )
            {
            // InternalScSl.g:1107:4: (lv_t_3_0= RULE_INT )
            // InternalScSl.g:1108:5: lv_t_3_0= RULE_INT
            {
            lv_t_3_0=(Token)match(input,RULE_INT,FOLLOW_37); 

            					newLeafNode(lv_t_3_0, grammarAccess.getSoundActionAccess().getTINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSoundActionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"t",
            						lv_t_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_4=(Token)match(input,43,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getSoundActionAccess().getMsKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSoundAction"


    // $ANTLR start "entryRuleMarkAction"
    // InternalScSl.g:1132:1: entryRuleMarkAction returns [EObject current=null] : iv_ruleMarkAction= ruleMarkAction EOF ;
    public final EObject entryRuleMarkAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMarkAction = null;


        try {
            // InternalScSl.g:1132:51: (iv_ruleMarkAction= ruleMarkAction EOF )
            // InternalScSl.g:1133:2: iv_ruleMarkAction= ruleMarkAction EOF
            {
             newCompositeNode(grammarAccess.getMarkActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMarkAction=ruleMarkAction();

            state._fsp--;

             current =iv_ruleMarkAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMarkAction"


    // $ANTLR start "ruleMarkAction"
    // InternalScSl.g:1139:1: ruleMarkAction returns [EObject current=null] : (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) ) ;
    public final EObject ruleMarkAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_a_1_0=null;


        	enterRule();

        try {
            // InternalScSl.g:1145:2: ( (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) ) )
            // InternalScSl.g:1146:2: (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) )
            {
            // InternalScSl.g:1146:2: (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) )
            // InternalScSl.g:1147:3: otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,44,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getMarkActionAccess().getAchievementKeyword_0());
            		
            // InternalScSl.g:1151:3: ( (lv_a_1_0= RULE_INT ) )
            // InternalScSl.g:1152:4: (lv_a_1_0= RULE_INT )
            {
            // InternalScSl.g:1152:4: (lv_a_1_0= RULE_INT )
            // InternalScSl.g:1153:5: lv_a_1_0= RULE_INT
            {
            lv_a_1_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_a_1_0, grammarAccess.getMarkActionAccess().getAINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMarkActionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"a",
            						lv_a_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMarkAction"


    // $ANTLR start "entryRuleClearAction"
    // InternalScSl.g:1173:1: entryRuleClearAction returns [EObject current=null] : iv_ruleClearAction= ruleClearAction EOF ;
    public final EObject entryRuleClearAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClearAction = null;


        try {
            // InternalScSl.g:1173:52: (iv_ruleClearAction= ruleClearAction EOF )
            // InternalScSl.g:1174:2: iv_ruleClearAction= ruleClearAction EOF
            {
             newCompositeNode(grammarAccess.getClearActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClearAction=ruleClearAction();

            state._fsp--;

             current =iv_ruleClearAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClearAction"


    // $ANTLR start "ruleClearAction"
    // InternalScSl.g:1180:1: ruleClearAction returns [EObject current=null] : (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) ) ;
    public final EObject ruleClearAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_a_1_0=null;


        	enterRule();

        try {
            // InternalScSl.g:1186:2: ( (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) ) )
            // InternalScSl.g:1187:2: (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) )
            {
            // InternalScSl.g:1187:2: (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) )
            // InternalScSl.g:1188:3: otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,44,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getClearActionAccess().getAchievementKeyword_0());
            		
            // InternalScSl.g:1192:3: ( (lv_a_1_0= RULE_INT ) )
            // InternalScSl.g:1193:4: (lv_a_1_0= RULE_INT )
            {
            // InternalScSl.g:1193:4: (lv_a_1_0= RULE_INT )
            // InternalScSl.g:1194:5: lv_a_1_0= RULE_INT
            {
            lv_a_1_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_a_1_0, grammarAccess.getClearActionAccess().getAINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClearActionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"a",
            						lv_a_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClearAction"


    // $ANTLR start "entryRuleWaitAction"
    // InternalScSl.g:1214:1: entryRuleWaitAction returns [EObject current=null] : iv_ruleWaitAction= ruleWaitAction EOF ;
    public final EObject entryRuleWaitAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWaitAction = null;


        try {
            // InternalScSl.g:1214:51: (iv_ruleWaitAction= ruleWaitAction EOF )
            // InternalScSl.g:1215:2: iv_ruleWaitAction= ruleWaitAction EOF
            {
             newCompositeNode(grammarAccess.getWaitActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWaitAction=ruleWaitAction();

            state._fsp--;

             current =iv_ruleWaitAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWaitAction"


    // $ANTLR start "ruleWaitAction"
    // InternalScSl.g:1221:1: ruleWaitAction returns [EObject current=null] : ( (lv_until_cond_0_0= ruleUntilCondition ) )+ ;
    public final EObject ruleWaitAction() throws RecognitionException {
        EObject current = null;

        EObject lv_until_cond_0_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1227:2: ( ( (lv_until_cond_0_0= ruleUntilCondition ) )+ )
            // InternalScSl.g:1228:2: ( (lv_until_cond_0_0= ruleUntilCondition ) )+
            {
            // InternalScSl.g:1228:2: ( (lv_until_cond_0_0= ruleUntilCondition ) )+
            int cnt21=0;
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==32) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalScSl.g:1229:3: (lv_until_cond_0_0= ruleUntilCondition )
            	    {
            	    // InternalScSl.g:1229:3: (lv_until_cond_0_0= ruleUntilCondition )
            	    // InternalScSl.g:1230:4: lv_until_cond_0_0= ruleUntilCondition
            	    {

            	    				newCompositeNode(grammarAccess.getWaitActionAccess().getUntil_condUntilConditionParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_38);
            	    lv_until_cond_0_0=ruleUntilCondition();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getWaitActionRule());
            	    				}
            	    				add(
            	    					current,
            	    					"until_cond",
            	    					lv_until_cond_0_0,
            	    					"vlad.xtextt.smartCar.scsl.ScSl.UntilCondition");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt21 >= 1 ) break loop21;
                        EarlyExitException eee =
                            new EarlyExitException(21, input);
                        throw eee;
                }
                cnt21++;
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWaitAction"


    // $ANTLR start "entryRuleDriveAction"
    // InternalScSl.g:1250:1: entryRuleDriveAction returns [EObject current=null] : iv_ruleDriveAction= ruleDriveAction EOF ;
    public final EObject entryRuleDriveAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDriveAction = null;


        try {
            // InternalScSl.g:1250:52: (iv_ruleDriveAction= ruleDriveAction EOF )
            // InternalScSl.g:1251:2: iv_ruleDriveAction= ruleDriveAction EOF
            {
             newCompositeNode(grammarAccess.getDriveActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDriveAction=ruleDriveAction();

            state._fsp--;

             current =iv_ruleDriveAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDriveAction"


    // $ANTLR start "ruleDriveAction"
    // InternalScSl.g:1257:1: ruleDriveAction returns [EObject current=null] : ( ( (lv_direction_0_0= ruleDriveDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ ) ;
    public final EObject ruleDriveAction() throws RecognitionException {
        EObject current = null;

        Enumerator lv_direction_0_0 = null;

        EObject lv_until_cond_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1263:2: ( ( ( (lv_direction_0_0= ruleDriveDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ ) )
            // InternalScSl.g:1264:2: ( ( (lv_direction_0_0= ruleDriveDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ )
            {
            // InternalScSl.g:1264:2: ( ( (lv_direction_0_0= ruleDriveDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ )
            // InternalScSl.g:1265:3: ( (lv_direction_0_0= ruleDriveDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+
            {
            // InternalScSl.g:1265:3: ( (lv_direction_0_0= ruleDriveDirection ) )
            // InternalScSl.g:1266:4: (lv_direction_0_0= ruleDriveDirection )
            {
            // InternalScSl.g:1266:4: (lv_direction_0_0= ruleDriveDirection )
            // InternalScSl.g:1267:5: lv_direction_0_0= ruleDriveDirection
            {

            					newCompositeNode(grammarAccess.getDriveActionAccess().getDirectionDriveDirectionEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_32);
            lv_direction_0_0=ruleDriveDirection();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDriveActionRule());
            					}
            					set(
            						current,
            						"direction",
            						lv_direction_0_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.DriveDirection");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalScSl.g:1284:3: ( (lv_until_cond_1_0= ruleUntilCondition ) )+
            int cnt22=0;
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==32) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalScSl.g:1285:4: (lv_until_cond_1_0= ruleUntilCondition )
            	    {
            	    // InternalScSl.g:1285:4: (lv_until_cond_1_0= ruleUntilCondition )
            	    // InternalScSl.g:1286:5: lv_until_cond_1_0= ruleUntilCondition
            	    {

            	    					newCompositeNode(grammarAccess.getDriveActionAccess().getUntil_condUntilConditionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_38);
            	    lv_until_cond_1_0=ruleUntilCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDriveActionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"until_cond",
            	    						lv_until_cond_1_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.UntilCondition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt22 >= 1 ) break loop22;
                        EarlyExitException eee =
                            new EarlyExitException(22, input);
                        throw eee;
                }
                cnt22++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDriveAction"


    // $ANTLR start "entryRuleTurnAction"
    // InternalScSl.g:1307:1: entryRuleTurnAction returns [EObject current=null] : iv_ruleTurnAction= ruleTurnAction EOF ;
    public final EObject entryRuleTurnAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTurnAction = null;


        try {
            // InternalScSl.g:1307:51: (iv_ruleTurnAction= ruleTurnAction EOF )
            // InternalScSl.g:1308:2: iv_ruleTurnAction= ruleTurnAction EOF
            {
             newCompositeNode(grammarAccess.getTurnActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTurnAction=ruleTurnAction();

            state._fsp--;

             current =iv_ruleTurnAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTurnAction"


    // $ANTLR start "ruleTurnAction"
    // InternalScSl.g:1314:1: ruleTurnAction returns [EObject current=null] : ( ( (lv_direction_0_0= ruleTurnDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ ) ;
    public final EObject ruleTurnAction() throws RecognitionException {
        EObject current = null;

        Enumerator lv_direction_0_0 = null;

        EObject lv_until_cond_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1320:2: ( ( ( (lv_direction_0_0= ruleTurnDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ ) )
            // InternalScSl.g:1321:2: ( ( (lv_direction_0_0= ruleTurnDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ )
            {
            // InternalScSl.g:1321:2: ( ( (lv_direction_0_0= ruleTurnDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+ )
            // InternalScSl.g:1322:3: ( (lv_direction_0_0= ruleTurnDirection ) ) ( (lv_until_cond_1_0= ruleUntilCondition ) )+
            {
            // InternalScSl.g:1322:3: ( (lv_direction_0_0= ruleTurnDirection ) )
            // InternalScSl.g:1323:4: (lv_direction_0_0= ruleTurnDirection )
            {
            // InternalScSl.g:1323:4: (lv_direction_0_0= ruleTurnDirection )
            // InternalScSl.g:1324:5: lv_direction_0_0= ruleTurnDirection
            {

            					newCompositeNode(grammarAccess.getTurnActionAccess().getDirectionTurnDirectionEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_32);
            lv_direction_0_0=ruleTurnDirection();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTurnActionRule());
            					}
            					set(
            						current,
            						"direction",
            						lv_direction_0_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.TurnDirection");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalScSl.g:1341:3: ( (lv_until_cond_1_0= ruleUntilCondition ) )+
            int cnt23=0;
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==32) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // InternalScSl.g:1342:4: (lv_until_cond_1_0= ruleUntilCondition )
            	    {
            	    // InternalScSl.g:1342:4: (lv_until_cond_1_0= ruleUntilCondition )
            	    // InternalScSl.g:1343:5: lv_until_cond_1_0= ruleUntilCondition
            	    {

            	    					newCompositeNode(grammarAccess.getTurnActionAccess().getUntil_condUntilConditionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_38);
            	    lv_until_cond_1_0=ruleUntilCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTurnActionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"until_cond",
            	    						lv_until_cond_1_0,
            	    						"vlad.xtextt.smartCar.scsl.ScSl.UntilCondition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt23 >= 1 ) break loop23;
                        EarlyExitException eee =
                            new EarlyExitException(23, input);
                        throw eee;
                }
                cnt23++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTurnAction"


    // $ANTLR start "entryRuleCondition"
    // InternalScSl.g:1364:1: entryRuleCondition returns [EObject current=null] : iv_ruleCondition= ruleCondition EOF ;
    public final EObject entryRuleCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCondition = null;


        try {
            // InternalScSl.g:1364:50: (iv_ruleCondition= ruleCondition EOF )
            // InternalScSl.g:1365:2: iv_ruleCondition= ruleCondition EOF
            {
             newCompositeNode(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCondition=ruleCondition();

            state._fsp--;

             current =iv_ruleCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalScSl.g:1371:1: ruleCondition returns [EObject current=null] : (this_ObjectFrontCondition_0= ruleObjectFrontCondition | this_ObjectRightCondition_1= ruleObjectRightCondition | this_ColorCondition_2= ruleColorCondition | this_TimeCondition_3= ruleTimeCondition | this_AchievementCondition_4= ruleAchievementCondition | this_MemoryCondition_5= ruleMemoryCondition ) ;
    public final EObject ruleCondition() throws RecognitionException {
        EObject current = null;

        EObject this_ObjectFrontCondition_0 = null;

        EObject this_ObjectRightCondition_1 = null;

        EObject this_ColorCondition_2 = null;

        EObject this_TimeCondition_3 = null;

        EObject this_AchievementCondition_4 = null;

        EObject this_MemoryCondition_5 = null;



        	enterRule();

        try {
            // InternalScSl.g:1377:2: ( (this_ObjectFrontCondition_0= ruleObjectFrontCondition | this_ObjectRightCondition_1= ruleObjectRightCondition | this_ColorCondition_2= ruleColorCondition | this_TimeCondition_3= ruleTimeCondition | this_AchievementCondition_4= ruleAchievementCondition | this_MemoryCondition_5= ruleMemoryCondition ) )
            // InternalScSl.g:1378:2: (this_ObjectFrontCondition_0= ruleObjectFrontCondition | this_ObjectRightCondition_1= ruleObjectRightCondition | this_ColorCondition_2= ruleColorCondition | this_TimeCondition_3= ruleTimeCondition | this_AchievementCondition_4= ruleAchievementCondition | this_MemoryCondition_5= ruleMemoryCondition )
            {
            // InternalScSl.g:1378:2: (this_ObjectFrontCondition_0= ruleObjectFrontCondition | this_ObjectRightCondition_1= ruleObjectRightCondition | this_ColorCondition_2= ruleColorCondition | this_TimeCondition_3= ruleTimeCondition | this_AchievementCondition_4= ruleAchievementCondition | this_MemoryCondition_5= ruleMemoryCondition )
            int alt24=6;
            switch ( input.LA(1) ) {
            case 46:
                {
                alt24=1;
                }
                break;
            case 47:
                {
                alt24=2;
                }
                break;
            case 45:
                {
                alt24=3;
                }
                break;
            case 48:
                {
                alt24=4;
                }
                break;
            case 44:
                {
                alt24=5;
                }
                break;
            case 49:
                {
                alt24=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // InternalScSl.g:1379:3: this_ObjectFrontCondition_0= ruleObjectFrontCondition
                    {

                    			newCompositeNode(grammarAccess.getConditionAccess().getObjectFrontConditionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ObjectFrontCondition_0=ruleObjectFrontCondition();

                    state._fsp--;


                    			current = this_ObjectFrontCondition_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalScSl.g:1388:3: this_ObjectRightCondition_1= ruleObjectRightCondition
                    {

                    			newCompositeNode(grammarAccess.getConditionAccess().getObjectRightConditionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ObjectRightCondition_1=ruleObjectRightCondition();

                    state._fsp--;


                    			current = this_ObjectRightCondition_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalScSl.g:1397:3: this_ColorCondition_2= ruleColorCondition
                    {

                    			newCompositeNode(grammarAccess.getConditionAccess().getColorConditionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ColorCondition_2=ruleColorCondition();

                    state._fsp--;


                    			current = this_ColorCondition_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalScSl.g:1406:3: this_TimeCondition_3= ruleTimeCondition
                    {

                    			newCompositeNode(grammarAccess.getConditionAccess().getTimeConditionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_TimeCondition_3=ruleTimeCondition();

                    state._fsp--;


                    			current = this_TimeCondition_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalScSl.g:1415:3: this_AchievementCondition_4= ruleAchievementCondition
                    {

                    			newCompositeNode(grammarAccess.getConditionAccess().getAchievementConditionParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_AchievementCondition_4=ruleAchievementCondition();

                    state._fsp--;


                    			current = this_AchievementCondition_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalScSl.g:1424:3: this_MemoryCondition_5= ruleMemoryCondition
                    {

                    			newCompositeNode(grammarAccess.getConditionAccess().getMemoryConditionParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_MemoryCondition_5=ruleMemoryCondition();

                    state._fsp--;


                    			current = this_MemoryCondition_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleColorCondition"
    // InternalScSl.g:1436:1: entryRuleColorCondition returns [EObject current=null] : iv_ruleColorCondition= ruleColorCondition EOF ;
    public final EObject entryRuleColorCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleColorCondition = null;


        try {
            // InternalScSl.g:1436:55: (iv_ruleColorCondition= ruleColorCondition EOF )
            // InternalScSl.g:1437:2: iv_ruleColorCondition= ruleColorCondition EOF
            {
             newCompositeNode(grammarAccess.getColorConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleColorCondition=ruleColorCondition();

            state._fsp--;

             current =iv_ruleColorCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleColorCondition"


    // $ANTLR start "ruleColorCondition"
    // InternalScSl.g:1443:1: ruleColorCondition returns [EObject current=null] : (otherlv_0= 'color' ( (lv_c_1_0= ruleColorDetection ) ) ) ;
    public final EObject ruleColorCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_c_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1449:2: ( (otherlv_0= 'color' ( (lv_c_1_0= ruleColorDetection ) ) ) )
            // InternalScSl.g:1450:2: (otherlv_0= 'color' ( (lv_c_1_0= ruleColorDetection ) ) )
            {
            // InternalScSl.g:1450:2: (otherlv_0= 'color' ( (lv_c_1_0= ruleColorDetection ) ) )
            // InternalScSl.g:1451:3: otherlv_0= 'color' ( (lv_c_1_0= ruleColorDetection ) )
            {
            otherlv_0=(Token)match(input,45,FOLLOW_39); 

            			newLeafNode(otherlv_0, grammarAccess.getColorConditionAccess().getColorKeyword_0());
            		
            // InternalScSl.g:1455:3: ( (lv_c_1_0= ruleColorDetection ) )
            // InternalScSl.g:1456:4: (lv_c_1_0= ruleColorDetection )
            {
            // InternalScSl.g:1456:4: (lv_c_1_0= ruleColorDetection )
            // InternalScSl.g:1457:5: lv_c_1_0= ruleColorDetection
            {

            					newCompositeNode(grammarAccess.getColorConditionAccess().getCColorDetectionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_c_1_0=ruleColorDetection();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getColorConditionRule());
            					}
            					set(
            						current,
            						"c",
            						lv_c_1_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.ColorDetection");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleColorCondition"


    // $ANTLR start "entryRuleObjectFrontCondition"
    // InternalScSl.g:1478:1: entryRuleObjectFrontCondition returns [EObject current=null] : iv_ruleObjectFrontCondition= ruleObjectFrontCondition EOF ;
    public final EObject entryRuleObjectFrontCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleObjectFrontCondition = null;


        try {
            // InternalScSl.g:1478:61: (iv_ruleObjectFrontCondition= ruleObjectFrontCondition EOF )
            // InternalScSl.g:1479:2: iv_ruleObjectFrontCondition= ruleObjectFrontCondition EOF
            {
             newCompositeNode(grammarAccess.getObjectFrontConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleObjectFrontCondition=ruleObjectFrontCondition();

            state._fsp--;

             current =iv_ruleObjectFrontCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleObjectFrontCondition"


    // $ANTLR start "ruleObjectFrontCondition"
    // InternalScSl.g:1485:1: ruleObjectFrontCondition returns [EObject current=null] : (otherlv_0= 'front' ( (lv_s_1_0= ruleObjectState ) ) ) ;
    public final EObject ruleObjectFrontCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Enumerator lv_s_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1491:2: ( (otherlv_0= 'front' ( (lv_s_1_0= ruleObjectState ) ) ) )
            // InternalScSl.g:1492:2: (otherlv_0= 'front' ( (lv_s_1_0= ruleObjectState ) ) )
            {
            // InternalScSl.g:1492:2: (otherlv_0= 'front' ( (lv_s_1_0= ruleObjectState ) ) )
            // InternalScSl.g:1493:3: otherlv_0= 'front' ( (lv_s_1_0= ruleObjectState ) )
            {
            otherlv_0=(Token)match(input,46,FOLLOW_40); 

            			newLeafNode(otherlv_0, grammarAccess.getObjectFrontConditionAccess().getFrontKeyword_0());
            		
            // InternalScSl.g:1497:3: ( (lv_s_1_0= ruleObjectState ) )
            // InternalScSl.g:1498:4: (lv_s_1_0= ruleObjectState )
            {
            // InternalScSl.g:1498:4: (lv_s_1_0= ruleObjectState )
            // InternalScSl.g:1499:5: lv_s_1_0= ruleObjectState
            {

            					newCompositeNode(grammarAccess.getObjectFrontConditionAccess().getSObjectStateEnumRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_s_1_0=ruleObjectState();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getObjectFrontConditionRule());
            					}
            					set(
            						current,
            						"s",
            						lv_s_1_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.ObjectState");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObjectFrontCondition"


    // $ANTLR start "entryRuleObjectRightCondition"
    // InternalScSl.g:1520:1: entryRuleObjectRightCondition returns [EObject current=null] : iv_ruleObjectRightCondition= ruleObjectRightCondition EOF ;
    public final EObject entryRuleObjectRightCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleObjectRightCondition = null;


        try {
            // InternalScSl.g:1520:61: (iv_ruleObjectRightCondition= ruleObjectRightCondition EOF )
            // InternalScSl.g:1521:2: iv_ruleObjectRightCondition= ruleObjectRightCondition EOF
            {
             newCompositeNode(grammarAccess.getObjectRightConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleObjectRightCondition=ruleObjectRightCondition();

            state._fsp--;

             current =iv_ruleObjectRightCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleObjectRightCondition"


    // $ANTLR start "ruleObjectRightCondition"
    // InternalScSl.g:1527:1: ruleObjectRightCondition returns [EObject current=null] : (otherlv_0= 'right' ( (lv_s_1_0= ruleObjectState ) ) ) ;
    public final EObject ruleObjectRightCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Enumerator lv_s_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1533:2: ( (otherlv_0= 'right' ( (lv_s_1_0= ruleObjectState ) ) ) )
            // InternalScSl.g:1534:2: (otherlv_0= 'right' ( (lv_s_1_0= ruleObjectState ) ) )
            {
            // InternalScSl.g:1534:2: (otherlv_0= 'right' ( (lv_s_1_0= ruleObjectState ) ) )
            // InternalScSl.g:1535:3: otherlv_0= 'right' ( (lv_s_1_0= ruleObjectState ) )
            {
            otherlv_0=(Token)match(input,47,FOLLOW_40); 

            			newLeafNode(otherlv_0, grammarAccess.getObjectRightConditionAccess().getRightKeyword_0());
            		
            // InternalScSl.g:1539:3: ( (lv_s_1_0= ruleObjectState ) )
            // InternalScSl.g:1540:4: (lv_s_1_0= ruleObjectState )
            {
            // InternalScSl.g:1540:4: (lv_s_1_0= ruleObjectState )
            // InternalScSl.g:1541:5: lv_s_1_0= ruleObjectState
            {

            					newCompositeNode(grammarAccess.getObjectRightConditionAccess().getSObjectStateEnumRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_s_1_0=ruleObjectState();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getObjectRightConditionRule());
            					}
            					set(
            						current,
            						"s",
            						lv_s_1_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.ObjectState");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObjectRightCondition"


    // $ANTLR start "entryRuleTimeCondition"
    // InternalScSl.g:1562:1: entryRuleTimeCondition returns [EObject current=null] : iv_ruleTimeCondition= ruleTimeCondition EOF ;
    public final EObject entryRuleTimeCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeCondition = null;


        try {
            // InternalScSl.g:1562:54: (iv_ruleTimeCondition= ruleTimeCondition EOF )
            // InternalScSl.g:1563:2: iv_ruleTimeCondition= ruleTimeCondition EOF
            {
             newCompositeNode(grammarAccess.getTimeConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTimeCondition=ruleTimeCondition();

            state._fsp--;

             current =iv_ruleTimeCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeCondition"


    // $ANTLR start "ruleTimeCondition"
    // InternalScSl.g:1569:1: ruleTimeCondition returns [EObject current=null] : (otherlv_0= 'time' ( (lv_t_1_0= RULE_INT ) ) otherlv_2= 'ms' ) ;
    public final EObject ruleTimeCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_t_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalScSl.g:1575:2: ( (otherlv_0= 'time' ( (lv_t_1_0= RULE_INT ) ) otherlv_2= 'ms' ) )
            // InternalScSl.g:1576:2: (otherlv_0= 'time' ( (lv_t_1_0= RULE_INT ) ) otherlv_2= 'ms' )
            {
            // InternalScSl.g:1576:2: (otherlv_0= 'time' ( (lv_t_1_0= RULE_INT ) ) otherlv_2= 'ms' )
            // InternalScSl.g:1577:3: otherlv_0= 'time' ( (lv_t_1_0= RULE_INT ) ) otherlv_2= 'ms'
            {
            otherlv_0=(Token)match(input,48,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getTimeConditionAccess().getTimeKeyword_0());
            		
            // InternalScSl.g:1581:3: ( (lv_t_1_0= RULE_INT ) )
            // InternalScSl.g:1582:4: (lv_t_1_0= RULE_INT )
            {
            // InternalScSl.g:1582:4: (lv_t_1_0= RULE_INT )
            // InternalScSl.g:1583:5: lv_t_1_0= RULE_INT
            {
            lv_t_1_0=(Token)match(input,RULE_INT,FOLLOW_37); 

            					newLeafNode(lv_t_1_0, grammarAccess.getTimeConditionAccess().getTINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimeConditionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"t",
            						lv_t_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_2=(Token)match(input,43,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getTimeConditionAccess().getMsKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeCondition"


    // $ANTLR start "entryRuleAchievementCondition"
    // InternalScSl.g:1607:1: entryRuleAchievementCondition returns [EObject current=null] : iv_ruleAchievementCondition= ruleAchievementCondition EOF ;
    public final EObject entryRuleAchievementCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAchievementCondition = null;


        try {
            // InternalScSl.g:1607:61: (iv_ruleAchievementCondition= ruleAchievementCondition EOF )
            // InternalScSl.g:1608:2: iv_ruleAchievementCondition= ruleAchievementCondition EOF
            {
             newCompositeNode(grammarAccess.getAchievementConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAchievementCondition=ruleAchievementCondition();

            state._fsp--;

             current =iv_ruleAchievementCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAchievementCondition"


    // $ANTLR start "ruleAchievementCondition"
    // InternalScSl.g:1614:1: ruleAchievementCondition returns [EObject current=null] : (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) ) ;
    public final EObject ruleAchievementCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_a_1_0=null;


        	enterRule();

        try {
            // InternalScSl.g:1620:2: ( (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) ) )
            // InternalScSl.g:1621:2: (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) )
            {
            // InternalScSl.g:1621:2: (otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) ) )
            // InternalScSl.g:1622:3: otherlv_0= 'achievement' ( (lv_a_1_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,44,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getAchievementConditionAccess().getAchievementKeyword_0());
            		
            // InternalScSl.g:1626:3: ( (lv_a_1_0= RULE_INT ) )
            // InternalScSl.g:1627:4: (lv_a_1_0= RULE_INT )
            {
            // InternalScSl.g:1627:4: (lv_a_1_0= RULE_INT )
            // InternalScSl.g:1628:5: lv_a_1_0= RULE_INT
            {
            lv_a_1_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_a_1_0, grammarAccess.getAchievementConditionAccess().getAINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAchievementConditionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"a",
            						lv_a_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAchievementCondition"


    // $ANTLR start "entryRuleMemoryCondition"
    // InternalScSl.g:1648:1: entryRuleMemoryCondition returns [EObject current=null] : iv_ruleMemoryCondition= ruleMemoryCondition EOF ;
    public final EObject entryRuleMemoryCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMemoryCondition = null;


        try {
            // InternalScSl.g:1648:56: (iv_ruleMemoryCondition= ruleMemoryCondition EOF )
            // InternalScSl.g:1649:2: iv_ruleMemoryCondition= ruleMemoryCondition EOF
            {
             newCompositeNode(grammarAccess.getMemoryConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMemoryCondition=ruleMemoryCondition();

            state._fsp--;

             current =iv_ruleMemoryCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMemoryCondition"


    // $ANTLR start "ruleMemoryCondition"
    // InternalScSl.g:1655:1: ruleMemoryCondition returns [EObject current=null] : ( (otherlv_0= 'memory' ( (lv_c_1_0= ruleColorCondition ) ) ) | (otherlv_2= 'memory' ( (lv_c_3_0= ruleObjectFrontCondition ) ) ) | (otherlv_4= 'memory' ( (lv_c_5_0= ruleObjectRightCondition ) ) ) ) ;
    public final EObject ruleMemoryCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_c_1_0 = null;

        EObject lv_c_3_0 = null;

        EObject lv_c_5_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1661:2: ( ( (otherlv_0= 'memory' ( (lv_c_1_0= ruleColorCondition ) ) ) | (otherlv_2= 'memory' ( (lv_c_3_0= ruleObjectFrontCondition ) ) ) | (otherlv_4= 'memory' ( (lv_c_5_0= ruleObjectRightCondition ) ) ) ) )
            // InternalScSl.g:1662:2: ( (otherlv_0= 'memory' ( (lv_c_1_0= ruleColorCondition ) ) ) | (otherlv_2= 'memory' ( (lv_c_3_0= ruleObjectFrontCondition ) ) ) | (otherlv_4= 'memory' ( (lv_c_5_0= ruleObjectRightCondition ) ) ) )
            {
            // InternalScSl.g:1662:2: ( (otherlv_0= 'memory' ( (lv_c_1_0= ruleColorCondition ) ) ) | (otherlv_2= 'memory' ( (lv_c_3_0= ruleObjectFrontCondition ) ) ) | (otherlv_4= 'memory' ( (lv_c_5_0= ruleObjectRightCondition ) ) ) )
            int alt25=3;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==49) ) {
                switch ( input.LA(2) ) {
                case 47:
                    {
                    alt25=3;
                    }
                    break;
                case 46:
                    {
                    alt25=2;
                    }
                    break;
                case 45:
                    {
                    alt25=1;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 25, 1, input);

                    throw nvae;
                }

            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // InternalScSl.g:1663:3: (otherlv_0= 'memory' ( (lv_c_1_0= ruleColorCondition ) ) )
                    {
                    // InternalScSl.g:1663:3: (otherlv_0= 'memory' ( (lv_c_1_0= ruleColorCondition ) ) )
                    // InternalScSl.g:1664:4: otherlv_0= 'memory' ( (lv_c_1_0= ruleColorCondition ) )
                    {
                    otherlv_0=(Token)match(input,49,FOLLOW_41); 

                    				newLeafNode(otherlv_0, grammarAccess.getMemoryConditionAccess().getMemoryKeyword_0_0());
                    			
                    // InternalScSl.g:1668:4: ( (lv_c_1_0= ruleColorCondition ) )
                    // InternalScSl.g:1669:5: (lv_c_1_0= ruleColorCondition )
                    {
                    // InternalScSl.g:1669:5: (lv_c_1_0= ruleColorCondition )
                    // InternalScSl.g:1670:6: lv_c_1_0= ruleColorCondition
                    {

                    						newCompositeNode(grammarAccess.getMemoryConditionAccess().getCColorConditionParserRuleCall_0_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_c_1_0=ruleColorCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryConditionRule());
                    						}
                    						set(
                    							current,
                    							"c",
                    							lv_c_1_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.ColorCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1689:3: (otherlv_2= 'memory' ( (lv_c_3_0= ruleObjectFrontCondition ) ) )
                    {
                    // InternalScSl.g:1689:3: (otherlv_2= 'memory' ( (lv_c_3_0= ruleObjectFrontCondition ) ) )
                    // InternalScSl.g:1690:4: otherlv_2= 'memory' ( (lv_c_3_0= ruleObjectFrontCondition ) )
                    {
                    otherlv_2=(Token)match(input,49,FOLLOW_42); 

                    				newLeafNode(otherlv_2, grammarAccess.getMemoryConditionAccess().getMemoryKeyword_1_0());
                    			
                    // InternalScSl.g:1694:4: ( (lv_c_3_0= ruleObjectFrontCondition ) )
                    // InternalScSl.g:1695:5: (lv_c_3_0= ruleObjectFrontCondition )
                    {
                    // InternalScSl.g:1695:5: (lv_c_3_0= ruleObjectFrontCondition )
                    // InternalScSl.g:1696:6: lv_c_3_0= ruleObjectFrontCondition
                    {

                    						newCompositeNode(grammarAccess.getMemoryConditionAccess().getCObjectFrontConditionParserRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_c_3_0=ruleObjectFrontCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryConditionRule());
                    						}
                    						set(
                    							current,
                    							"c",
                    							lv_c_3_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.ObjectFrontCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalScSl.g:1715:3: (otherlv_4= 'memory' ( (lv_c_5_0= ruleObjectRightCondition ) ) )
                    {
                    // InternalScSl.g:1715:3: (otherlv_4= 'memory' ( (lv_c_5_0= ruleObjectRightCondition ) ) )
                    // InternalScSl.g:1716:4: otherlv_4= 'memory' ( (lv_c_5_0= ruleObjectRightCondition ) )
                    {
                    otherlv_4=(Token)match(input,49,FOLLOW_43); 

                    				newLeafNode(otherlv_4, grammarAccess.getMemoryConditionAccess().getMemoryKeyword_2_0());
                    			
                    // InternalScSl.g:1720:4: ( (lv_c_5_0= ruleObjectRightCondition ) )
                    // InternalScSl.g:1721:5: (lv_c_5_0= ruleObjectRightCondition )
                    {
                    // InternalScSl.g:1721:5: (lv_c_5_0= ruleObjectRightCondition )
                    // InternalScSl.g:1722:6: lv_c_5_0= ruleObjectRightCondition
                    {

                    						newCompositeNode(grammarAccess.getMemoryConditionAccess().getCObjectRightConditionParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_c_5_0=ruleObjectRightCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryConditionRule());
                    						}
                    						set(
                    							current,
                    							"c",
                    							lv_c_5_0,
                    							"vlad.xtextt.smartCar.scsl.ScSl.ObjectRightCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMemoryCondition"


    // $ANTLR start "entryRuleColorDetection"
    // InternalScSl.g:1744:1: entryRuleColorDetection returns [EObject current=null] : iv_ruleColorDetection= ruleColorDetection EOF ;
    public final EObject entryRuleColorDetection() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleColorDetection = null;


        try {
            // InternalScSl.g:1744:55: (iv_ruleColorDetection= ruleColorDetection EOF )
            // InternalScSl.g:1745:2: iv_ruleColorDetection= ruleColorDetection EOF
            {
             newCompositeNode(grammarAccess.getColorDetectionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleColorDetection=ruleColorDetection();

            state._fsp--;

             current =iv_ruleColorDetection; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleColorDetection"


    // $ANTLR start "ruleColorDetection"
    // InternalScSl.g:1751:1: ruleColorDetection returns [EObject current=null] : ( ( (lv_sensor_0_0= ruleColorSensor ) ) ( (lv_color_1_0= ruleColor ) ) ) ;
    public final EObject ruleColorDetection() throws RecognitionException {
        EObject current = null;

        Enumerator lv_sensor_0_0 = null;

        Enumerator lv_color_1_0 = null;



        	enterRule();

        try {
            // InternalScSl.g:1757:2: ( ( ( (lv_sensor_0_0= ruleColorSensor ) ) ( (lv_color_1_0= ruleColor ) ) ) )
            // InternalScSl.g:1758:2: ( ( (lv_sensor_0_0= ruleColorSensor ) ) ( (lv_color_1_0= ruleColor ) ) )
            {
            // InternalScSl.g:1758:2: ( ( (lv_sensor_0_0= ruleColorSensor ) ) ( (lv_color_1_0= ruleColor ) ) )
            // InternalScSl.g:1759:3: ( (lv_sensor_0_0= ruleColorSensor ) ) ( (lv_color_1_0= ruleColor ) )
            {
            // InternalScSl.g:1759:3: ( (lv_sensor_0_0= ruleColorSensor ) )
            // InternalScSl.g:1760:4: (lv_sensor_0_0= ruleColorSensor )
            {
            // InternalScSl.g:1760:4: (lv_sensor_0_0= ruleColorSensor )
            // InternalScSl.g:1761:5: lv_sensor_0_0= ruleColorSensor
            {

            					newCompositeNode(grammarAccess.getColorDetectionAccess().getSensorColorSensorEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_44);
            lv_sensor_0_0=ruleColorSensor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getColorDetectionRule());
            					}
            					set(
            						current,
            						"sensor",
            						lv_sensor_0_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.ColorSensor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalScSl.g:1778:3: ( (lv_color_1_0= ruleColor ) )
            // InternalScSl.g:1779:4: (lv_color_1_0= ruleColor )
            {
            // InternalScSl.g:1779:4: (lv_color_1_0= ruleColor )
            // InternalScSl.g:1780:5: lv_color_1_0= ruleColor
            {

            					newCompositeNode(grammarAccess.getColorDetectionAccess().getColorColorEnumRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_color_1_0=ruleColor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getColorDetectionRule());
            					}
            					set(
            						current,
            						"color",
            						lv_color_1_0,
            						"vlad.xtextt.smartCar.scsl.ScSl.Color");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleColorDetection"


    // $ANTLR start "ruleDriveDirection"
    // InternalScSl.g:1801:1: ruleDriveDirection returns [Enumerator current=null] : ( (enumLiteral_0= 'forward' ) | (enumLiteral_1= 'back' ) ) ;
    public final Enumerator ruleDriveDirection() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalScSl.g:1807:2: ( ( (enumLiteral_0= 'forward' ) | (enumLiteral_1= 'back' ) ) )
            // InternalScSl.g:1808:2: ( (enumLiteral_0= 'forward' ) | (enumLiteral_1= 'back' ) )
            {
            // InternalScSl.g:1808:2: ( (enumLiteral_0= 'forward' ) | (enumLiteral_1= 'back' ) )
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==50) ) {
                alt26=1;
            }
            else if ( (LA26_0==51) ) {
                alt26=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }
            switch (alt26) {
                case 1 :
                    // InternalScSl.g:1809:3: (enumLiteral_0= 'forward' )
                    {
                    // InternalScSl.g:1809:3: (enumLiteral_0= 'forward' )
                    // InternalScSl.g:1810:4: enumLiteral_0= 'forward'
                    {
                    enumLiteral_0=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getDriveDirectionAccess().getFORWARDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getDriveDirectionAccess().getFORWARDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1817:3: (enumLiteral_1= 'back' )
                    {
                    // InternalScSl.g:1817:3: (enumLiteral_1= 'back' )
                    // InternalScSl.g:1818:4: enumLiteral_1= 'back'
                    {
                    enumLiteral_1=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getDriveDirectionAccess().getBACKEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getDriveDirectionAccess().getBACKEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDriveDirection"


    // $ANTLR start "ruleTurnDirection"
    // InternalScSl.g:1828:1: ruleTurnDirection returns [Enumerator current=null] : ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) ) ;
    public final Enumerator ruleTurnDirection() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalScSl.g:1834:2: ( ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) ) )
            // InternalScSl.g:1835:2: ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) )
            {
            // InternalScSl.g:1835:2: ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) )
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==52) ) {
                alt27=1;
            }
            else if ( (LA27_0==47) ) {
                alt27=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 27, 0, input);

                throw nvae;
            }
            switch (alt27) {
                case 1 :
                    // InternalScSl.g:1836:3: (enumLiteral_0= 'left' )
                    {
                    // InternalScSl.g:1836:3: (enumLiteral_0= 'left' )
                    // InternalScSl.g:1837:4: enumLiteral_0= 'left'
                    {
                    enumLiteral_0=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getTurnDirectionAccess().getLEFTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTurnDirectionAccess().getLEFTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1844:3: (enumLiteral_1= 'right' )
                    {
                    // InternalScSl.g:1844:3: (enumLiteral_1= 'right' )
                    // InternalScSl.g:1845:4: enumLiteral_1= 'right'
                    {
                    enumLiteral_1=(Token)match(input,47,FOLLOW_2); 

                    				current = grammarAccess.getTurnDirectionAccess().getRIGHTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTurnDirectionAccess().getRIGHTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTurnDirection"


    // $ANTLR start "ruleObjectState"
    // InternalScSl.g:1855:1: ruleObjectState returns [Enumerator current=null] : ( (enumLiteral_0= 'close' ) | (enumLiteral_1= 'none' ) ) ;
    public final Enumerator ruleObjectState() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalScSl.g:1861:2: ( ( (enumLiteral_0= 'close' ) | (enumLiteral_1= 'none' ) ) )
            // InternalScSl.g:1862:2: ( (enumLiteral_0= 'close' ) | (enumLiteral_1= 'none' ) )
            {
            // InternalScSl.g:1862:2: ( (enumLiteral_0= 'close' ) | (enumLiteral_1= 'none' ) )
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==53) ) {
                alt28=1;
            }
            else if ( (LA28_0==54) ) {
                alt28=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }
            switch (alt28) {
                case 1 :
                    // InternalScSl.g:1863:3: (enumLiteral_0= 'close' )
                    {
                    // InternalScSl.g:1863:3: (enumLiteral_0= 'close' )
                    // InternalScSl.g:1864:4: enumLiteral_0= 'close'
                    {
                    enumLiteral_0=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getObjectStateAccess().getCLOSEEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getObjectStateAccess().getCLOSEEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1871:3: (enumLiteral_1= 'none' )
                    {
                    // InternalScSl.g:1871:3: (enumLiteral_1= 'none' )
                    // InternalScSl.g:1872:4: enumLiteral_1= 'none'
                    {
                    enumLiteral_1=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getObjectStateAccess().getNONEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getObjectStateAccess().getNONEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObjectState"


    // $ANTLR start "ruleColor"
    // InternalScSl.g:1882:1: ruleColor returns [Enumerator current=null] : ( (enumLiteral_0= 'black' ) | (enumLiteral_1= 'white' ) ) ;
    public final Enumerator ruleColor() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalScSl.g:1888:2: ( ( (enumLiteral_0= 'black' ) | (enumLiteral_1= 'white' ) ) )
            // InternalScSl.g:1889:2: ( (enumLiteral_0= 'black' ) | (enumLiteral_1= 'white' ) )
            {
            // InternalScSl.g:1889:2: ( (enumLiteral_0= 'black' ) | (enumLiteral_1= 'white' ) )
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==55) ) {
                alt29=1;
            }
            else if ( (LA29_0==56) ) {
                alt29=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }
            switch (alt29) {
                case 1 :
                    // InternalScSl.g:1890:3: (enumLiteral_0= 'black' )
                    {
                    // InternalScSl.g:1890:3: (enumLiteral_0= 'black' )
                    // InternalScSl.g:1891:4: enumLiteral_0= 'black'
                    {
                    enumLiteral_0=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getColorAccess().getBLACKEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getColorAccess().getBLACKEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1898:3: (enumLiteral_1= 'white' )
                    {
                    // InternalScSl.g:1898:3: (enumLiteral_1= 'white' )
                    // InternalScSl.g:1899:4: enumLiteral_1= 'white'
                    {
                    enumLiteral_1=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getColorAccess().getWHITEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getColorAccess().getWHITEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleColor"


    // $ANTLR start "ruleColorSensor"
    // InternalScSl.g:1909:1: ruleColorSensor returns [Enumerator current=null] : ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) | (enumLiteral_2= 'any' ) ) ;
    public final Enumerator ruleColorSensor() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalScSl.g:1915:2: ( ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) | (enumLiteral_2= 'any' ) ) )
            // InternalScSl.g:1916:2: ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) | (enumLiteral_2= 'any' ) )
            {
            // InternalScSl.g:1916:2: ( (enumLiteral_0= 'left' ) | (enumLiteral_1= 'right' ) | (enumLiteral_2= 'any' ) )
            int alt30=3;
            switch ( input.LA(1) ) {
            case 52:
                {
                alt30=1;
                }
                break;
            case 47:
                {
                alt30=2;
                }
                break;
            case 57:
                {
                alt30=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }

            switch (alt30) {
                case 1 :
                    // InternalScSl.g:1917:3: (enumLiteral_0= 'left' )
                    {
                    // InternalScSl.g:1917:3: (enumLiteral_0= 'left' )
                    // InternalScSl.g:1918:4: enumLiteral_0= 'left'
                    {
                    enumLiteral_0=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getColorSensorAccess().getLEFTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getColorSensorAccess().getLEFTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1925:3: (enumLiteral_1= 'right' )
                    {
                    // InternalScSl.g:1925:3: (enumLiteral_1= 'right' )
                    // InternalScSl.g:1926:4: enumLiteral_1= 'right'
                    {
                    enumLiteral_1=(Token)match(input,47,FOLLOW_2); 

                    				current = grammarAccess.getColorSensorAccess().getRIGHTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getColorSensorAccess().getRIGHTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalScSl.g:1933:3: (enumLiteral_2= 'any' )
                    {
                    // InternalScSl.g:1933:3: (enumLiteral_2= 'any' )
                    // InternalScSl.g:1934:4: enumLiteral_2= 'any'
                    {
                    enumLiteral_2=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getColorSensorAccess().getANYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getColorSensorAccess().getANYEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleColorSensor"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000020001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000020001020L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000000203FF000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000000003FC000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x00000000003F8000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000000003F0000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x00000000003E0000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x00000000003C0000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000380000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000300000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x000000FEC0000002L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x000000FE80000002L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x000000FE00000002L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0003F00000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0003F00000000002L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0010800000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000100000002L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0210800000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0060000000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0180000000000000L});

}