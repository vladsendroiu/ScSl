package vlad.xtextt.smartCar.scsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import vlad.xtextt.smartCar.scsl.services.ScSlGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalScSlParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'forward'", "'back'", "'left'", "'right'", "'close'", "'none'", "'black'", "'white'", "'any'", "'Mission'", "'Tasks'", "'Achievements'", "'Drive_speed'", "'Turn_speed'", "'Sensor_distance_front'", "'Sensor_distance_right'", "'Sensor_color_left'", "'Sensor_color_right'", "'Motor_left_pins'", "'Motor_right_pins'", "'Trigger_Pin'", "'Echo_Pin'", "'Pin'", "'Input1_pin'", "'Input2_pin'", "'Task'", "'priority'", "'Goal'", "'Start_if'", "'Stop_when'", "'until'", "'Drive'", "'Turn'", "'Wait'", "'Mark'", "'Clear'", "'Show'", "'Play'", "'message'", "'note'", "'for'", "'ms'", "'achievement'", "'color'", "'front'", "'time'", "'memory'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalScSlParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalScSlParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalScSlParser.tokenNames; }
    public String getGrammarFileName() { return "InternalScSl.g"; }


    	private ScSlGrammarAccess grammarAccess;

    	public void setGrammarAccess(ScSlGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleMission"
    // InternalScSl.g:53:1: entryRuleMission : ruleMission EOF ;
    public final void entryRuleMission() throws RecognitionException {
        try {
            // InternalScSl.g:54:1: ( ruleMission EOF )
            // InternalScSl.g:55:1: ruleMission EOF
            {
             before(grammarAccess.getMissionRule()); 
            pushFollow(FOLLOW_1);
            ruleMission();

            state._fsp--;

             after(grammarAccess.getMissionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMission"


    // $ANTLR start "ruleMission"
    // InternalScSl.g:62:1: ruleMission : ( ( rule__Mission__Group__0 ) ) ;
    public final void ruleMission() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:66:2: ( ( ( rule__Mission__Group__0 ) ) )
            // InternalScSl.g:67:2: ( ( rule__Mission__Group__0 ) )
            {
            // InternalScSl.g:67:2: ( ( rule__Mission__Group__0 ) )
            // InternalScSl.g:68:3: ( rule__Mission__Group__0 )
            {
             before(grammarAccess.getMissionAccess().getGroup()); 
            // InternalScSl.g:69:3: ( rule__Mission__Group__0 )
            // InternalScSl.g:69:4: rule__Mission__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMission"


    // $ANTLR start "entryRuleSpeed"
    // InternalScSl.g:78:1: entryRuleSpeed : ruleSpeed EOF ;
    public final void entryRuleSpeed() throws RecognitionException {
        try {
            // InternalScSl.g:79:1: ( ruleSpeed EOF )
            // InternalScSl.g:80:1: ruleSpeed EOF
            {
             before(grammarAccess.getSpeedRule()); 
            pushFollow(FOLLOW_1);
            ruleSpeed();

            state._fsp--;

             after(grammarAccess.getSpeedRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSpeed"


    // $ANTLR start "ruleSpeed"
    // InternalScSl.g:87:1: ruleSpeed : ( ( rule__Speed__SAssignment ) ) ;
    public final void ruleSpeed() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:91:2: ( ( ( rule__Speed__SAssignment ) ) )
            // InternalScSl.g:92:2: ( ( rule__Speed__SAssignment ) )
            {
            // InternalScSl.g:92:2: ( ( rule__Speed__SAssignment ) )
            // InternalScSl.g:93:3: ( rule__Speed__SAssignment )
            {
             before(grammarAccess.getSpeedAccess().getSAssignment()); 
            // InternalScSl.g:94:3: ( rule__Speed__SAssignment )
            // InternalScSl.g:94:4: rule__Speed__SAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Speed__SAssignment();

            state._fsp--;


            }

             after(grammarAccess.getSpeedAccess().getSAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSpeed"


    // $ANTLR start "entryRuleDistance_Pins"
    // InternalScSl.g:103:1: entryRuleDistance_Pins : ruleDistance_Pins EOF ;
    public final void entryRuleDistance_Pins() throws RecognitionException {
        try {
            // InternalScSl.g:104:1: ( ruleDistance_Pins EOF )
            // InternalScSl.g:105:1: ruleDistance_Pins EOF
            {
             before(grammarAccess.getDistance_PinsRule()); 
            pushFollow(FOLLOW_1);
            ruleDistance_Pins();

            state._fsp--;

             after(grammarAccess.getDistance_PinsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDistance_Pins"


    // $ANTLR start "ruleDistance_Pins"
    // InternalScSl.g:112:1: ruleDistance_Pins : ( ( rule__Distance_Pins__Group__0 ) ) ;
    public final void ruleDistance_Pins() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:116:2: ( ( ( rule__Distance_Pins__Group__0 ) ) )
            // InternalScSl.g:117:2: ( ( rule__Distance_Pins__Group__0 ) )
            {
            // InternalScSl.g:117:2: ( ( rule__Distance_Pins__Group__0 ) )
            // InternalScSl.g:118:3: ( rule__Distance_Pins__Group__0 )
            {
             before(grammarAccess.getDistance_PinsAccess().getGroup()); 
            // InternalScSl.g:119:3: ( rule__Distance_Pins__Group__0 )
            // InternalScSl.g:119:4: rule__Distance_Pins__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Distance_Pins__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDistance_PinsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDistance_Pins"


    // $ANTLR start "entryRuleColor_Pin"
    // InternalScSl.g:128:1: entryRuleColor_Pin : ruleColor_Pin EOF ;
    public final void entryRuleColor_Pin() throws RecognitionException {
        try {
            // InternalScSl.g:129:1: ( ruleColor_Pin EOF )
            // InternalScSl.g:130:1: ruleColor_Pin EOF
            {
             before(grammarAccess.getColor_PinRule()); 
            pushFollow(FOLLOW_1);
            ruleColor_Pin();

            state._fsp--;

             after(grammarAccess.getColor_PinRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleColor_Pin"


    // $ANTLR start "ruleColor_Pin"
    // InternalScSl.g:137:1: ruleColor_Pin : ( ( rule__Color_Pin__Group__0 ) ) ;
    public final void ruleColor_Pin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:141:2: ( ( ( rule__Color_Pin__Group__0 ) ) )
            // InternalScSl.g:142:2: ( ( rule__Color_Pin__Group__0 ) )
            {
            // InternalScSl.g:142:2: ( ( rule__Color_Pin__Group__0 ) )
            // InternalScSl.g:143:3: ( rule__Color_Pin__Group__0 )
            {
             before(grammarAccess.getColor_PinAccess().getGroup()); 
            // InternalScSl.g:144:3: ( rule__Color_Pin__Group__0 )
            // InternalScSl.g:144:4: rule__Color_Pin__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Color_Pin__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getColor_PinAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleColor_Pin"


    // $ANTLR start "entryRuleMotor_Pins"
    // InternalScSl.g:153:1: entryRuleMotor_Pins : ruleMotor_Pins EOF ;
    public final void entryRuleMotor_Pins() throws RecognitionException {
        try {
            // InternalScSl.g:154:1: ( ruleMotor_Pins EOF )
            // InternalScSl.g:155:1: ruleMotor_Pins EOF
            {
             before(grammarAccess.getMotor_PinsRule()); 
            pushFollow(FOLLOW_1);
            ruleMotor_Pins();

            state._fsp--;

             after(grammarAccess.getMotor_PinsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMotor_Pins"


    // $ANTLR start "ruleMotor_Pins"
    // InternalScSl.g:162:1: ruleMotor_Pins : ( ( rule__Motor_Pins__Group__0 ) ) ;
    public final void ruleMotor_Pins() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:166:2: ( ( ( rule__Motor_Pins__Group__0 ) ) )
            // InternalScSl.g:167:2: ( ( rule__Motor_Pins__Group__0 ) )
            {
            // InternalScSl.g:167:2: ( ( rule__Motor_Pins__Group__0 ) )
            // InternalScSl.g:168:3: ( rule__Motor_Pins__Group__0 )
            {
             before(grammarAccess.getMotor_PinsAccess().getGroup()); 
            // InternalScSl.g:169:3: ( rule__Motor_Pins__Group__0 )
            // InternalScSl.g:169:4: rule__Motor_Pins__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Motor_Pins__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMotor_PinsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMotor_Pins"


    // $ANTLR start "entryRulePind"
    // InternalScSl.g:178:1: entryRulePind : rulePind EOF ;
    public final void entryRulePind() throws RecognitionException {
        try {
            // InternalScSl.g:179:1: ( rulePind EOF )
            // InternalScSl.g:180:1: rulePind EOF
            {
             before(grammarAccess.getPindRule()); 
            pushFollow(FOLLOW_1);
            rulePind();

            state._fsp--;

             after(grammarAccess.getPindRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePind"


    // $ANTLR start "rulePind"
    // InternalScSl.g:187:1: rulePind : ( ( rule__Pind__PinAssignment ) ) ;
    public final void rulePind() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:191:2: ( ( ( rule__Pind__PinAssignment ) ) )
            // InternalScSl.g:192:2: ( ( rule__Pind__PinAssignment ) )
            {
            // InternalScSl.g:192:2: ( ( rule__Pind__PinAssignment ) )
            // InternalScSl.g:193:3: ( rule__Pind__PinAssignment )
            {
             before(grammarAccess.getPindAccess().getPinAssignment()); 
            // InternalScSl.g:194:3: ( rule__Pind__PinAssignment )
            // InternalScSl.g:194:4: rule__Pind__PinAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Pind__PinAssignment();

            state._fsp--;


            }

             after(grammarAccess.getPindAccess().getPinAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePind"


    // $ANTLR start "entryRuleTask"
    // InternalScSl.g:203:1: entryRuleTask : ruleTask EOF ;
    public final void entryRuleTask() throws RecognitionException {
        try {
            // InternalScSl.g:204:1: ( ruleTask EOF )
            // InternalScSl.g:205:1: ruleTask EOF
            {
             before(grammarAccess.getTaskRule()); 
            pushFollow(FOLLOW_1);
            ruleTask();

            state._fsp--;

             after(grammarAccess.getTaskRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTask"


    // $ANTLR start "ruleTask"
    // InternalScSl.g:212:1: ruleTask : ( ( rule__Task__Group__0 ) ) ;
    public final void ruleTask() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:216:2: ( ( ( rule__Task__Group__0 ) ) )
            // InternalScSl.g:217:2: ( ( rule__Task__Group__0 ) )
            {
            // InternalScSl.g:217:2: ( ( rule__Task__Group__0 ) )
            // InternalScSl.g:218:3: ( rule__Task__Group__0 )
            {
             before(grammarAccess.getTaskAccess().getGroup()); 
            // InternalScSl.g:219:3: ( rule__Task__Group__0 )
            // InternalScSl.g:219:4: rule__Task__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Task__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTaskAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTask"


    // $ANTLR start "entryRuleGoal"
    // InternalScSl.g:228:1: entryRuleGoal : ruleGoal EOF ;
    public final void entryRuleGoal() throws RecognitionException {
        try {
            // InternalScSl.g:229:1: ( ruleGoal EOF )
            // InternalScSl.g:230:1: ruleGoal EOF
            {
             before(grammarAccess.getGoalRule()); 
            pushFollow(FOLLOW_1);
            ruleGoal();

            state._fsp--;

             after(grammarAccess.getGoalRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGoal"


    // $ANTLR start "ruleGoal"
    // InternalScSl.g:237:1: ruleGoal : ( ( rule__Goal__Group__0 ) ) ;
    public final void ruleGoal() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:241:2: ( ( ( rule__Goal__Group__0 ) ) )
            // InternalScSl.g:242:2: ( ( rule__Goal__Group__0 ) )
            {
            // InternalScSl.g:242:2: ( ( rule__Goal__Group__0 ) )
            // InternalScSl.g:243:3: ( rule__Goal__Group__0 )
            {
             before(grammarAccess.getGoalAccess().getGroup()); 
            // InternalScSl.g:244:3: ( rule__Goal__Group__0 )
            // InternalScSl.g:244:4: rule__Goal__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Goal__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGoalAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGoal"


    // $ANTLR start "entryRuleStartingCondition"
    // InternalScSl.g:253:1: entryRuleStartingCondition : ruleStartingCondition EOF ;
    public final void entryRuleStartingCondition() throws RecognitionException {
        try {
            // InternalScSl.g:254:1: ( ruleStartingCondition EOF )
            // InternalScSl.g:255:1: ruleStartingCondition EOF
            {
             before(grammarAccess.getStartingConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleStartingCondition();

            state._fsp--;

             after(grammarAccess.getStartingConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStartingCondition"


    // $ANTLR start "ruleStartingCondition"
    // InternalScSl.g:262:1: ruleStartingCondition : ( ( rule__StartingCondition__Group__0 ) ) ;
    public final void ruleStartingCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:266:2: ( ( ( rule__StartingCondition__Group__0 ) ) )
            // InternalScSl.g:267:2: ( ( rule__StartingCondition__Group__0 ) )
            {
            // InternalScSl.g:267:2: ( ( rule__StartingCondition__Group__0 ) )
            // InternalScSl.g:268:3: ( rule__StartingCondition__Group__0 )
            {
             before(grammarAccess.getStartingConditionAccess().getGroup()); 
            // InternalScSl.g:269:3: ( rule__StartingCondition__Group__0 )
            // InternalScSl.g:269:4: rule__StartingCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__StartingCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStartingConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStartingCondition"


    // $ANTLR start "entryRuleStoppingCondition"
    // InternalScSl.g:278:1: entryRuleStoppingCondition : ruleStoppingCondition EOF ;
    public final void entryRuleStoppingCondition() throws RecognitionException {
        try {
            // InternalScSl.g:279:1: ( ruleStoppingCondition EOF )
            // InternalScSl.g:280:1: ruleStoppingCondition EOF
            {
             before(grammarAccess.getStoppingConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleStoppingCondition();

            state._fsp--;

             after(grammarAccess.getStoppingConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStoppingCondition"


    // $ANTLR start "ruleStoppingCondition"
    // InternalScSl.g:287:1: ruleStoppingCondition : ( ( rule__StoppingCondition__Group__0 ) ) ;
    public final void ruleStoppingCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:291:2: ( ( ( rule__StoppingCondition__Group__0 ) ) )
            // InternalScSl.g:292:2: ( ( rule__StoppingCondition__Group__0 ) )
            {
            // InternalScSl.g:292:2: ( ( rule__StoppingCondition__Group__0 ) )
            // InternalScSl.g:293:3: ( rule__StoppingCondition__Group__0 )
            {
             before(grammarAccess.getStoppingConditionAccess().getGroup()); 
            // InternalScSl.g:294:3: ( rule__StoppingCondition__Group__0 )
            // InternalScSl.g:294:4: rule__StoppingCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__StoppingCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStoppingConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStoppingCondition"


    // $ANTLR start "entryRuleUntilCondition"
    // InternalScSl.g:303:1: entryRuleUntilCondition : ruleUntilCondition EOF ;
    public final void entryRuleUntilCondition() throws RecognitionException {
        try {
            // InternalScSl.g:304:1: ( ruleUntilCondition EOF )
            // InternalScSl.g:305:1: ruleUntilCondition EOF
            {
             before(grammarAccess.getUntilConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleUntilCondition();

            state._fsp--;

             after(grammarAccess.getUntilConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUntilCondition"


    // $ANTLR start "ruleUntilCondition"
    // InternalScSl.g:312:1: ruleUntilCondition : ( ( rule__UntilCondition__Group__0 ) ) ;
    public final void ruleUntilCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:316:2: ( ( ( rule__UntilCondition__Group__0 ) ) )
            // InternalScSl.g:317:2: ( ( rule__UntilCondition__Group__0 ) )
            {
            // InternalScSl.g:317:2: ( ( rule__UntilCondition__Group__0 ) )
            // InternalScSl.g:318:3: ( rule__UntilCondition__Group__0 )
            {
             before(grammarAccess.getUntilConditionAccess().getGroup()); 
            // InternalScSl.g:319:3: ( rule__UntilCondition__Group__0 )
            // InternalScSl.g:319:4: rule__UntilCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__UntilCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUntilConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUntilCondition"


    // $ANTLR start "entryRuleAction"
    // InternalScSl.g:328:1: entryRuleAction : ruleAction EOF ;
    public final void entryRuleAction() throws RecognitionException {
        try {
            // InternalScSl.g:329:1: ( ruleAction EOF )
            // InternalScSl.g:330:1: ruleAction EOF
            {
             before(grammarAccess.getActionRule()); 
            pushFollow(FOLLOW_1);
            ruleAction();

            state._fsp--;

             after(grammarAccess.getActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAction"


    // $ANTLR start "ruleAction"
    // InternalScSl.g:337:1: ruleAction : ( ( rule__Action__Alternatives ) ) ;
    public final void ruleAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:341:2: ( ( ( rule__Action__Alternatives ) ) )
            // InternalScSl.g:342:2: ( ( rule__Action__Alternatives ) )
            {
            // InternalScSl.g:342:2: ( ( rule__Action__Alternatives ) )
            // InternalScSl.g:343:3: ( rule__Action__Alternatives )
            {
             before(grammarAccess.getActionAccess().getAlternatives()); 
            // InternalScSl.g:344:3: ( rule__Action__Alternatives )
            // InternalScSl.g:344:4: rule__Action__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Action__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getActionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAction"


    // $ANTLR start "entryRuleMessageAction"
    // InternalScSl.g:353:1: entryRuleMessageAction : ruleMessageAction EOF ;
    public final void entryRuleMessageAction() throws RecognitionException {
        try {
            // InternalScSl.g:354:1: ( ruleMessageAction EOF )
            // InternalScSl.g:355:1: ruleMessageAction EOF
            {
             before(grammarAccess.getMessageActionRule()); 
            pushFollow(FOLLOW_1);
            ruleMessageAction();

            state._fsp--;

             after(grammarAccess.getMessageActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMessageAction"


    // $ANTLR start "ruleMessageAction"
    // InternalScSl.g:362:1: ruleMessageAction : ( ( rule__MessageAction__Group__0 ) ) ;
    public final void ruleMessageAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:366:2: ( ( ( rule__MessageAction__Group__0 ) ) )
            // InternalScSl.g:367:2: ( ( rule__MessageAction__Group__0 ) )
            {
            // InternalScSl.g:367:2: ( ( rule__MessageAction__Group__0 ) )
            // InternalScSl.g:368:3: ( rule__MessageAction__Group__0 )
            {
             before(grammarAccess.getMessageActionAccess().getGroup()); 
            // InternalScSl.g:369:3: ( rule__MessageAction__Group__0 )
            // InternalScSl.g:369:4: rule__MessageAction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__MessageAction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMessageActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMessageAction"


    // $ANTLR start "entryRuleSoundAction"
    // InternalScSl.g:378:1: entryRuleSoundAction : ruleSoundAction EOF ;
    public final void entryRuleSoundAction() throws RecognitionException {
        try {
            // InternalScSl.g:379:1: ( ruleSoundAction EOF )
            // InternalScSl.g:380:1: ruleSoundAction EOF
            {
             before(grammarAccess.getSoundActionRule()); 
            pushFollow(FOLLOW_1);
            ruleSoundAction();

            state._fsp--;

             after(grammarAccess.getSoundActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSoundAction"


    // $ANTLR start "ruleSoundAction"
    // InternalScSl.g:387:1: ruleSoundAction : ( ( rule__SoundAction__Group__0 ) ) ;
    public final void ruleSoundAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:391:2: ( ( ( rule__SoundAction__Group__0 ) ) )
            // InternalScSl.g:392:2: ( ( rule__SoundAction__Group__0 ) )
            {
            // InternalScSl.g:392:2: ( ( rule__SoundAction__Group__0 ) )
            // InternalScSl.g:393:3: ( rule__SoundAction__Group__0 )
            {
             before(grammarAccess.getSoundActionAccess().getGroup()); 
            // InternalScSl.g:394:3: ( rule__SoundAction__Group__0 )
            // InternalScSl.g:394:4: rule__SoundAction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SoundAction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSoundActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSoundAction"


    // $ANTLR start "entryRuleMarkAction"
    // InternalScSl.g:403:1: entryRuleMarkAction : ruleMarkAction EOF ;
    public final void entryRuleMarkAction() throws RecognitionException {
        try {
            // InternalScSl.g:404:1: ( ruleMarkAction EOF )
            // InternalScSl.g:405:1: ruleMarkAction EOF
            {
             before(grammarAccess.getMarkActionRule()); 
            pushFollow(FOLLOW_1);
            ruleMarkAction();

            state._fsp--;

             after(grammarAccess.getMarkActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMarkAction"


    // $ANTLR start "ruleMarkAction"
    // InternalScSl.g:412:1: ruleMarkAction : ( ( rule__MarkAction__Group__0 ) ) ;
    public final void ruleMarkAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:416:2: ( ( ( rule__MarkAction__Group__0 ) ) )
            // InternalScSl.g:417:2: ( ( rule__MarkAction__Group__0 ) )
            {
            // InternalScSl.g:417:2: ( ( rule__MarkAction__Group__0 ) )
            // InternalScSl.g:418:3: ( rule__MarkAction__Group__0 )
            {
             before(grammarAccess.getMarkActionAccess().getGroup()); 
            // InternalScSl.g:419:3: ( rule__MarkAction__Group__0 )
            // InternalScSl.g:419:4: rule__MarkAction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__MarkAction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMarkActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMarkAction"


    // $ANTLR start "entryRuleClearAction"
    // InternalScSl.g:428:1: entryRuleClearAction : ruleClearAction EOF ;
    public final void entryRuleClearAction() throws RecognitionException {
        try {
            // InternalScSl.g:429:1: ( ruleClearAction EOF )
            // InternalScSl.g:430:1: ruleClearAction EOF
            {
             before(grammarAccess.getClearActionRule()); 
            pushFollow(FOLLOW_1);
            ruleClearAction();

            state._fsp--;

             after(grammarAccess.getClearActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClearAction"


    // $ANTLR start "ruleClearAction"
    // InternalScSl.g:437:1: ruleClearAction : ( ( rule__ClearAction__Group__0 ) ) ;
    public final void ruleClearAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:441:2: ( ( ( rule__ClearAction__Group__0 ) ) )
            // InternalScSl.g:442:2: ( ( rule__ClearAction__Group__0 ) )
            {
            // InternalScSl.g:442:2: ( ( rule__ClearAction__Group__0 ) )
            // InternalScSl.g:443:3: ( rule__ClearAction__Group__0 )
            {
             before(grammarAccess.getClearActionAccess().getGroup()); 
            // InternalScSl.g:444:3: ( rule__ClearAction__Group__0 )
            // InternalScSl.g:444:4: rule__ClearAction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ClearAction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClearActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClearAction"


    // $ANTLR start "entryRuleWaitAction"
    // InternalScSl.g:453:1: entryRuleWaitAction : ruleWaitAction EOF ;
    public final void entryRuleWaitAction() throws RecognitionException {
        try {
            // InternalScSl.g:454:1: ( ruleWaitAction EOF )
            // InternalScSl.g:455:1: ruleWaitAction EOF
            {
             before(grammarAccess.getWaitActionRule()); 
            pushFollow(FOLLOW_1);
            ruleWaitAction();

            state._fsp--;

             after(grammarAccess.getWaitActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleWaitAction"


    // $ANTLR start "ruleWaitAction"
    // InternalScSl.g:462:1: ruleWaitAction : ( ( ( rule__WaitAction__Until_condAssignment ) ) ( ( rule__WaitAction__Until_condAssignment )* ) ) ;
    public final void ruleWaitAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:466:2: ( ( ( ( rule__WaitAction__Until_condAssignment ) ) ( ( rule__WaitAction__Until_condAssignment )* ) ) )
            // InternalScSl.g:467:2: ( ( ( rule__WaitAction__Until_condAssignment ) ) ( ( rule__WaitAction__Until_condAssignment )* ) )
            {
            // InternalScSl.g:467:2: ( ( ( rule__WaitAction__Until_condAssignment ) ) ( ( rule__WaitAction__Until_condAssignment )* ) )
            // InternalScSl.g:468:3: ( ( rule__WaitAction__Until_condAssignment ) ) ( ( rule__WaitAction__Until_condAssignment )* )
            {
            // InternalScSl.g:468:3: ( ( rule__WaitAction__Until_condAssignment ) )
            // InternalScSl.g:469:4: ( rule__WaitAction__Until_condAssignment )
            {
             before(grammarAccess.getWaitActionAccess().getUntil_condAssignment()); 
            // InternalScSl.g:470:4: ( rule__WaitAction__Until_condAssignment )
            // InternalScSl.g:470:5: rule__WaitAction__Until_condAssignment
            {
            pushFollow(FOLLOW_3);
            rule__WaitAction__Until_condAssignment();

            state._fsp--;


            }

             after(grammarAccess.getWaitActionAccess().getUntil_condAssignment()); 

            }

            // InternalScSl.g:473:3: ( ( rule__WaitAction__Until_condAssignment )* )
            // InternalScSl.g:474:4: ( rule__WaitAction__Until_condAssignment )*
            {
             before(grammarAccess.getWaitActionAccess().getUntil_condAssignment()); 
            // InternalScSl.g:475:4: ( rule__WaitAction__Until_condAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==41) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalScSl.g:475:5: rule__WaitAction__Until_condAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__WaitAction__Until_condAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getWaitActionAccess().getUntil_condAssignment()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleWaitAction"


    // $ANTLR start "entryRuleDriveAction"
    // InternalScSl.g:485:1: entryRuleDriveAction : ruleDriveAction EOF ;
    public final void entryRuleDriveAction() throws RecognitionException {
        try {
            // InternalScSl.g:486:1: ( ruleDriveAction EOF )
            // InternalScSl.g:487:1: ruleDriveAction EOF
            {
             before(grammarAccess.getDriveActionRule()); 
            pushFollow(FOLLOW_1);
            ruleDriveAction();

            state._fsp--;

             after(grammarAccess.getDriveActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDriveAction"


    // $ANTLR start "ruleDriveAction"
    // InternalScSl.g:494:1: ruleDriveAction : ( ( rule__DriveAction__Group__0 ) ) ;
    public final void ruleDriveAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:498:2: ( ( ( rule__DriveAction__Group__0 ) ) )
            // InternalScSl.g:499:2: ( ( rule__DriveAction__Group__0 ) )
            {
            // InternalScSl.g:499:2: ( ( rule__DriveAction__Group__0 ) )
            // InternalScSl.g:500:3: ( rule__DriveAction__Group__0 )
            {
             before(grammarAccess.getDriveActionAccess().getGroup()); 
            // InternalScSl.g:501:3: ( rule__DriveAction__Group__0 )
            // InternalScSl.g:501:4: rule__DriveAction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DriveAction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDriveActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDriveAction"


    // $ANTLR start "entryRuleTurnAction"
    // InternalScSl.g:510:1: entryRuleTurnAction : ruleTurnAction EOF ;
    public final void entryRuleTurnAction() throws RecognitionException {
        try {
            // InternalScSl.g:511:1: ( ruleTurnAction EOF )
            // InternalScSl.g:512:1: ruleTurnAction EOF
            {
             before(grammarAccess.getTurnActionRule()); 
            pushFollow(FOLLOW_1);
            ruleTurnAction();

            state._fsp--;

             after(grammarAccess.getTurnActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTurnAction"


    // $ANTLR start "ruleTurnAction"
    // InternalScSl.g:519:1: ruleTurnAction : ( ( rule__TurnAction__Group__0 ) ) ;
    public final void ruleTurnAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:523:2: ( ( ( rule__TurnAction__Group__0 ) ) )
            // InternalScSl.g:524:2: ( ( rule__TurnAction__Group__0 ) )
            {
            // InternalScSl.g:524:2: ( ( rule__TurnAction__Group__0 ) )
            // InternalScSl.g:525:3: ( rule__TurnAction__Group__0 )
            {
             before(grammarAccess.getTurnActionAccess().getGroup()); 
            // InternalScSl.g:526:3: ( rule__TurnAction__Group__0 )
            // InternalScSl.g:526:4: rule__TurnAction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TurnAction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTurnActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTurnAction"


    // $ANTLR start "entryRuleCondition"
    // InternalScSl.g:535:1: entryRuleCondition : ruleCondition EOF ;
    public final void entryRuleCondition() throws RecognitionException {
        try {
            // InternalScSl.g:536:1: ( ruleCondition EOF )
            // InternalScSl.g:537:1: ruleCondition EOF
            {
             before(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalScSl.g:544:1: ruleCondition : ( ( rule__Condition__Alternatives ) ) ;
    public final void ruleCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:548:2: ( ( ( rule__Condition__Alternatives ) ) )
            // InternalScSl.g:549:2: ( ( rule__Condition__Alternatives ) )
            {
            // InternalScSl.g:549:2: ( ( rule__Condition__Alternatives ) )
            // InternalScSl.g:550:3: ( rule__Condition__Alternatives )
            {
             before(grammarAccess.getConditionAccess().getAlternatives()); 
            // InternalScSl.g:551:3: ( rule__Condition__Alternatives )
            // InternalScSl.g:551:4: rule__Condition__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Condition__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getConditionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleColorCondition"
    // InternalScSl.g:560:1: entryRuleColorCondition : ruleColorCondition EOF ;
    public final void entryRuleColorCondition() throws RecognitionException {
        try {
            // InternalScSl.g:561:1: ( ruleColorCondition EOF )
            // InternalScSl.g:562:1: ruleColorCondition EOF
            {
             before(grammarAccess.getColorConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleColorCondition();

            state._fsp--;

             after(grammarAccess.getColorConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleColorCondition"


    // $ANTLR start "ruleColorCondition"
    // InternalScSl.g:569:1: ruleColorCondition : ( ( rule__ColorCondition__Group__0 ) ) ;
    public final void ruleColorCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:573:2: ( ( ( rule__ColorCondition__Group__0 ) ) )
            // InternalScSl.g:574:2: ( ( rule__ColorCondition__Group__0 ) )
            {
            // InternalScSl.g:574:2: ( ( rule__ColorCondition__Group__0 ) )
            // InternalScSl.g:575:3: ( rule__ColorCondition__Group__0 )
            {
             before(grammarAccess.getColorConditionAccess().getGroup()); 
            // InternalScSl.g:576:3: ( rule__ColorCondition__Group__0 )
            // InternalScSl.g:576:4: rule__ColorCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ColorCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getColorConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleColorCondition"


    // $ANTLR start "entryRuleObjectFrontCondition"
    // InternalScSl.g:585:1: entryRuleObjectFrontCondition : ruleObjectFrontCondition EOF ;
    public final void entryRuleObjectFrontCondition() throws RecognitionException {
        try {
            // InternalScSl.g:586:1: ( ruleObjectFrontCondition EOF )
            // InternalScSl.g:587:1: ruleObjectFrontCondition EOF
            {
             before(grammarAccess.getObjectFrontConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleObjectFrontCondition();

            state._fsp--;

             after(grammarAccess.getObjectFrontConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleObjectFrontCondition"


    // $ANTLR start "ruleObjectFrontCondition"
    // InternalScSl.g:594:1: ruleObjectFrontCondition : ( ( rule__ObjectFrontCondition__Group__0 ) ) ;
    public final void ruleObjectFrontCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:598:2: ( ( ( rule__ObjectFrontCondition__Group__0 ) ) )
            // InternalScSl.g:599:2: ( ( rule__ObjectFrontCondition__Group__0 ) )
            {
            // InternalScSl.g:599:2: ( ( rule__ObjectFrontCondition__Group__0 ) )
            // InternalScSl.g:600:3: ( rule__ObjectFrontCondition__Group__0 )
            {
             before(grammarAccess.getObjectFrontConditionAccess().getGroup()); 
            // InternalScSl.g:601:3: ( rule__ObjectFrontCondition__Group__0 )
            // InternalScSl.g:601:4: rule__ObjectFrontCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ObjectFrontCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getObjectFrontConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleObjectFrontCondition"


    // $ANTLR start "entryRuleObjectRightCondition"
    // InternalScSl.g:610:1: entryRuleObjectRightCondition : ruleObjectRightCondition EOF ;
    public final void entryRuleObjectRightCondition() throws RecognitionException {
        try {
            // InternalScSl.g:611:1: ( ruleObjectRightCondition EOF )
            // InternalScSl.g:612:1: ruleObjectRightCondition EOF
            {
             before(grammarAccess.getObjectRightConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleObjectRightCondition();

            state._fsp--;

             after(grammarAccess.getObjectRightConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleObjectRightCondition"


    // $ANTLR start "ruleObjectRightCondition"
    // InternalScSl.g:619:1: ruleObjectRightCondition : ( ( rule__ObjectRightCondition__Group__0 ) ) ;
    public final void ruleObjectRightCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:623:2: ( ( ( rule__ObjectRightCondition__Group__0 ) ) )
            // InternalScSl.g:624:2: ( ( rule__ObjectRightCondition__Group__0 ) )
            {
            // InternalScSl.g:624:2: ( ( rule__ObjectRightCondition__Group__0 ) )
            // InternalScSl.g:625:3: ( rule__ObjectRightCondition__Group__0 )
            {
             before(grammarAccess.getObjectRightConditionAccess().getGroup()); 
            // InternalScSl.g:626:3: ( rule__ObjectRightCondition__Group__0 )
            // InternalScSl.g:626:4: rule__ObjectRightCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ObjectRightCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getObjectRightConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleObjectRightCondition"


    // $ANTLR start "entryRuleTimeCondition"
    // InternalScSl.g:635:1: entryRuleTimeCondition : ruleTimeCondition EOF ;
    public final void entryRuleTimeCondition() throws RecognitionException {
        try {
            // InternalScSl.g:636:1: ( ruleTimeCondition EOF )
            // InternalScSl.g:637:1: ruleTimeCondition EOF
            {
             before(grammarAccess.getTimeConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleTimeCondition();

            state._fsp--;

             after(grammarAccess.getTimeConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTimeCondition"


    // $ANTLR start "ruleTimeCondition"
    // InternalScSl.g:644:1: ruleTimeCondition : ( ( rule__TimeCondition__Group__0 ) ) ;
    public final void ruleTimeCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:648:2: ( ( ( rule__TimeCondition__Group__0 ) ) )
            // InternalScSl.g:649:2: ( ( rule__TimeCondition__Group__0 ) )
            {
            // InternalScSl.g:649:2: ( ( rule__TimeCondition__Group__0 ) )
            // InternalScSl.g:650:3: ( rule__TimeCondition__Group__0 )
            {
             before(grammarAccess.getTimeConditionAccess().getGroup()); 
            // InternalScSl.g:651:3: ( rule__TimeCondition__Group__0 )
            // InternalScSl.g:651:4: rule__TimeCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TimeCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTimeConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTimeCondition"


    // $ANTLR start "entryRuleAchievementCondition"
    // InternalScSl.g:660:1: entryRuleAchievementCondition : ruleAchievementCondition EOF ;
    public final void entryRuleAchievementCondition() throws RecognitionException {
        try {
            // InternalScSl.g:661:1: ( ruleAchievementCondition EOF )
            // InternalScSl.g:662:1: ruleAchievementCondition EOF
            {
             before(grammarAccess.getAchievementConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleAchievementCondition();

            state._fsp--;

             after(grammarAccess.getAchievementConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAchievementCondition"


    // $ANTLR start "ruleAchievementCondition"
    // InternalScSl.g:669:1: ruleAchievementCondition : ( ( rule__AchievementCondition__Group__0 ) ) ;
    public final void ruleAchievementCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:673:2: ( ( ( rule__AchievementCondition__Group__0 ) ) )
            // InternalScSl.g:674:2: ( ( rule__AchievementCondition__Group__0 ) )
            {
            // InternalScSl.g:674:2: ( ( rule__AchievementCondition__Group__0 ) )
            // InternalScSl.g:675:3: ( rule__AchievementCondition__Group__0 )
            {
             before(grammarAccess.getAchievementConditionAccess().getGroup()); 
            // InternalScSl.g:676:3: ( rule__AchievementCondition__Group__0 )
            // InternalScSl.g:676:4: rule__AchievementCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__AchievementCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAchievementConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAchievementCondition"


    // $ANTLR start "entryRuleMemoryCondition"
    // InternalScSl.g:685:1: entryRuleMemoryCondition : ruleMemoryCondition EOF ;
    public final void entryRuleMemoryCondition() throws RecognitionException {
        try {
            // InternalScSl.g:686:1: ( ruleMemoryCondition EOF )
            // InternalScSl.g:687:1: ruleMemoryCondition EOF
            {
             before(grammarAccess.getMemoryConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleMemoryCondition();

            state._fsp--;

             after(grammarAccess.getMemoryConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMemoryCondition"


    // $ANTLR start "ruleMemoryCondition"
    // InternalScSl.g:694:1: ruleMemoryCondition : ( ( rule__MemoryCondition__Alternatives ) ) ;
    public final void ruleMemoryCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:698:2: ( ( ( rule__MemoryCondition__Alternatives ) ) )
            // InternalScSl.g:699:2: ( ( rule__MemoryCondition__Alternatives ) )
            {
            // InternalScSl.g:699:2: ( ( rule__MemoryCondition__Alternatives ) )
            // InternalScSl.g:700:3: ( rule__MemoryCondition__Alternatives )
            {
             before(grammarAccess.getMemoryConditionAccess().getAlternatives()); 
            // InternalScSl.g:701:3: ( rule__MemoryCondition__Alternatives )
            // InternalScSl.g:701:4: rule__MemoryCondition__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__MemoryCondition__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getMemoryConditionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMemoryCondition"


    // $ANTLR start "entryRuleColorDetection"
    // InternalScSl.g:710:1: entryRuleColorDetection : ruleColorDetection EOF ;
    public final void entryRuleColorDetection() throws RecognitionException {
        try {
            // InternalScSl.g:711:1: ( ruleColorDetection EOF )
            // InternalScSl.g:712:1: ruleColorDetection EOF
            {
             before(grammarAccess.getColorDetectionRule()); 
            pushFollow(FOLLOW_1);
            ruleColorDetection();

            state._fsp--;

             after(grammarAccess.getColorDetectionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleColorDetection"


    // $ANTLR start "ruleColorDetection"
    // InternalScSl.g:719:1: ruleColorDetection : ( ( rule__ColorDetection__Group__0 ) ) ;
    public final void ruleColorDetection() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:723:2: ( ( ( rule__ColorDetection__Group__0 ) ) )
            // InternalScSl.g:724:2: ( ( rule__ColorDetection__Group__0 ) )
            {
            // InternalScSl.g:724:2: ( ( rule__ColorDetection__Group__0 ) )
            // InternalScSl.g:725:3: ( rule__ColorDetection__Group__0 )
            {
             before(grammarAccess.getColorDetectionAccess().getGroup()); 
            // InternalScSl.g:726:3: ( rule__ColorDetection__Group__0 )
            // InternalScSl.g:726:4: rule__ColorDetection__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ColorDetection__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getColorDetectionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleColorDetection"


    // $ANTLR start "ruleDriveDirection"
    // InternalScSl.g:735:1: ruleDriveDirection : ( ( rule__DriveDirection__Alternatives ) ) ;
    public final void ruleDriveDirection() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:739:1: ( ( ( rule__DriveDirection__Alternatives ) ) )
            // InternalScSl.g:740:2: ( ( rule__DriveDirection__Alternatives ) )
            {
            // InternalScSl.g:740:2: ( ( rule__DriveDirection__Alternatives ) )
            // InternalScSl.g:741:3: ( rule__DriveDirection__Alternatives )
            {
             before(grammarAccess.getDriveDirectionAccess().getAlternatives()); 
            // InternalScSl.g:742:3: ( rule__DriveDirection__Alternatives )
            // InternalScSl.g:742:4: rule__DriveDirection__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DriveDirection__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDriveDirectionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDriveDirection"


    // $ANTLR start "ruleTurnDirection"
    // InternalScSl.g:751:1: ruleTurnDirection : ( ( rule__TurnDirection__Alternatives ) ) ;
    public final void ruleTurnDirection() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:755:1: ( ( ( rule__TurnDirection__Alternatives ) ) )
            // InternalScSl.g:756:2: ( ( rule__TurnDirection__Alternatives ) )
            {
            // InternalScSl.g:756:2: ( ( rule__TurnDirection__Alternatives ) )
            // InternalScSl.g:757:3: ( rule__TurnDirection__Alternatives )
            {
             before(grammarAccess.getTurnDirectionAccess().getAlternatives()); 
            // InternalScSl.g:758:3: ( rule__TurnDirection__Alternatives )
            // InternalScSl.g:758:4: rule__TurnDirection__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__TurnDirection__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTurnDirectionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTurnDirection"


    // $ANTLR start "ruleObjectState"
    // InternalScSl.g:767:1: ruleObjectState : ( ( rule__ObjectState__Alternatives ) ) ;
    public final void ruleObjectState() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:771:1: ( ( ( rule__ObjectState__Alternatives ) ) )
            // InternalScSl.g:772:2: ( ( rule__ObjectState__Alternatives ) )
            {
            // InternalScSl.g:772:2: ( ( rule__ObjectState__Alternatives ) )
            // InternalScSl.g:773:3: ( rule__ObjectState__Alternatives )
            {
             before(grammarAccess.getObjectStateAccess().getAlternatives()); 
            // InternalScSl.g:774:3: ( rule__ObjectState__Alternatives )
            // InternalScSl.g:774:4: rule__ObjectState__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ObjectState__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getObjectStateAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleObjectState"


    // $ANTLR start "ruleColor"
    // InternalScSl.g:783:1: ruleColor : ( ( rule__Color__Alternatives ) ) ;
    public final void ruleColor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:787:1: ( ( ( rule__Color__Alternatives ) ) )
            // InternalScSl.g:788:2: ( ( rule__Color__Alternatives ) )
            {
            // InternalScSl.g:788:2: ( ( rule__Color__Alternatives ) )
            // InternalScSl.g:789:3: ( rule__Color__Alternatives )
            {
             before(grammarAccess.getColorAccess().getAlternatives()); 
            // InternalScSl.g:790:3: ( rule__Color__Alternatives )
            // InternalScSl.g:790:4: rule__Color__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Color__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getColorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleColor"


    // $ANTLR start "ruleColorSensor"
    // InternalScSl.g:799:1: ruleColorSensor : ( ( rule__ColorSensor__Alternatives ) ) ;
    public final void ruleColorSensor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:803:1: ( ( ( rule__ColorSensor__Alternatives ) ) )
            // InternalScSl.g:804:2: ( ( rule__ColorSensor__Alternatives ) )
            {
            // InternalScSl.g:804:2: ( ( rule__ColorSensor__Alternatives ) )
            // InternalScSl.g:805:3: ( rule__ColorSensor__Alternatives )
            {
             before(grammarAccess.getColorSensorAccess().getAlternatives()); 
            // InternalScSl.g:806:3: ( rule__ColorSensor__Alternatives )
            // InternalScSl.g:806:4: rule__ColorSensor__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ColorSensor__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getColorSensorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleColorSensor"


    // $ANTLR start "rule__Action__Alternatives"
    // InternalScSl.g:814:1: rule__Action__Alternatives : ( ( ( rule__Action__Group_0__0 ) ) | ( ( rule__Action__Group_1__0 ) ) | ( ( rule__Action__Group_2__0 ) ) | ( ( rule__Action__Group_3__0 ) ) | ( ( rule__Action__Group_4__0 ) ) | ( ( rule__Action__Group_5__0 ) ) | ( ( rule__Action__Group_6__0 ) ) );
    public final void rule__Action__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:818:1: ( ( ( rule__Action__Group_0__0 ) ) | ( ( rule__Action__Group_1__0 ) ) | ( ( rule__Action__Group_2__0 ) ) | ( ( rule__Action__Group_3__0 ) ) | ( ( rule__Action__Group_4__0 ) ) | ( ( rule__Action__Group_5__0 ) ) | ( ( rule__Action__Group_6__0 ) ) )
            int alt2=7;
            switch ( input.LA(1) ) {
            case 42:
                {
                alt2=1;
                }
                break;
            case 43:
                {
                alt2=2;
                }
                break;
            case 44:
                {
                alt2=3;
                }
                break;
            case 45:
                {
                alt2=4;
                }
                break;
            case 46:
                {
                alt2=5;
                }
                break;
            case 47:
                {
                alt2=6;
                }
                break;
            case 48:
                {
                alt2=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalScSl.g:819:2: ( ( rule__Action__Group_0__0 ) )
                    {
                    // InternalScSl.g:819:2: ( ( rule__Action__Group_0__0 ) )
                    // InternalScSl.g:820:3: ( rule__Action__Group_0__0 )
                    {
                     before(grammarAccess.getActionAccess().getGroup_0()); 
                    // InternalScSl.g:821:3: ( rule__Action__Group_0__0 )
                    // InternalScSl.g:821:4: rule__Action__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Action__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getActionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:825:2: ( ( rule__Action__Group_1__0 ) )
                    {
                    // InternalScSl.g:825:2: ( ( rule__Action__Group_1__0 ) )
                    // InternalScSl.g:826:3: ( rule__Action__Group_1__0 )
                    {
                     before(grammarAccess.getActionAccess().getGroup_1()); 
                    // InternalScSl.g:827:3: ( rule__Action__Group_1__0 )
                    // InternalScSl.g:827:4: rule__Action__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Action__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getActionAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalScSl.g:831:2: ( ( rule__Action__Group_2__0 ) )
                    {
                    // InternalScSl.g:831:2: ( ( rule__Action__Group_2__0 ) )
                    // InternalScSl.g:832:3: ( rule__Action__Group_2__0 )
                    {
                     before(grammarAccess.getActionAccess().getGroup_2()); 
                    // InternalScSl.g:833:3: ( rule__Action__Group_2__0 )
                    // InternalScSl.g:833:4: rule__Action__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Action__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getActionAccess().getGroup_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalScSl.g:837:2: ( ( rule__Action__Group_3__0 ) )
                    {
                    // InternalScSl.g:837:2: ( ( rule__Action__Group_3__0 ) )
                    // InternalScSl.g:838:3: ( rule__Action__Group_3__0 )
                    {
                     before(grammarAccess.getActionAccess().getGroup_3()); 
                    // InternalScSl.g:839:3: ( rule__Action__Group_3__0 )
                    // InternalScSl.g:839:4: rule__Action__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Action__Group_3__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getActionAccess().getGroup_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalScSl.g:843:2: ( ( rule__Action__Group_4__0 ) )
                    {
                    // InternalScSl.g:843:2: ( ( rule__Action__Group_4__0 ) )
                    // InternalScSl.g:844:3: ( rule__Action__Group_4__0 )
                    {
                     before(grammarAccess.getActionAccess().getGroup_4()); 
                    // InternalScSl.g:845:3: ( rule__Action__Group_4__0 )
                    // InternalScSl.g:845:4: rule__Action__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Action__Group_4__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getActionAccess().getGroup_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalScSl.g:849:2: ( ( rule__Action__Group_5__0 ) )
                    {
                    // InternalScSl.g:849:2: ( ( rule__Action__Group_5__0 ) )
                    // InternalScSl.g:850:3: ( rule__Action__Group_5__0 )
                    {
                     before(grammarAccess.getActionAccess().getGroup_5()); 
                    // InternalScSl.g:851:3: ( rule__Action__Group_5__0 )
                    // InternalScSl.g:851:4: rule__Action__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Action__Group_5__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getActionAccess().getGroup_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalScSl.g:855:2: ( ( rule__Action__Group_6__0 ) )
                    {
                    // InternalScSl.g:855:2: ( ( rule__Action__Group_6__0 ) )
                    // InternalScSl.g:856:3: ( rule__Action__Group_6__0 )
                    {
                     before(grammarAccess.getActionAccess().getGroup_6()); 
                    // InternalScSl.g:857:3: ( rule__Action__Group_6__0 )
                    // InternalScSl.g:857:4: rule__Action__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Action__Group_6__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getActionAccess().getGroup_6()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Alternatives"


    // $ANTLR start "rule__Condition__Alternatives"
    // InternalScSl.g:865:1: rule__Condition__Alternatives : ( ( ruleObjectFrontCondition ) | ( ruleObjectRightCondition ) | ( ruleColorCondition ) | ( ruleTimeCondition ) | ( ruleAchievementCondition ) | ( ruleMemoryCondition ) );
    public final void rule__Condition__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:869:1: ( ( ruleObjectFrontCondition ) | ( ruleObjectRightCondition ) | ( ruleColorCondition ) | ( ruleTimeCondition ) | ( ruleAchievementCondition ) | ( ruleMemoryCondition ) )
            int alt3=6;
            switch ( input.LA(1) ) {
            case 55:
                {
                alt3=1;
                }
                break;
            case 14:
                {
                alt3=2;
                }
                break;
            case 54:
                {
                alt3=3;
                }
                break;
            case 56:
                {
                alt3=4;
                }
                break;
            case 53:
                {
                alt3=5;
                }
                break;
            case 57:
                {
                alt3=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalScSl.g:870:2: ( ruleObjectFrontCondition )
                    {
                    // InternalScSl.g:870:2: ( ruleObjectFrontCondition )
                    // InternalScSl.g:871:3: ruleObjectFrontCondition
                    {
                     before(grammarAccess.getConditionAccess().getObjectFrontConditionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleObjectFrontCondition();

                    state._fsp--;

                     after(grammarAccess.getConditionAccess().getObjectFrontConditionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:876:2: ( ruleObjectRightCondition )
                    {
                    // InternalScSl.g:876:2: ( ruleObjectRightCondition )
                    // InternalScSl.g:877:3: ruleObjectRightCondition
                    {
                     before(grammarAccess.getConditionAccess().getObjectRightConditionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleObjectRightCondition();

                    state._fsp--;

                     after(grammarAccess.getConditionAccess().getObjectRightConditionParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalScSl.g:882:2: ( ruleColorCondition )
                    {
                    // InternalScSl.g:882:2: ( ruleColorCondition )
                    // InternalScSl.g:883:3: ruleColorCondition
                    {
                     before(grammarAccess.getConditionAccess().getColorConditionParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleColorCondition();

                    state._fsp--;

                     after(grammarAccess.getConditionAccess().getColorConditionParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalScSl.g:888:2: ( ruleTimeCondition )
                    {
                    // InternalScSl.g:888:2: ( ruleTimeCondition )
                    // InternalScSl.g:889:3: ruleTimeCondition
                    {
                     before(grammarAccess.getConditionAccess().getTimeConditionParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleTimeCondition();

                    state._fsp--;

                     after(grammarAccess.getConditionAccess().getTimeConditionParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalScSl.g:894:2: ( ruleAchievementCondition )
                    {
                    // InternalScSl.g:894:2: ( ruleAchievementCondition )
                    // InternalScSl.g:895:3: ruleAchievementCondition
                    {
                     before(grammarAccess.getConditionAccess().getAchievementConditionParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleAchievementCondition();

                    state._fsp--;

                     after(grammarAccess.getConditionAccess().getAchievementConditionParserRuleCall_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalScSl.g:900:2: ( ruleMemoryCondition )
                    {
                    // InternalScSl.g:900:2: ( ruleMemoryCondition )
                    // InternalScSl.g:901:3: ruleMemoryCondition
                    {
                     before(grammarAccess.getConditionAccess().getMemoryConditionParserRuleCall_5()); 
                    pushFollow(FOLLOW_2);
                    ruleMemoryCondition();

                    state._fsp--;

                     after(grammarAccess.getConditionAccess().getMemoryConditionParserRuleCall_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Alternatives"


    // $ANTLR start "rule__MemoryCondition__Alternatives"
    // InternalScSl.g:910:1: rule__MemoryCondition__Alternatives : ( ( ( rule__MemoryCondition__Group_0__0 ) ) | ( ( rule__MemoryCondition__Group_1__0 ) ) | ( ( rule__MemoryCondition__Group_2__0 ) ) );
    public final void rule__MemoryCondition__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:914:1: ( ( ( rule__MemoryCondition__Group_0__0 ) ) | ( ( rule__MemoryCondition__Group_1__0 ) ) | ( ( rule__MemoryCondition__Group_2__0 ) ) )
            int alt4=3;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==57) ) {
                switch ( input.LA(2) ) {
                case 14:
                    {
                    alt4=3;
                    }
                    break;
                case 55:
                    {
                    alt4=2;
                    }
                    break;
                case 54:
                    {
                    alt4=1;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 1, input);

                    throw nvae;
                }

            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalScSl.g:915:2: ( ( rule__MemoryCondition__Group_0__0 ) )
                    {
                    // InternalScSl.g:915:2: ( ( rule__MemoryCondition__Group_0__0 ) )
                    // InternalScSl.g:916:3: ( rule__MemoryCondition__Group_0__0 )
                    {
                     before(grammarAccess.getMemoryConditionAccess().getGroup_0()); 
                    // InternalScSl.g:917:3: ( rule__MemoryCondition__Group_0__0 )
                    // InternalScSl.g:917:4: rule__MemoryCondition__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MemoryCondition__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMemoryConditionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:921:2: ( ( rule__MemoryCondition__Group_1__0 ) )
                    {
                    // InternalScSl.g:921:2: ( ( rule__MemoryCondition__Group_1__0 ) )
                    // InternalScSl.g:922:3: ( rule__MemoryCondition__Group_1__0 )
                    {
                     before(grammarAccess.getMemoryConditionAccess().getGroup_1()); 
                    // InternalScSl.g:923:3: ( rule__MemoryCondition__Group_1__0 )
                    // InternalScSl.g:923:4: rule__MemoryCondition__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MemoryCondition__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMemoryConditionAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalScSl.g:927:2: ( ( rule__MemoryCondition__Group_2__0 ) )
                    {
                    // InternalScSl.g:927:2: ( ( rule__MemoryCondition__Group_2__0 ) )
                    // InternalScSl.g:928:3: ( rule__MemoryCondition__Group_2__0 )
                    {
                     before(grammarAccess.getMemoryConditionAccess().getGroup_2()); 
                    // InternalScSl.g:929:3: ( rule__MemoryCondition__Group_2__0 )
                    // InternalScSl.g:929:4: rule__MemoryCondition__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MemoryCondition__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMemoryConditionAccess().getGroup_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Alternatives"


    // $ANTLR start "rule__DriveDirection__Alternatives"
    // InternalScSl.g:937:1: rule__DriveDirection__Alternatives : ( ( ( 'forward' ) ) | ( ( 'back' ) ) );
    public final void rule__DriveDirection__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:941:1: ( ( ( 'forward' ) ) | ( ( 'back' ) ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==11) ) {
                alt5=1;
            }
            else if ( (LA5_0==12) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalScSl.g:942:2: ( ( 'forward' ) )
                    {
                    // InternalScSl.g:942:2: ( ( 'forward' ) )
                    // InternalScSl.g:943:3: ( 'forward' )
                    {
                     before(grammarAccess.getDriveDirectionAccess().getFORWARDEnumLiteralDeclaration_0()); 
                    // InternalScSl.g:944:3: ( 'forward' )
                    // InternalScSl.g:944:4: 'forward'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getDriveDirectionAccess().getFORWARDEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:948:2: ( ( 'back' ) )
                    {
                    // InternalScSl.g:948:2: ( ( 'back' ) )
                    // InternalScSl.g:949:3: ( 'back' )
                    {
                     before(grammarAccess.getDriveDirectionAccess().getBACKEnumLiteralDeclaration_1()); 
                    // InternalScSl.g:950:3: ( 'back' )
                    // InternalScSl.g:950:4: 'back'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getDriveDirectionAccess().getBACKEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DriveDirection__Alternatives"


    // $ANTLR start "rule__TurnDirection__Alternatives"
    // InternalScSl.g:958:1: rule__TurnDirection__Alternatives : ( ( ( 'left' ) ) | ( ( 'right' ) ) );
    public final void rule__TurnDirection__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:962:1: ( ( ( 'left' ) ) | ( ( 'right' ) ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==13) ) {
                alt6=1;
            }
            else if ( (LA6_0==14) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalScSl.g:963:2: ( ( 'left' ) )
                    {
                    // InternalScSl.g:963:2: ( ( 'left' ) )
                    // InternalScSl.g:964:3: ( 'left' )
                    {
                     before(grammarAccess.getTurnDirectionAccess().getLEFTEnumLiteralDeclaration_0()); 
                    // InternalScSl.g:965:3: ( 'left' )
                    // InternalScSl.g:965:4: 'left'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getTurnDirectionAccess().getLEFTEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:969:2: ( ( 'right' ) )
                    {
                    // InternalScSl.g:969:2: ( ( 'right' ) )
                    // InternalScSl.g:970:3: ( 'right' )
                    {
                     before(grammarAccess.getTurnDirectionAccess().getRIGHTEnumLiteralDeclaration_1()); 
                    // InternalScSl.g:971:3: ( 'right' )
                    // InternalScSl.g:971:4: 'right'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getTurnDirectionAccess().getRIGHTEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TurnDirection__Alternatives"


    // $ANTLR start "rule__ObjectState__Alternatives"
    // InternalScSl.g:979:1: rule__ObjectState__Alternatives : ( ( ( 'close' ) ) | ( ( 'none' ) ) );
    public final void rule__ObjectState__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:983:1: ( ( ( 'close' ) ) | ( ( 'none' ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==15) ) {
                alt7=1;
            }
            else if ( (LA7_0==16) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalScSl.g:984:2: ( ( 'close' ) )
                    {
                    // InternalScSl.g:984:2: ( ( 'close' ) )
                    // InternalScSl.g:985:3: ( 'close' )
                    {
                     before(grammarAccess.getObjectStateAccess().getCLOSEEnumLiteralDeclaration_0()); 
                    // InternalScSl.g:986:3: ( 'close' )
                    // InternalScSl.g:986:4: 'close'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getObjectStateAccess().getCLOSEEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:990:2: ( ( 'none' ) )
                    {
                    // InternalScSl.g:990:2: ( ( 'none' ) )
                    // InternalScSl.g:991:3: ( 'none' )
                    {
                     before(grammarAccess.getObjectStateAccess().getNONEEnumLiteralDeclaration_1()); 
                    // InternalScSl.g:992:3: ( 'none' )
                    // InternalScSl.g:992:4: 'none'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getObjectStateAccess().getNONEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectState__Alternatives"


    // $ANTLR start "rule__Color__Alternatives"
    // InternalScSl.g:1000:1: rule__Color__Alternatives : ( ( ( 'black' ) ) | ( ( 'white' ) ) );
    public final void rule__Color__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1004:1: ( ( ( 'black' ) ) | ( ( 'white' ) ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==17) ) {
                alt8=1;
            }
            else if ( (LA8_0==18) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalScSl.g:1005:2: ( ( 'black' ) )
                    {
                    // InternalScSl.g:1005:2: ( ( 'black' ) )
                    // InternalScSl.g:1006:3: ( 'black' )
                    {
                     before(grammarAccess.getColorAccess().getBLACKEnumLiteralDeclaration_0()); 
                    // InternalScSl.g:1007:3: ( 'black' )
                    // InternalScSl.g:1007:4: 'black'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getColorAccess().getBLACKEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1011:2: ( ( 'white' ) )
                    {
                    // InternalScSl.g:1011:2: ( ( 'white' ) )
                    // InternalScSl.g:1012:3: ( 'white' )
                    {
                     before(grammarAccess.getColorAccess().getWHITEEnumLiteralDeclaration_1()); 
                    // InternalScSl.g:1013:3: ( 'white' )
                    // InternalScSl.g:1013:4: 'white'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getColorAccess().getWHITEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Color__Alternatives"


    // $ANTLR start "rule__ColorSensor__Alternatives"
    // InternalScSl.g:1021:1: rule__ColorSensor__Alternatives : ( ( ( 'left' ) ) | ( ( 'right' ) ) | ( ( 'any' ) ) );
    public final void rule__ColorSensor__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1025:1: ( ( ( 'left' ) ) | ( ( 'right' ) ) | ( ( 'any' ) ) )
            int alt9=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt9=1;
                }
                break;
            case 14:
                {
                alt9=2;
                }
                break;
            case 19:
                {
                alt9=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalScSl.g:1026:2: ( ( 'left' ) )
                    {
                    // InternalScSl.g:1026:2: ( ( 'left' ) )
                    // InternalScSl.g:1027:3: ( 'left' )
                    {
                     before(grammarAccess.getColorSensorAccess().getLEFTEnumLiteralDeclaration_0()); 
                    // InternalScSl.g:1028:3: ( 'left' )
                    // InternalScSl.g:1028:4: 'left'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getColorSensorAccess().getLEFTEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalScSl.g:1032:2: ( ( 'right' ) )
                    {
                    // InternalScSl.g:1032:2: ( ( 'right' ) )
                    // InternalScSl.g:1033:3: ( 'right' )
                    {
                     before(grammarAccess.getColorSensorAccess().getRIGHTEnumLiteralDeclaration_1()); 
                    // InternalScSl.g:1034:3: ( 'right' )
                    // InternalScSl.g:1034:4: 'right'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getColorSensorAccess().getRIGHTEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalScSl.g:1038:2: ( ( 'any' ) )
                    {
                    // InternalScSl.g:1038:2: ( ( 'any' ) )
                    // InternalScSl.g:1039:3: ( 'any' )
                    {
                     before(grammarAccess.getColorSensorAccess().getANYEnumLiteralDeclaration_2()); 
                    // InternalScSl.g:1040:3: ( 'any' )
                    // InternalScSl.g:1040:4: 'any'
                    {
                    match(input,19,FOLLOW_2); 

                    }

                     after(grammarAccess.getColorSensorAccess().getANYEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorSensor__Alternatives"


    // $ANTLR start "rule__Mission__Group__0"
    // InternalScSl.g:1048:1: rule__Mission__Group__0 : rule__Mission__Group__0__Impl rule__Mission__Group__1 ;
    public final void rule__Mission__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1052:1: ( rule__Mission__Group__0__Impl rule__Mission__Group__1 )
            // InternalScSl.g:1053:2: rule__Mission__Group__0__Impl rule__Mission__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Mission__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__0"


    // $ANTLR start "rule__Mission__Group__0__Impl"
    // InternalScSl.g:1060:1: rule__Mission__Group__0__Impl : ( 'Mission' ) ;
    public final void rule__Mission__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1064:1: ( ( 'Mission' ) )
            // InternalScSl.g:1065:1: ( 'Mission' )
            {
            // InternalScSl.g:1065:1: ( 'Mission' )
            // InternalScSl.g:1066:2: 'Mission'
            {
             before(grammarAccess.getMissionAccess().getMissionKeyword_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getMissionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__0__Impl"


    // $ANTLR start "rule__Mission__Group__1"
    // InternalScSl.g:1075:1: rule__Mission__Group__1 : rule__Mission__Group__1__Impl rule__Mission__Group__2 ;
    public final void rule__Mission__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1079:1: ( rule__Mission__Group__1__Impl rule__Mission__Group__2 )
            // InternalScSl.g:1080:2: rule__Mission__Group__1__Impl rule__Mission__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Mission__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__1"


    // $ANTLR start "rule__Mission__Group__1__Impl"
    // InternalScSl.g:1087:1: rule__Mission__Group__1__Impl : ( ( rule__Mission__NameAssignment_1 ) ) ;
    public final void rule__Mission__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1091:1: ( ( ( rule__Mission__NameAssignment_1 ) ) )
            // InternalScSl.g:1092:1: ( ( rule__Mission__NameAssignment_1 ) )
            {
            // InternalScSl.g:1092:1: ( ( rule__Mission__NameAssignment_1 ) )
            // InternalScSl.g:1093:2: ( rule__Mission__NameAssignment_1 )
            {
             before(grammarAccess.getMissionAccess().getNameAssignment_1()); 
            // InternalScSl.g:1094:2: ( rule__Mission__NameAssignment_1 )
            // InternalScSl.g:1094:3: rule__Mission__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__1__Impl"


    // $ANTLR start "rule__Mission__Group__2"
    // InternalScSl.g:1102:1: rule__Mission__Group__2 : rule__Mission__Group__2__Impl rule__Mission__Group__3 ;
    public final void rule__Mission__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1106:1: ( rule__Mission__Group__2__Impl rule__Mission__Group__3 )
            // InternalScSl.g:1107:2: rule__Mission__Group__2__Impl rule__Mission__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Mission__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__2"


    // $ANTLR start "rule__Mission__Group__2__Impl"
    // InternalScSl.g:1114:1: rule__Mission__Group__2__Impl : ( ( rule__Mission__Group_2__0 )? ) ;
    public final void rule__Mission__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1118:1: ( ( ( rule__Mission__Group_2__0 )? ) )
            // InternalScSl.g:1119:1: ( ( rule__Mission__Group_2__0 )? )
            {
            // InternalScSl.g:1119:1: ( ( rule__Mission__Group_2__0 )? )
            // InternalScSl.g:1120:2: ( rule__Mission__Group_2__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_2()); 
            // InternalScSl.g:1121:2: ( rule__Mission__Group_2__0 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==22) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalScSl.g:1121:3: rule__Mission__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__2__Impl"


    // $ANTLR start "rule__Mission__Group__3"
    // InternalScSl.g:1129:1: rule__Mission__Group__3 : rule__Mission__Group__3__Impl rule__Mission__Group__4 ;
    public final void rule__Mission__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1133:1: ( rule__Mission__Group__3__Impl rule__Mission__Group__4 )
            // InternalScSl.g:1134:2: rule__Mission__Group__3__Impl rule__Mission__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__3"


    // $ANTLR start "rule__Mission__Group__3__Impl"
    // InternalScSl.g:1141:1: rule__Mission__Group__3__Impl : ( ( ( rule__Mission__GoalsAssignment_3 ) ) ( ( rule__Mission__GoalsAssignment_3 )* ) ) ;
    public final void rule__Mission__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1145:1: ( ( ( ( rule__Mission__GoalsAssignment_3 ) ) ( ( rule__Mission__GoalsAssignment_3 )* ) ) )
            // InternalScSl.g:1146:1: ( ( ( rule__Mission__GoalsAssignment_3 ) ) ( ( rule__Mission__GoalsAssignment_3 )* ) )
            {
            // InternalScSl.g:1146:1: ( ( ( rule__Mission__GoalsAssignment_3 ) ) ( ( rule__Mission__GoalsAssignment_3 )* ) )
            // InternalScSl.g:1147:2: ( ( rule__Mission__GoalsAssignment_3 ) ) ( ( rule__Mission__GoalsAssignment_3 )* )
            {
            // InternalScSl.g:1147:2: ( ( rule__Mission__GoalsAssignment_3 ) )
            // InternalScSl.g:1148:3: ( rule__Mission__GoalsAssignment_3 )
            {
             before(grammarAccess.getMissionAccess().getGoalsAssignment_3()); 
            // InternalScSl.g:1149:3: ( rule__Mission__GoalsAssignment_3 )
            // InternalScSl.g:1149:4: rule__Mission__GoalsAssignment_3
            {
            pushFollow(FOLLOW_7);
            rule__Mission__GoalsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getGoalsAssignment_3()); 

            }

            // InternalScSl.g:1152:2: ( ( rule__Mission__GoalsAssignment_3 )* )
            // InternalScSl.g:1153:3: ( rule__Mission__GoalsAssignment_3 )*
            {
             before(grammarAccess.getMissionAccess().getGoalsAssignment_3()); 
            // InternalScSl.g:1154:3: ( rule__Mission__GoalsAssignment_3 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==38) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalScSl.g:1154:4: rule__Mission__GoalsAssignment_3
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__Mission__GoalsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getMissionAccess().getGoalsAssignment_3()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__3__Impl"


    // $ANTLR start "rule__Mission__Group__4"
    // InternalScSl.g:1163:1: rule__Mission__Group__4 : rule__Mission__Group__4__Impl rule__Mission__Group__5 ;
    public final void rule__Mission__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1167:1: ( rule__Mission__Group__4__Impl rule__Mission__Group__5 )
            // InternalScSl.g:1168:2: rule__Mission__Group__4__Impl rule__Mission__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__4"


    // $ANTLR start "rule__Mission__Group__4__Impl"
    // InternalScSl.g:1175:1: rule__Mission__Group__4__Impl : ( ( rule__Mission__Group_4__0 )? ) ;
    public final void rule__Mission__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1179:1: ( ( ( rule__Mission__Group_4__0 )? ) )
            // InternalScSl.g:1180:1: ( ( rule__Mission__Group_4__0 )? )
            {
            // InternalScSl.g:1180:1: ( ( rule__Mission__Group_4__0 )? )
            // InternalScSl.g:1181:2: ( rule__Mission__Group_4__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_4()); 
            // InternalScSl.g:1182:2: ( rule__Mission__Group_4__0 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==23) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalScSl.g:1182:3: rule__Mission__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__4__Impl"


    // $ANTLR start "rule__Mission__Group__5"
    // InternalScSl.g:1190:1: rule__Mission__Group__5 : rule__Mission__Group__5__Impl rule__Mission__Group__6 ;
    public final void rule__Mission__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1194:1: ( rule__Mission__Group__5__Impl rule__Mission__Group__6 )
            // InternalScSl.g:1195:2: rule__Mission__Group__5__Impl rule__Mission__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__5"


    // $ANTLR start "rule__Mission__Group__5__Impl"
    // InternalScSl.g:1202:1: rule__Mission__Group__5__Impl : ( ( rule__Mission__Group_5__0 )? ) ;
    public final void rule__Mission__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1206:1: ( ( ( rule__Mission__Group_5__0 )? ) )
            // InternalScSl.g:1207:1: ( ( rule__Mission__Group_5__0 )? )
            {
            // InternalScSl.g:1207:1: ( ( rule__Mission__Group_5__0 )? )
            // InternalScSl.g:1208:2: ( rule__Mission__Group_5__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_5()); 
            // InternalScSl.g:1209:2: ( rule__Mission__Group_5__0 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==24) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalScSl.g:1209:3: rule__Mission__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__5__Impl"


    // $ANTLR start "rule__Mission__Group__6"
    // InternalScSl.g:1217:1: rule__Mission__Group__6 : rule__Mission__Group__6__Impl rule__Mission__Group__7 ;
    public final void rule__Mission__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1221:1: ( rule__Mission__Group__6__Impl rule__Mission__Group__7 )
            // InternalScSl.g:1222:2: rule__Mission__Group__6__Impl rule__Mission__Group__7
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__6"


    // $ANTLR start "rule__Mission__Group__6__Impl"
    // InternalScSl.g:1229:1: rule__Mission__Group__6__Impl : ( ( rule__Mission__Group_6__0 )? ) ;
    public final void rule__Mission__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1233:1: ( ( ( rule__Mission__Group_6__0 )? ) )
            // InternalScSl.g:1234:1: ( ( rule__Mission__Group_6__0 )? )
            {
            // InternalScSl.g:1234:1: ( ( rule__Mission__Group_6__0 )? )
            // InternalScSl.g:1235:2: ( rule__Mission__Group_6__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_6()); 
            // InternalScSl.g:1236:2: ( rule__Mission__Group_6__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==25) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalScSl.g:1236:3: rule__Mission__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__6__Impl"


    // $ANTLR start "rule__Mission__Group__7"
    // InternalScSl.g:1244:1: rule__Mission__Group__7 : rule__Mission__Group__7__Impl rule__Mission__Group__8 ;
    public final void rule__Mission__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1248:1: ( rule__Mission__Group__7__Impl rule__Mission__Group__8 )
            // InternalScSl.g:1249:2: rule__Mission__Group__7__Impl rule__Mission__Group__8
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__7"


    // $ANTLR start "rule__Mission__Group__7__Impl"
    // InternalScSl.g:1256:1: rule__Mission__Group__7__Impl : ( ( rule__Mission__Group_7__0 )? ) ;
    public final void rule__Mission__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1260:1: ( ( ( rule__Mission__Group_7__0 )? ) )
            // InternalScSl.g:1261:1: ( ( rule__Mission__Group_7__0 )? )
            {
            // InternalScSl.g:1261:1: ( ( rule__Mission__Group_7__0 )? )
            // InternalScSl.g:1262:2: ( rule__Mission__Group_7__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_7()); 
            // InternalScSl.g:1263:2: ( rule__Mission__Group_7__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==26) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalScSl.g:1263:3: rule__Mission__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__7__Impl"


    // $ANTLR start "rule__Mission__Group__8"
    // InternalScSl.g:1271:1: rule__Mission__Group__8 : rule__Mission__Group__8__Impl rule__Mission__Group__9 ;
    public final void rule__Mission__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1275:1: ( rule__Mission__Group__8__Impl rule__Mission__Group__9 )
            // InternalScSl.g:1276:2: rule__Mission__Group__8__Impl rule__Mission__Group__9
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__8"


    // $ANTLR start "rule__Mission__Group__8__Impl"
    // InternalScSl.g:1283:1: rule__Mission__Group__8__Impl : ( ( rule__Mission__Group_8__0 )? ) ;
    public final void rule__Mission__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1287:1: ( ( ( rule__Mission__Group_8__0 )? ) )
            // InternalScSl.g:1288:1: ( ( rule__Mission__Group_8__0 )? )
            {
            // InternalScSl.g:1288:1: ( ( rule__Mission__Group_8__0 )? )
            // InternalScSl.g:1289:2: ( rule__Mission__Group_8__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_8()); 
            // InternalScSl.g:1290:2: ( rule__Mission__Group_8__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==27) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalScSl.g:1290:3: rule__Mission__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__8__Impl"


    // $ANTLR start "rule__Mission__Group__9"
    // InternalScSl.g:1298:1: rule__Mission__Group__9 : rule__Mission__Group__9__Impl rule__Mission__Group__10 ;
    public final void rule__Mission__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1302:1: ( rule__Mission__Group__9__Impl rule__Mission__Group__10 )
            // InternalScSl.g:1303:2: rule__Mission__Group__9__Impl rule__Mission__Group__10
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__9"


    // $ANTLR start "rule__Mission__Group__9__Impl"
    // InternalScSl.g:1310:1: rule__Mission__Group__9__Impl : ( ( rule__Mission__Group_9__0 )? ) ;
    public final void rule__Mission__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1314:1: ( ( ( rule__Mission__Group_9__0 )? ) )
            // InternalScSl.g:1315:1: ( ( rule__Mission__Group_9__0 )? )
            {
            // InternalScSl.g:1315:1: ( ( rule__Mission__Group_9__0 )? )
            // InternalScSl.g:1316:2: ( rule__Mission__Group_9__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_9()); 
            // InternalScSl.g:1317:2: ( rule__Mission__Group_9__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==28) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalScSl.g:1317:3: rule__Mission__Group_9__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_9__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__9__Impl"


    // $ANTLR start "rule__Mission__Group__10"
    // InternalScSl.g:1325:1: rule__Mission__Group__10 : rule__Mission__Group__10__Impl rule__Mission__Group__11 ;
    public final void rule__Mission__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1329:1: ( rule__Mission__Group__10__Impl rule__Mission__Group__11 )
            // InternalScSl.g:1330:2: rule__Mission__Group__10__Impl rule__Mission__Group__11
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__10"


    // $ANTLR start "rule__Mission__Group__10__Impl"
    // InternalScSl.g:1337:1: rule__Mission__Group__10__Impl : ( ( rule__Mission__Group_10__0 )? ) ;
    public final void rule__Mission__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1341:1: ( ( ( rule__Mission__Group_10__0 )? ) )
            // InternalScSl.g:1342:1: ( ( rule__Mission__Group_10__0 )? )
            {
            // InternalScSl.g:1342:1: ( ( rule__Mission__Group_10__0 )? )
            // InternalScSl.g:1343:2: ( rule__Mission__Group_10__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_10()); 
            // InternalScSl.g:1344:2: ( rule__Mission__Group_10__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==29) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalScSl.g:1344:3: rule__Mission__Group_10__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_10__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__10__Impl"


    // $ANTLR start "rule__Mission__Group__11"
    // InternalScSl.g:1352:1: rule__Mission__Group__11 : rule__Mission__Group__11__Impl rule__Mission__Group__12 ;
    public final void rule__Mission__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1356:1: ( rule__Mission__Group__11__Impl rule__Mission__Group__12 )
            // InternalScSl.g:1357:2: rule__Mission__Group__11__Impl rule__Mission__Group__12
            {
            pushFollow(FOLLOW_6);
            rule__Mission__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__11"


    // $ANTLR start "rule__Mission__Group__11__Impl"
    // InternalScSl.g:1364:1: rule__Mission__Group__11__Impl : ( ( rule__Mission__Group_11__0 )? ) ;
    public final void rule__Mission__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1368:1: ( ( ( rule__Mission__Group_11__0 )? ) )
            // InternalScSl.g:1369:1: ( ( rule__Mission__Group_11__0 )? )
            {
            // InternalScSl.g:1369:1: ( ( rule__Mission__Group_11__0 )? )
            // InternalScSl.g:1370:2: ( rule__Mission__Group_11__0 )?
            {
             before(grammarAccess.getMissionAccess().getGroup_11()); 
            // InternalScSl.g:1371:2: ( rule__Mission__Group_11__0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==30) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalScSl.g:1371:3: rule__Mission__Group_11__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mission__Group_11__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMissionAccess().getGroup_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__11__Impl"


    // $ANTLR start "rule__Mission__Group__12"
    // InternalScSl.g:1379:1: rule__Mission__Group__12 : rule__Mission__Group__12__Impl rule__Mission__Group__13 ;
    public final void rule__Mission__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1383:1: ( rule__Mission__Group__12__Impl rule__Mission__Group__13 )
            // InternalScSl.g:1384:2: rule__Mission__Group__12__Impl rule__Mission__Group__13
            {
            pushFollow(FOLLOW_8);
            rule__Mission__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__12"


    // $ANTLR start "rule__Mission__Group__12__Impl"
    // InternalScSl.g:1391:1: rule__Mission__Group__12__Impl : ( 'Tasks' ) ;
    public final void rule__Mission__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1395:1: ( ( 'Tasks' ) )
            // InternalScSl.g:1396:1: ( 'Tasks' )
            {
            // InternalScSl.g:1396:1: ( 'Tasks' )
            // InternalScSl.g:1397:2: 'Tasks'
            {
             before(grammarAccess.getMissionAccess().getTasksKeyword_12()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getTasksKeyword_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__12__Impl"


    // $ANTLR start "rule__Mission__Group__13"
    // InternalScSl.g:1406:1: rule__Mission__Group__13 : rule__Mission__Group__13__Impl ;
    public final void rule__Mission__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1410:1: ( rule__Mission__Group__13__Impl )
            // InternalScSl.g:1411:2: rule__Mission__Group__13__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group__13__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__13"


    // $ANTLR start "rule__Mission__Group__13__Impl"
    // InternalScSl.g:1417:1: rule__Mission__Group__13__Impl : ( ( ( rule__Mission__TasksAssignment_13 ) ) ( ( rule__Mission__TasksAssignment_13 )* ) ) ;
    public final void rule__Mission__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1421:1: ( ( ( ( rule__Mission__TasksAssignment_13 ) ) ( ( rule__Mission__TasksAssignment_13 )* ) ) )
            // InternalScSl.g:1422:1: ( ( ( rule__Mission__TasksAssignment_13 ) ) ( ( rule__Mission__TasksAssignment_13 )* ) )
            {
            // InternalScSl.g:1422:1: ( ( ( rule__Mission__TasksAssignment_13 ) ) ( ( rule__Mission__TasksAssignment_13 )* ) )
            // InternalScSl.g:1423:2: ( ( rule__Mission__TasksAssignment_13 ) ) ( ( rule__Mission__TasksAssignment_13 )* )
            {
            // InternalScSl.g:1423:2: ( ( rule__Mission__TasksAssignment_13 ) )
            // InternalScSl.g:1424:3: ( rule__Mission__TasksAssignment_13 )
            {
             before(grammarAccess.getMissionAccess().getTasksAssignment_13()); 
            // InternalScSl.g:1425:3: ( rule__Mission__TasksAssignment_13 )
            // InternalScSl.g:1425:4: rule__Mission__TasksAssignment_13
            {
            pushFollow(FOLLOW_9);
            rule__Mission__TasksAssignment_13();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getTasksAssignment_13()); 

            }

            // InternalScSl.g:1428:2: ( ( rule__Mission__TasksAssignment_13 )* )
            // InternalScSl.g:1429:3: ( rule__Mission__TasksAssignment_13 )*
            {
             before(grammarAccess.getMissionAccess().getTasksAssignment_13()); 
            // InternalScSl.g:1430:3: ( rule__Mission__TasksAssignment_13 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==36) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalScSl.g:1430:4: rule__Mission__TasksAssignment_13
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Mission__TasksAssignment_13();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getMissionAccess().getTasksAssignment_13()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group__13__Impl"


    // $ANTLR start "rule__Mission__Group_2__0"
    // InternalScSl.g:1440:1: rule__Mission__Group_2__0 : rule__Mission__Group_2__0__Impl rule__Mission__Group_2__1 ;
    public final void rule__Mission__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1444:1: ( rule__Mission__Group_2__0__Impl rule__Mission__Group_2__1 )
            // InternalScSl.g:1445:2: rule__Mission__Group_2__0__Impl rule__Mission__Group_2__1
            {
            pushFollow(FOLLOW_10);
            rule__Mission__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_2__0"


    // $ANTLR start "rule__Mission__Group_2__0__Impl"
    // InternalScSl.g:1452:1: rule__Mission__Group_2__0__Impl : ( 'Achievements' ) ;
    public final void rule__Mission__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1456:1: ( ( 'Achievements' ) )
            // InternalScSl.g:1457:1: ( 'Achievements' )
            {
            // InternalScSl.g:1457:1: ( 'Achievements' )
            // InternalScSl.g:1458:2: 'Achievements'
            {
             before(grammarAccess.getMissionAccess().getAchievementsKeyword_2_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getAchievementsKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_2__0__Impl"


    // $ANTLR start "rule__Mission__Group_2__1"
    // InternalScSl.g:1467:1: rule__Mission__Group_2__1 : rule__Mission__Group_2__1__Impl ;
    public final void rule__Mission__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1471:1: ( rule__Mission__Group_2__1__Impl )
            // InternalScSl.g:1472:2: rule__Mission__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_2__1"


    // $ANTLR start "rule__Mission__Group_2__1__Impl"
    // InternalScSl.g:1478:1: rule__Mission__Group_2__1__Impl : ( ( rule__Mission__AchievementsAssignment_2_1 )* ) ;
    public final void rule__Mission__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1482:1: ( ( ( rule__Mission__AchievementsAssignment_2_1 )* ) )
            // InternalScSl.g:1483:1: ( ( rule__Mission__AchievementsAssignment_2_1 )* )
            {
            // InternalScSl.g:1483:1: ( ( rule__Mission__AchievementsAssignment_2_1 )* )
            // InternalScSl.g:1484:2: ( rule__Mission__AchievementsAssignment_2_1 )*
            {
             before(grammarAccess.getMissionAccess().getAchievementsAssignment_2_1()); 
            // InternalScSl.g:1485:2: ( rule__Mission__AchievementsAssignment_2_1 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==RULE_INT) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalScSl.g:1485:3: rule__Mission__AchievementsAssignment_2_1
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__Mission__AchievementsAssignment_2_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getMissionAccess().getAchievementsAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_2__1__Impl"


    // $ANTLR start "rule__Mission__Group_4__0"
    // InternalScSl.g:1494:1: rule__Mission__Group_4__0 : rule__Mission__Group_4__0__Impl rule__Mission__Group_4__1 ;
    public final void rule__Mission__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1498:1: ( rule__Mission__Group_4__0__Impl rule__Mission__Group_4__1 )
            // InternalScSl.g:1499:2: rule__Mission__Group_4__0__Impl rule__Mission__Group_4__1
            {
            pushFollow(FOLLOW_10);
            rule__Mission__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_4__0"


    // $ANTLR start "rule__Mission__Group_4__0__Impl"
    // InternalScSl.g:1506:1: rule__Mission__Group_4__0__Impl : ( 'Drive_speed' ) ;
    public final void rule__Mission__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1510:1: ( ( 'Drive_speed' ) )
            // InternalScSl.g:1511:1: ( 'Drive_speed' )
            {
            // InternalScSl.g:1511:1: ( 'Drive_speed' )
            // InternalScSl.g:1512:2: 'Drive_speed'
            {
             before(grammarAccess.getMissionAccess().getDrive_speedKeyword_4_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getDrive_speedKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_4__0__Impl"


    // $ANTLR start "rule__Mission__Group_4__1"
    // InternalScSl.g:1521:1: rule__Mission__Group_4__1 : rule__Mission__Group_4__1__Impl ;
    public final void rule__Mission__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1525:1: ( rule__Mission__Group_4__1__Impl )
            // InternalScSl.g:1526:2: rule__Mission__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_4__1"


    // $ANTLR start "rule__Mission__Group_4__1__Impl"
    // InternalScSl.g:1532:1: rule__Mission__Group_4__1__Impl : ( ( rule__Mission__Drive_speedAssignment_4_1 ) ) ;
    public final void rule__Mission__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1536:1: ( ( ( rule__Mission__Drive_speedAssignment_4_1 ) ) )
            // InternalScSl.g:1537:1: ( ( rule__Mission__Drive_speedAssignment_4_1 ) )
            {
            // InternalScSl.g:1537:1: ( ( rule__Mission__Drive_speedAssignment_4_1 ) )
            // InternalScSl.g:1538:2: ( rule__Mission__Drive_speedAssignment_4_1 )
            {
             before(grammarAccess.getMissionAccess().getDrive_speedAssignment_4_1()); 
            // InternalScSl.g:1539:2: ( rule__Mission__Drive_speedAssignment_4_1 )
            // InternalScSl.g:1539:3: rule__Mission__Drive_speedAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Drive_speedAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getDrive_speedAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_4__1__Impl"


    // $ANTLR start "rule__Mission__Group_5__0"
    // InternalScSl.g:1548:1: rule__Mission__Group_5__0 : rule__Mission__Group_5__0__Impl rule__Mission__Group_5__1 ;
    public final void rule__Mission__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1552:1: ( rule__Mission__Group_5__0__Impl rule__Mission__Group_5__1 )
            // InternalScSl.g:1553:2: rule__Mission__Group_5__0__Impl rule__Mission__Group_5__1
            {
            pushFollow(FOLLOW_10);
            rule__Mission__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_5__0"


    // $ANTLR start "rule__Mission__Group_5__0__Impl"
    // InternalScSl.g:1560:1: rule__Mission__Group_5__0__Impl : ( 'Turn_speed' ) ;
    public final void rule__Mission__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1564:1: ( ( 'Turn_speed' ) )
            // InternalScSl.g:1565:1: ( 'Turn_speed' )
            {
            // InternalScSl.g:1565:1: ( 'Turn_speed' )
            // InternalScSl.g:1566:2: 'Turn_speed'
            {
             before(grammarAccess.getMissionAccess().getTurn_speedKeyword_5_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getTurn_speedKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_5__0__Impl"


    // $ANTLR start "rule__Mission__Group_5__1"
    // InternalScSl.g:1575:1: rule__Mission__Group_5__1 : rule__Mission__Group_5__1__Impl ;
    public final void rule__Mission__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1579:1: ( rule__Mission__Group_5__1__Impl )
            // InternalScSl.g:1580:2: rule__Mission__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_5__1"


    // $ANTLR start "rule__Mission__Group_5__1__Impl"
    // InternalScSl.g:1586:1: rule__Mission__Group_5__1__Impl : ( ( rule__Mission__Turn_speedAssignment_5_1 ) ) ;
    public final void rule__Mission__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1590:1: ( ( ( rule__Mission__Turn_speedAssignment_5_1 ) ) )
            // InternalScSl.g:1591:1: ( ( rule__Mission__Turn_speedAssignment_5_1 ) )
            {
            // InternalScSl.g:1591:1: ( ( rule__Mission__Turn_speedAssignment_5_1 ) )
            // InternalScSl.g:1592:2: ( rule__Mission__Turn_speedAssignment_5_1 )
            {
             before(grammarAccess.getMissionAccess().getTurn_speedAssignment_5_1()); 
            // InternalScSl.g:1593:2: ( rule__Mission__Turn_speedAssignment_5_1 )
            // InternalScSl.g:1593:3: rule__Mission__Turn_speedAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Turn_speedAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getTurn_speedAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_5__1__Impl"


    // $ANTLR start "rule__Mission__Group_6__0"
    // InternalScSl.g:1602:1: rule__Mission__Group_6__0 : rule__Mission__Group_6__0__Impl rule__Mission__Group_6__1 ;
    public final void rule__Mission__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1606:1: ( rule__Mission__Group_6__0__Impl rule__Mission__Group_6__1 )
            // InternalScSl.g:1607:2: rule__Mission__Group_6__0__Impl rule__Mission__Group_6__1
            {
            pushFollow(FOLLOW_12);
            rule__Mission__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_6__0"


    // $ANTLR start "rule__Mission__Group_6__0__Impl"
    // InternalScSl.g:1614:1: rule__Mission__Group_6__0__Impl : ( 'Sensor_distance_front' ) ;
    public final void rule__Mission__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1618:1: ( ( 'Sensor_distance_front' ) )
            // InternalScSl.g:1619:1: ( 'Sensor_distance_front' )
            {
            // InternalScSl.g:1619:1: ( 'Sensor_distance_front' )
            // InternalScSl.g:1620:2: 'Sensor_distance_front'
            {
             before(grammarAccess.getMissionAccess().getSensor_distance_frontKeyword_6_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getSensor_distance_frontKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_6__0__Impl"


    // $ANTLR start "rule__Mission__Group_6__1"
    // InternalScSl.g:1629:1: rule__Mission__Group_6__1 : rule__Mission__Group_6__1__Impl ;
    public final void rule__Mission__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1633:1: ( rule__Mission__Group_6__1__Impl )
            // InternalScSl.g:1634:2: rule__Mission__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_6__1"


    // $ANTLR start "rule__Mission__Group_6__1__Impl"
    // InternalScSl.g:1640:1: rule__Mission__Group_6__1__Impl : ( ( rule__Mission__Sensor_dist_frontAssignment_6_1 ) ) ;
    public final void rule__Mission__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1644:1: ( ( ( rule__Mission__Sensor_dist_frontAssignment_6_1 ) ) )
            // InternalScSl.g:1645:1: ( ( rule__Mission__Sensor_dist_frontAssignment_6_1 ) )
            {
            // InternalScSl.g:1645:1: ( ( rule__Mission__Sensor_dist_frontAssignment_6_1 ) )
            // InternalScSl.g:1646:2: ( rule__Mission__Sensor_dist_frontAssignment_6_1 )
            {
             before(grammarAccess.getMissionAccess().getSensor_dist_frontAssignment_6_1()); 
            // InternalScSl.g:1647:2: ( rule__Mission__Sensor_dist_frontAssignment_6_1 )
            // InternalScSl.g:1647:3: rule__Mission__Sensor_dist_frontAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Sensor_dist_frontAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getSensor_dist_frontAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_6__1__Impl"


    // $ANTLR start "rule__Mission__Group_7__0"
    // InternalScSl.g:1656:1: rule__Mission__Group_7__0 : rule__Mission__Group_7__0__Impl rule__Mission__Group_7__1 ;
    public final void rule__Mission__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1660:1: ( rule__Mission__Group_7__0__Impl rule__Mission__Group_7__1 )
            // InternalScSl.g:1661:2: rule__Mission__Group_7__0__Impl rule__Mission__Group_7__1
            {
            pushFollow(FOLLOW_12);
            rule__Mission__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_7__0"


    // $ANTLR start "rule__Mission__Group_7__0__Impl"
    // InternalScSl.g:1668:1: rule__Mission__Group_7__0__Impl : ( 'Sensor_distance_right' ) ;
    public final void rule__Mission__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1672:1: ( ( 'Sensor_distance_right' ) )
            // InternalScSl.g:1673:1: ( 'Sensor_distance_right' )
            {
            // InternalScSl.g:1673:1: ( 'Sensor_distance_right' )
            // InternalScSl.g:1674:2: 'Sensor_distance_right'
            {
             before(grammarAccess.getMissionAccess().getSensor_distance_rightKeyword_7_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getSensor_distance_rightKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_7__0__Impl"


    // $ANTLR start "rule__Mission__Group_7__1"
    // InternalScSl.g:1683:1: rule__Mission__Group_7__1 : rule__Mission__Group_7__1__Impl ;
    public final void rule__Mission__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1687:1: ( rule__Mission__Group_7__1__Impl )
            // InternalScSl.g:1688:2: rule__Mission__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_7__1"


    // $ANTLR start "rule__Mission__Group_7__1__Impl"
    // InternalScSl.g:1694:1: rule__Mission__Group_7__1__Impl : ( ( rule__Mission__Sensor_dist_rightAssignment_7_1 ) ) ;
    public final void rule__Mission__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1698:1: ( ( ( rule__Mission__Sensor_dist_rightAssignment_7_1 ) ) )
            // InternalScSl.g:1699:1: ( ( rule__Mission__Sensor_dist_rightAssignment_7_1 ) )
            {
            // InternalScSl.g:1699:1: ( ( rule__Mission__Sensor_dist_rightAssignment_7_1 ) )
            // InternalScSl.g:1700:2: ( rule__Mission__Sensor_dist_rightAssignment_7_1 )
            {
             before(grammarAccess.getMissionAccess().getSensor_dist_rightAssignment_7_1()); 
            // InternalScSl.g:1701:2: ( rule__Mission__Sensor_dist_rightAssignment_7_1 )
            // InternalScSl.g:1701:3: rule__Mission__Sensor_dist_rightAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Sensor_dist_rightAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getSensor_dist_rightAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_7__1__Impl"


    // $ANTLR start "rule__Mission__Group_8__0"
    // InternalScSl.g:1710:1: rule__Mission__Group_8__0 : rule__Mission__Group_8__0__Impl rule__Mission__Group_8__1 ;
    public final void rule__Mission__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1714:1: ( rule__Mission__Group_8__0__Impl rule__Mission__Group_8__1 )
            // InternalScSl.g:1715:2: rule__Mission__Group_8__0__Impl rule__Mission__Group_8__1
            {
            pushFollow(FOLLOW_13);
            rule__Mission__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_8__0"


    // $ANTLR start "rule__Mission__Group_8__0__Impl"
    // InternalScSl.g:1722:1: rule__Mission__Group_8__0__Impl : ( 'Sensor_color_left' ) ;
    public final void rule__Mission__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1726:1: ( ( 'Sensor_color_left' ) )
            // InternalScSl.g:1727:1: ( 'Sensor_color_left' )
            {
            // InternalScSl.g:1727:1: ( 'Sensor_color_left' )
            // InternalScSl.g:1728:2: 'Sensor_color_left'
            {
             before(grammarAccess.getMissionAccess().getSensor_color_leftKeyword_8_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getSensor_color_leftKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_8__0__Impl"


    // $ANTLR start "rule__Mission__Group_8__1"
    // InternalScSl.g:1737:1: rule__Mission__Group_8__1 : rule__Mission__Group_8__1__Impl ;
    public final void rule__Mission__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1741:1: ( rule__Mission__Group_8__1__Impl )
            // InternalScSl.g:1742:2: rule__Mission__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_8__1"


    // $ANTLR start "rule__Mission__Group_8__1__Impl"
    // InternalScSl.g:1748:1: rule__Mission__Group_8__1__Impl : ( ( rule__Mission__Sensor_color_leftAssignment_8_1 ) ) ;
    public final void rule__Mission__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1752:1: ( ( ( rule__Mission__Sensor_color_leftAssignment_8_1 ) ) )
            // InternalScSl.g:1753:1: ( ( rule__Mission__Sensor_color_leftAssignment_8_1 ) )
            {
            // InternalScSl.g:1753:1: ( ( rule__Mission__Sensor_color_leftAssignment_8_1 ) )
            // InternalScSl.g:1754:2: ( rule__Mission__Sensor_color_leftAssignment_8_1 )
            {
             before(grammarAccess.getMissionAccess().getSensor_color_leftAssignment_8_1()); 
            // InternalScSl.g:1755:2: ( rule__Mission__Sensor_color_leftAssignment_8_1 )
            // InternalScSl.g:1755:3: rule__Mission__Sensor_color_leftAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Sensor_color_leftAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getSensor_color_leftAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_8__1__Impl"


    // $ANTLR start "rule__Mission__Group_9__0"
    // InternalScSl.g:1764:1: rule__Mission__Group_9__0 : rule__Mission__Group_9__0__Impl rule__Mission__Group_9__1 ;
    public final void rule__Mission__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1768:1: ( rule__Mission__Group_9__0__Impl rule__Mission__Group_9__1 )
            // InternalScSl.g:1769:2: rule__Mission__Group_9__0__Impl rule__Mission__Group_9__1
            {
            pushFollow(FOLLOW_13);
            rule__Mission__Group_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_9__0"


    // $ANTLR start "rule__Mission__Group_9__0__Impl"
    // InternalScSl.g:1776:1: rule__Mission__Group_9__0__Impl : ( 'Sensor_color_right' ) ;
    public final void rule__Mission__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1780:1: ( ( 'Sensor_color_right' ) )
            // InternalScSl.g:1781:1: ( 'Sensor_color_right' )
            {
            // InternalScSl.g:1781:1: ( 'Sensor_color_right' )
            // InternalScSl.g:1782:2: 'Sensor_color_right'
            {
             before(grammarAccess.getMissionAccess().getSensor_color_rightKeyword_9_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getSensor_color_rightKeyword_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_9__0__Impl"


    // $ANTLR start "rule__Mission__Group_9__1"
    // InternalScSl.g:1791:1: rule__Mission__Group_9__1 : rule__Mission__Group_9__1__Impl ;
    public final void rule__Mission__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1795:1: ( rule__Mission__Group_9__1__Impl )
            // InternalScSl.g:1796:2: rule__Mission__Group_9__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_9__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_9__1"


    // $ANTLR start "rule__Mission__Group_9__1__Impl"
    // InternalScSl.g:1802:1: rule__Mission__Group_9__1__Impl : ( ( rule__Mission__Sensor_color_rightAssignment_9_1 ) ) ;
    public final void rule__Mission__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1806:1: ( ( ( rule__Mission__Sensor_color_rightAssignment_9_1 ) ) )
            // InternalScSl.g:1807:1: ( ( rule__Mission__Sensor_color_rightAssignment_9_1 ) )
            {
            // InternalScSl.g:1807:1: ( ( rule__Mission__Sensor_color_rightAssignment_9_1 ) )
            // InternalScSl.g:1808:2: ( rule__Mission__Sensor_color_rightAssignment_9_1 )
            {
             before(grammarAccess.getMissionAccess().getSensor_color_rightAssignment_9_1()); 
            // InternalScSl.g:1809:2: ( rule__Mission__Sensor_color_rightAssignment_9_1 )
            // InternalScSl.g:1809:3: rule__Mission__Sensor_color_rightAssignment_9_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Sensor_color_rightAssignment_9_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getSensor_color_rightAssignment_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_9__1__Impl"


    // $ANTLR start "rule__Mission__Group_10__0"
    // InternalScSl.g:1818:1: rule__Mission__Group_10__0 : rule__Mission__Group_10__0__Impl rule__Mission__Group_10__1 ;
    public final void rule__Mission__Group_10__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1822:1: ( rule__Mission__Group_10__0__Impl rule__Mission__Group_10__1 )
            // InternalScSl.g:1823:2: rule__Mission__Group_10__0__Impl rule__Mission__Group_10__1
            {
            pushFollow(FOLLOW_14);
            rule__Mission__Group_10__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_10__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_10__0"


    // $ANTLR start "rule__Mission__Group_10__0__Impl"
    // InternalScSl.g:1830:1: rule__Mission__Group_10__0__Impl : ( 'Motor_left_pins' ) ;
    public final void rule__Mission__Group_10__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1834:1: ( ( 'Motor_left_pins' ) )
            // InternalScSl.g:1835:1: ( 'Motor_left_pins' )
            {
            // InternalScSl.g:1835:1: ( 'Motor_left_pins' )
            // InternalScSl.g:1836:2: 'Motor_left_pins'
            {
             before(grammarAccess.getMissionAccess().getMotor_left_pinsKeyword_10_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getMotor_left_pinsKeyword_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_10__0__Impl"


    // $ANTLR start "rule__Mission__Group_10__1"
    // InternalScSl.g:1845:1: rule__Mission__Group_10__1 : rule__Mission__Group_10__1__Impl ;
    public final void rule__Mission__Group_10__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1849:1: ( rule__Mission__Group_10__1__Impl )
            // InternalScSl.g:1850:2: rule__Mission__Group_10__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_10__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_10__1"


    // $ANTLR start "rule__Mission__Group_10__1__Impl"
    // InternalScSl.g:1856:1: rule__Mission__Group_10__1__Impl : ( ( rule__Mission__Motor_leftAssignment_10_1 ) ) ;
    public final void rule__Mission__Group_10__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1860:1: ( ( ( rule__Mission__Motor_leftAssignment_10_1 ) ) )
            // InternalScSl.g:1861:1: ( ( rule__Mission__Motor_leftAssignment_10_1 ) )
            {
            // InternalScSl.g:1861:1: ( ( rule__Mission__Motor_leftAssignment_10_1 ) )
            // InternalScSl.g:1862:2: ( rule__Mission__Motor_leftAssignment_10_1 )
            {
             before(grammarAccess.getMissionAccess().getMotor_leftAssignment_10_1()); 
            // InternalScSl.g:1863:2: ( rule__Mission__Motor_leftAssignment_10_1 )
            // InternalScSl.g:1863:3: rule__Mission__Motor_leftAssignment_10_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Motor_leftAssignment_10_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getMotor_leftAssignment_10_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_10__1__Impl"


    // $ANTLR start "rule__Mission__Group_11__0"
    // InternalScSl.g:1872:1: rule__Mission__Group_11__0 : rule__Mission__Group_11__0__Impl rule__Mission__Group_11__1 ;
    public final void rule__Mission__Group_11__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1876:1: ( rule__Mission__Group_11__0__Impl rule__Mission__Group_11__1 )
            // InternalScSl.g:1877:2: rule__Mission__Group_11__0__Impl rule__Mission__Group_11__1
            {
            pushFollow(FOLLOW_14);
            rule__Mission__Group_11__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mission__Group_11__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_11__0"


    // $ANTLR start "rule__Mission__Group_11__0__Impl"
    // InternalScSl.g:1884:1: rule__Mission__Group_11__0__Impl : ( 'Motor_right_pins' ) ;
    public final void rule__Mission__Group_11__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1888:1: ( ( 'Motor_right_pins' ) )
            // InternalScSl.g:1889:1: ( 'Motor_right_pins' )
            {
            // InternalScSl.g:1889:1: ( 'Motor_right_pins' )
            // InternalScSl.g:1890:2: 'Motor_right_pins'
            {
             before(grammarAccess.getMissionAccess().getMotor_right_pinsKeyword_11_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getMotor_right_pinsKeyword_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_11__0__Impl"


    // $ANTLR start "rule__Mission__Group_11__1"
    // InternalScSl.g:1899:1: rule__Mission__Group_11__1 : rule__Mission__Group_11__1__Impl ;
    public final void rule__Mission__Group_11__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1903:1: ( rule__Mission__Group_11__1__Impl )
            // InternalScSl.g:1904:2: rule__Mission__Group_11__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Group_11__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_11__1"


    // $ANTLR start "rule__Mission__Group_11__1__Impl"
    // InternalScSl.g:1910:1: rule__Mission__Group_11__1__Impl : ( ( rule__Mission__Motor_rightAssignment_11_1 ) ) ;
    public final void rule__Mission__Group_11__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1914:1: ( ( ( rule__Mission__Motor_rightAssignment_11_1 ) ) )
            // InternalScSl.g:1915:1: ( ( rule__Mission__Motor_rightAssignment_11_1 ) )
            {
            // InternalScSl.g:1915:1: ( ( rule__Mission__Motor_rightAssignment_11_1 ) )
            // InternalScSl.g:1916:2: ( rule__Mission__Motor_rightAssignment_11_1 )
            {
             before(grammarAccess.getMissionAccess().getMotor_rightAssignment_11_1()); 
            // InternalScSl.g:1917:2: ( rule__Mission__Motor_rightAssignment_11_1 )
            // InternalScSl.g:1917:3: rule__Mission__Motor_rightAssignment_11_1
            {
            pushFollow(FOLLOW_2);
            rule__Mission__Motor_rightAssignment_11_1();

            state._fsp--;


            }

             after(grammarAccess.getMissionAccess().getMotor_rightAssignment_11_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Group_11__1__Impl"


    // $ANTLR start "rule__Distance_Pins__Group__0"
    // InternalScSl.g:1926:1: rule__Distance_Pins__Group__0 : rule__Distance_Pins__Group__0__Impl rule__Distance_Pins__Group__1 ;
    public final void rule__Distance_Pins__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1930:1: ( rule__Distance_Pins__Group__0__Impl rule__Distance_Pins__Group__1 )
            // InternalScSl.g:1931:2: rule__Distance_Pins__Group__0__Impl rule__Distance_Pins__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__Distance_Pins__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Distance_Pins__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__0"


    // $ANTLR start "rule__Distance_Pins__Group__0__Impl"
    // InternalScSl.g:1938:1: rule__Distance_Pins__Group__0__Impl : ( 'Trigger_Pin' ) ;
    public final void rule__Distance_Pins__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1942:1: ( ( 'Trigger_Pin' ) )
            // InternalScSl.g:1943:1: ( 'Trigger_Pin' )
            {
            // InternalScSl.g:1943:1: ( 'Trigger_Pin' )
            // InternalScSl.g:1944:2: 'Trigger_Pin'
            {
             before(grammarAccess.getDistance_PinsAccess().getTrigger_PinKeyword_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getDistance_PinsAccess().getTrigger_PinKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__0__Impl"


    // $ANTLR start "rule__Distance_Pins__Group__1"
    // InternalScSl.g:1953:1: rule__Distance_Pins__Group__1 : rule__Distance_Pins__Group__1__Impl rule__Distance_Pins__Group__2 ;
    public final void rule__Distance_Pins__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1957:1: ( rule__Distance_Pins__Group__1__Impl rule__Distance_Pins__Group__2 )
            // InternalScSl.g:1958:2: rule__Distance_Pins__Group__1__Impl rule__Distance_Pins__Group__2
            {
            pushFollow(FOLLOW_15);
            rule__Distance_Pins__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Distance_Pins__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__1"


    // $ANTLR start "rule__Distance_Pins__Group__1__Impl"
    // InternalScSl.g:1965:1: rule__Distance_Pins__Group__1__Impl : ( ( rule__Distance_Pins__TriggerpinAssignment_1 ) ) ;
    public final void rule__Distance_Pins__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1969:1: ( ( ( rule__Distance_Pins__TriggerpinAssignment_1 ) ) )
            // InternalScSl.g:1970:1: ( ( rule__Distance_Pins__TriggerpinAssignment_1 ) )
            {
            // InternalScSl.g:1970:1: ( ( rule__Distance_Pins__TriggerpinAssignment_1 ) )
            // InternalScSl.g:1971:2: ( rule__Distance_Pins__TriggerpinAssignment_1 )
            {
             before(grammarAccess.getDistance_PinsAccess().getTriggerpinAssignment_1()); 
            // InternalScSl.g:1972:2: ( rule__Distance_Pins__TriggerpinAssignment_1 )
            // InternalScSl.g:1972:3: rule__Distance_Pins__TriggerpinAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Distance_Pins__TriggerpinAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDistance_PinsAccess().getTriggerpinAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__1__Impl"


    // $ANTLR start "rule__Distance_Pins__Group__2"
    // InternalScSl.g:1980:1: rule__Distance_Pins__Group__2 : rule__Distance_Pins__Group__2__Impl rule__Distance_Pins__Group__3 ;
    public final void rule__Distance_Pins__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1984:1: ( rule__Distance_Pins__Group__2__Impl rule__Distance_Pins__Group__3 )
            // InternalScSl.g:1985:2: rule__Distance_Pins__Group__2__Impl rule__Distance_Pins__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Distance_Pins__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Distance_Pins__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__2"


    // $ANTLR start "rule__Distance_Pins__Group__2__Impl"
    // InternalScSl.g:1992:1: rule__Distance_Pins__Group__2__Impl : ( 'Echo_Pin' ) ;
    public final void rule__Distance_Pins__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:1996:1: ( ( 'Echo_Pin' ) )
            // InternalScSl.g:1997:1: ( 'Echo_Pin' )
            {
            // InternalScSl.g:1997:1: ( 'Echo_Pin' )
            // InternalScSl.g:1998:2: 'Echo_Pin'
            {
             before(grammarAccess.getDistance_PinsAccess().getEcho_PinKeyword_2()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getDistance_PinsAccess().getEcho_PinKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__2__Impl"


    // $ANTLR start "rule__Distance_Pins__Group__3"
    // InternalScSl.g:2007:1: rule__Distance_Pins__Group__3 : rule__Distance_Pins__Group__3__Impl ;
    public final void rule__Distance_Pins__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2011:1: ( rule__Distance_Pins__Group__3__Impl )
            // InternalScSl.g:2012:2: rule__Distance_Pins__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Distance_Pins__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__3"


    // $ANTLR start "rule__Distance_Pins__Group__3__Impl"
    // InternalScSl.g:2018:1: rule__Distance_Pins__Group__3__Impl : ( ( rule__Distance_Pins__EchopinAssignment_3 ) ) ;
    public final void rule__Distance_Pins__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2022:1: ( ( ( rule__Distance_Pins__EchopinAssignment_3 ) ) )
            // InternalScSl.g:2023:1: ( ( rule__Distance_Pins__EchopinAssignment_3 ) )
            {
            // InternalScSl.g:2023:1: ( ( rule__Distance_Pins__EchopinAssignment_3 ) )
            // InternalScSl.g:2024:2: ( rule__Distance_Pins__EchopinAssignment_3 )
            {
             before(grammarAccess.getDistance_PinsAccess().getEchopinAssignment_3()); 
            // InternalScSl.g:2025:2: ( rule__Distance_Pins__EchopinAssignment_3 )
            // InternalScSl.g:2025:3: rule__Distance_Pins__EchopinAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Distance_Pins__EchopinAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getDistance_PinsAccess().getEchopinAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__Group__3__Impl"


    // $ANTLR start "rule__Color_Pin__Group__0"
    // InternalScSl.g:2034:1: rule__Color_Pin__Group__0 : rule__Color_Pin__Group__0__Impl rule__Color_Pin__Group__1 ;
    public final void rule__Color_Pin__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2038:1: ( rule__Color_Pin__Group__0__Impl rule__Color_Pin__Group__1 )
            // InternalScSl.g:2039:2: rule__Color_Pin__Group__0__Impl rule__Color_Pin__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Color_Pin__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Color_Pin__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Color_Pin__Group__0"


    // $ANTLR start "rule__Color_Pin__Group__0__Impl"
    // InternalScSl.g:2046:1: rule__Color_Pin__Group__0__Impl : ( 'Pin' ) ;
    public final void rule__Color_Pin__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2050:1: ( ( 'Pin' ) )
            // InternalScSl.g:2051:1: ( 'Pin' )
            {
            // InternalScSl.g:2051:1: ( 'Pin' )
            // InternalScSl.g:2052:2: 'Pin'
            {
             before(grammarAccess.getColor_PinAccess().getPinKeyword_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getColor_PinAccess().getPinKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Color_Pin__Group__0__Impl"


    // $ANTLR start "rule__Color_Pin__Group__1"
    // InternalScSl.g:2061:1: rule__Color_Pin__Group__1 : rule__Color_Pin__Group__1__Impl ;
    public final void rule__Color_Pin__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2065:1: ( rule__Color_Pin__Group__1__Impl )
            // InternalScSl.g:2066:2: rule__Color_Pin__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Color_Pin__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Color_Pin__Group__1"


    // $ANTLR start "rule__Color_Pin__Group__1__Impl"
    // InternalScSl.g:2072:1: rule__Color_Pin__Group__1__Impl : ( ( rule__Color_Pin__PinAssignment_1 ) ) ;
    public final void rule__Color_Pin__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2076:1: ( ( ( rule__Color_Pin__PinAssignment_1 ) ) )
            // InternalScSl.g:2077:1: ( ( rule__Color_Pin__PinAssignment_1 ) )
            {
            // InternalScSl.g:2077:1: ( ( rule__Color_Pin__PinAssignment_1 ) )
            // InternalScSl.g:2078:2: ( rule__Color_Pin__PinAssignment_1 )
            {
             before(grammarAccess.getColor_PinAccess().getPinAssignment_1()); 
            // InternalScSl.g:2079:2: ( rule__Color_Pin__PinAssignment_1 )
            // InternalScSl.g:2079:3: rule__Color_Pin__PinAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Color_Pin__PinAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getColor_PinAccess().getPinAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Color_Pin__Group__1__Impl"


    // $ANTLR start "rule__Motor_Pins__Group__0"
    // InternalScSl.g:2088:1: rule__Motor_Pins__Group__0 : rule__Motor_Pins__Group__0__Impl rule__Motor_Pins__Group__1 ;
    public final void rule__Motor_Pins__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2092:1: ( rule__Motor_Pins__Group__0__Impl rule__Motor_Pins__Group__1 )
            // InternalScSl.g:2093:2: rule__Motor_Pins__Group__0__Impl rule__Motor_Pins__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__Motor_Pins__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Motor_Pins__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__0"


    // $ANTLR start "rule__Motor_Pins__Group__0__Impl"
    // InternalScSl.g:2100:1: rule__Motor_Pins__Group__0__Impl : ( 'Input1_pin' ) ;
    public final void rule__Motor_Pins__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2104:1: ( ( 'Input1_pin' ) )
            // InternalScSl.g:2105:1: ( 'Input1_pin' )
            {
            // InternalScSl.g:2105:1: ( 'Input1_pin' )
            // InternalScSl.g:2106:2: 'Input1_pin'
            {
             before(grammarAccess.getMotor_PinsAccess().getInput1_pinKeyword_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getMotor_PinsAccess().getInput1_pinKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__0__Impl"


    // $ANTLR start "rule__Motor_Pins__Group__1"
    // InternalScSl.g:2115:1: rule__Motor_Pins__Group__1 : rule__Motor_Pins__Group__1__Impl rule__Motor_Pins__Group__2 ;
    public final void rule__Motor_Pins__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2119:1: ( rule__Motor_Pins__Group__1__Impl rule__Motor_Pins__Group__2 )
            // InternalScSl.g:2120:2: rule__Motor_Pins__Group__1__Impl rule__Motor_Pins__Group__2
            {
            pushFollow(FOLLOW_17);
            rule__Motor_Pins__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Motor_Pins__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__1"


    // $ANTLR start "rule__Motor_Pins__Group__1__Impl"
    // InternalScSl.g:2127:1: rule__Motor_Pins__Group__1__Impl : ( ( rule__Motor_Pins__In1_pinAssignment_1 ) ) ;
    public final void rule__Motor_Pins__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2131:1: ( ( ( rule__Motor_Pins__In1_pinAssignment_1 ) ) )
            // InternalScSl.g:2132:1: ( ( rule__Motor_Pins__In1_pinAssignment_1 ) )
            {
            // InternalScSl.g:2132:1: ( ( rule__Motor_Pins__In1_pinAssignment_1 ) )
            // InternalScSl.g:2133:2: ( rule__Motor_Pins__In1_pinAssignment_1 )
            {
             before(grammarAccess.getMotor_PinsAccess().getIn1_pinAssignment_1()); 
            // InternalScSl.g:2134:2: ( rule__Motor_Pins__In1_pinAssignment_1 )
            // InternalScSl.g:2134:3: rule__Motor_Pins__In1_pinAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Motor_Pins__In1_pinAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getMotor_PinsAccess().getIn1_pinAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__1__Impl"


    // $ANTLR start "rule__Motor_Pins__Group__2"
    // InternalScSl.g:2142:1: rule__Motor_Pins__Group__2 : rule__Motor_Pins__Group__2__Impl rule__Motor_Pins__Group__3 ;
    public final void rule__Motor_Pins__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2146:1: ( rule__Motor_Pins__Group__2__Impl rule__Motor_Pins__Group__3 )
            // InternalScSl.g:2147:2: rule__Motor_Pins__Group__2__Impl rule__Motor_Pins__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Motor_Pins__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Motor_Pins__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__2"


    // $ANTLR start "rule__Motor_Pins__Group__2__Impl"
    // InternalScSl.g:2154:1: rule__Motor_Pins__Group__2__Impl : ( 'Input2_pin' ) ;
    public final void rule__Motor_Pins__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2158:1: ( ( 'Input2_pin' ) )
            // InternalScSl.g:2159:1: ( 'Input2_pin' )
            {
            // InternalScSl.g:2159:1: ( 'Input2_pin' )
            // InternalScSl.g:2160:2: 'Input2_pin'
            {
             before(grammarAccess.getMotor_PinsAccess().getInput2_pinKeyword_2()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getMotor_PinsAccess().getInput2_pinKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__2__Impl"


    // $ANTLR start "rule__Motor_Pins__Group__3"
    // InternalScSl.g:2169:1: rule__Motor_Pins__Group__3 : rule__Motor_Pins__Group__3__Impl ;
    public final void rule__Motor_Pins__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2173:1: ( rule__Motor_Pins__Group__3__Impl )
            // InternalScSl.g:2174:2: rule__Motor_Pins__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Motor_Pins__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__3"


    // $ANTLR start "rule__Motor_Pins__Group__3__Impl"
    // InternalScSl.g:2180:1: rule__Motor_Pins__Group__3__Impl : ( ( rule__Motor_Pins__In2_pinAssignment_3 ) ) ;
    public final void rule__Motor_Pins__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2184:1: ( ( ( rule__Motor_Pins__In2_pinAssignment_3 ) ) )
            // InternalScSl.g:2185:1: ( ( rule__Motor_Pins__In2_pinAssignment_3 ) )
            {
            // InternalScSl.g:2185:1: ( ( rule__Motor_Pins__In2_pinAssignment_3 ) )
            // InternalScSl.g:2186:2: ( rule__Motor_Pins__In2_pinAssignment_3 )
            {
             before(grammarAccess.getMotor_PinsAccess().getIn2_pinAssignment_3()); 
            // InternalScSl.g:2187:2: ( rule__Motor_Pins__In2_pinAssignment_3 )
            // InternalScSl.g:2187:3: rule__Motor_Pins__In2_pinAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Motor_Pins__In2_pinAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getMotor_PinsAccess().getIn2_pinAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__Group__3__Impl"


    // $ANTLR start "rule__Task__Group__0"
    // InternalScSl.g:2196:1: rule__Task__Group__0 : rule__Task__Group__0__Impl rule__Task__Group__1 ;
    public final void rule__Task__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2200:1: ( rule__Task__Group__0__Impl rule__Task__Group__1 )
            // InternalScSl.g:2201:2: rule__Task__Group__0__Impl rule__Task__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Task__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Task__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__0"


    // $ANTLR start "rule__Task__Group__0__Impl"
    // InternalScSl.g:2208:1: rule__Task__Group__0__Impl : ( 'Task' ) ;
    public final void rule__Task__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2212:1: ( ( 'Task' ) )
            // InternalScSl.g:2213:1: ( 'Task' )
            {
            // InternalScSl.g:2213:1: ( 'Task' )
            // InternalScSl.g:2214:2: 'Task'
            {
             before(grammarAccess.getTaskAccess().getTaskKeyword_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getTaskAccess().getTaskKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__0__Impl"


    // $ANTLR start "rule__Task__Group__1"
    // InternalScSl.g:2223:1: rule__Task__Group__1 : rule__Task__Group__1__Impl rule__Task__Group__2 ;
    public final void rule__Task__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2227:1: ( rule__Task__Group__1__Impl rule__Task__Group__2 )
            // InternalScSl.g:2228:2: rule__Task__Group__1__Impl rule__Task__Group__2
            {
            pushFollow(FOLLOW_18);
            rule__Task__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Task__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__1"


    // $ANTLR start "rule__Task__Group__1__Impl"
    // InternalScSl.g:2235:1: rule__Task__Group__1__Impl : ( ( rule__Task__NameAssignment_1 ) ) ;
    public final void rule__Task__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2239:1: ( ( ( rule__Task__NameAssignment_1 ) ) )
            // InternalScSl.g:2240:1: ( ( rule__Task__NameAssignment_1 ) )
            {
            // InternalScSl.g:2240:1: ( ( rule__Task__NameAssignment_1 ) )
            // InternalScSl.g:2241:2: ( rule__Task__NameAssignment_1 )
            {
             before(grammarAccess.getTaskAccess().getNameAssignment_1()); 
            // InternalScSl.g:2242:2: ( rule__Task__NameAssignment_1 )
            // InternalScSl.g:2242:3: rule__Task__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Task__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getTaskAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__1__Impl"


    // $ANTLR start "rule__Task__Group__2"
    // InternalScSl.g:2250:1: rule__Task__Group__2 : rule__Task__Group__2__Impl rule__Task__Group__3 ;
    public final void rule__Task__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2254:1: ( rule__Task__Group__2__Impl rule__Task__Group__3 )
            // InternalScSl.g:2255:2: rule__Task__Group__2__Impl rule__Task__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Task__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Task__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__2"


    // $ANTLR start "rule__Task__Group__2__Impl"
    // InternalScSl.g:2262:1: rule__Task__Group__2__Impl : ( 'priority' ) ;
    public final void rule__Task__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2266:1: ( ( 'priority' ) )
            // InternalScSl.g:2267:1: ( 'priority' )
            {
            // InternalScSl.g:2267:1: ( 'priority' )
            // InternalScSl.g:2268:2: 'priority'
            {
             before(grammarAccess.getTaskAccess().getPriorityKeyword_2()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getTaskAccess().getPriorityKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__2__Impl"


    // $ANTLR start "rule__Task__Group__3"
    // InternalScSl.g:2277:1: rule__Task__Group__3 : rule__Task__Group__3__Impl rule__Task__Group__4 ;
    public final void rule__Task__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2281:1: ( rule__Task__Group__3__Impl rule__Task__Group__4 )
            // InternalScSl.g:2282:2: rule__Task__Group__3__Impl rule__Task__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__Task__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Task__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__3"


    // $ANTLR start "rule__Task__Group__3__Impl"
    // InternalScSl.g:2289:1: rule__Task__Group__3__Impl : ( ( rule__Task__PriorityAssignment_3 ) ) ;
    public final void rule__Task__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2293:1: ( ( ( rule__Task__PriorityAssignment_3 ) ) )
            // InternalScSl.g:2294:1: ( ( rule__Task__PriorityAssignment_3 ) )
            {
            // InternalScSl.g:2294:1: ( ( rule__Task__PriorityAssignment_3 ) )
            // InternalScSl.g:2295:2: ( rule__Task__PriorityAssignment_3 )
            {
             before(grammarAccess.getTaskAccess().getPriorityAssignment_3()); 
            // InternalScSl.g:2296:2: ( rule__Task__PriorityAssignment_3 )
            // InternalScSl.g:2296:3: rule__Task__PriorityAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Task__PriorityAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getTaskAccess().getPriorityAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__3__Impl"


    // $ANTLR start "rule__Task__Group__4"
    // InternalScSl.g:2304:1: rule__Task__Group__4 : rule__Task__Group__4__Impl rule__Task__Group__5 ;
    public final void rule__Task__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2308:1: ( rule__Task__Group__4__Impl rule__Task__Group__5 )
            // InternalScSl.g:2309:2: rule__Task__Group__4__Impl rule__Task__Group__5
            {
            pushFollow(FOLLOW_19);
            rule__Task__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Task__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__4"


    // $ANTLR start "rule__Task__Group__4__Impl"
    // InternalScSl.g:2316:1: rule__Task__Group__4__Impl : ( ( rule__Task__Starting_condsAssignment_4 )* ) ;
    public final void rule__Task__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2320:1: ( ( ( rule__Task__Starting_condsAssignment_4 )* ) )
            // InternalScSl.g:2321:1: ( ( rule__Task__Starting_condsAssignment_4 )* )
            {
            // InternalScSl.g:2321:1: ( ( rule__Task__Starting_condsAssignment_4 )* )
            // InternalScSl.g:2322:2: ( rule__Task__Starting_condsAssignment_4 )*
            {
             before(grammarAccess.getTaskAccess().getStarting_condsAssignment_4()); 
            // InternalScSl.g:2323:2: ( rule__Task__Starting_condsAssignment_4 )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==39) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalScSl.g:2323:3: rule__Task__Starting_condsAssignment_4
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__Task__Starting_condsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

             after(grammarAccess.getTaskAccess().getStarting_condsAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__4__Impl"


    // $ANTLR start "rule__Task__Group__5"
    // InternalScSl.g:2331:1: rule__Task__Group__5 : rule__Task__Group__5__Impl rule__Task__Group__6 ;
    public final void rule__Task__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2335:1: ( rule__Task__Group__5__Impl rule__Task__Group__6 )
            // InternalScSl.g:2336:2: rule__Task__Group__5__Impl rule__Task__Group__6
            {
            pushFollow(FOLLOW_19);
            rule__Task__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Task__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__5"


    // $ANTLR start "rule__Task__Group__5__Impl"
    // InternalScSl.g:2343:1: rule__Task__Group__5__Impl : ( ( rule__Task__Stopping_condsAssignment_5 )* ) ;
    public final void rule__Task__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2347:1: ( ( ( rule__Task__Stopping_condsAssignment_5 )* ) )
            // InternalScSl.g:2348:1: ( ( rule__Task__Stopping_condsAssignment_5 )* )
            {
            // InternalScSl.g:2348:1: ( ( rule__Task__Stopping_condsAssignment_5 )* )
            // InternalScSl.g:2349:2: ( rule__Task__Stopping_condsAssignment_5 )*
            {
             before(grammarAccess.getTaskAccess().getStopping_condsAssignment_5()); 
            // InternalScSl.g:2350:2: ( rule__Task__Stopping_condsAssignment_5 )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==40) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // InternalScSl.g:2350:3: rule__Task__Stopping_condsAssignment_5
            	    {
            	    pushFollow(FOLLOW_21);
            	    rule__Task__Stopping_condsAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

             after(grammarAccess.getTaskAccess().getStopping_condsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__5__Impl"


    // $ANTLR start "rule__Task__Group__6"
    // InternalScSl.g:2358:1: rule__Task__Group__6 : rule__Task__Group__6__Impl ;
    public final void rule__Task__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2362:1: ( rule__Task__Group__6__Impl )
            // InternalScSl.g:2363:2: rule__Task__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Task__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__6"


    // $ANTLR start "rule__Task__Group__6__Impl"
    // InternalScSl.g:2369:1: rule__Task__Group__6__Impl : ( ( rule__Task__ActionsAssignment_6 )* ) ;
    public final void rule__Task__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2373:1: ( ( ( rule__Task__ActionsAssignment_6 )* ) )
            // InternalScSl.g:2374:1: ( ( rule__Task__ActionsAssignment_6 )* )
            {
            // InternalScSl.g:2374:1: ( ( rule__Task__ActionsAssignment_6 )* )
            // InternalScSl.g:2375:2: ( rule__Task__ActionsAssignment_6 )*
            {
             before(grammarAccess.getTaskAccess().getActionsAssignment_6()); 
            // InternalScSl.g:2376:2: ( rule__Task__ActionsAssignment_6 )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( ((LA24_0>=42 && LA24_0<=48)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalScSl.g:2376:3: rule__Task__ActionsAssignment_6
            	    {
            	    pushFollow(FOLLOW_22);
            	    rule__Task__ActionsAssignment_6();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

             after(grammarAccess.getTaskAccess().getActionsAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Group__6__Impl"


    // $ANTLR start "rule__Goal__Group__0"
    // InternalScSl.g:2385:1: rule__Goal__Group__0 : rule__Goal__Group__0__Impl rule__Goal__Group__1 ;
    public final void rule__Goal__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2389:1: ( rule__Goal__Group__0__Impl rule__Goal__Group__1 )
            // InternalScSl.g:2390:2: rule__Goal__Group__0__Impl rule__Goal__Group__1
            {
            pushFollow(FOLLOW_23);
            rule__Goal__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Goal__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Goal__Group__0"


    // $ANTLR start "rule__Goal__Group__0__Impl"
    // InternalScSl.g:2397:1: rule__Goal__Group__0__Impl : ( 'Goal' ) ;
    public final void rule__Goal__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2401:1: ( ( 'Goal' ) )
            // InternalScSl.g:2402:1: ( 'Goal' )
            {
            // InternalScSl.g:2402:1: ( 'Goal' )
            // InternalScSl.g:2403:2: 'Goal'
            {
             before(grammarAccess.getGoalAccess().getGoalKeyword_0()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getGoalAccess().getGoalKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Goal__Group__0__Impl"


    // $ANTLR start "rule__Goal__Group__1"
    // InternalScSl.g:2412:1: rule__Goal__Group__1 : rule__Goal__Group__1__Impl ;
    public final void rule__Goal__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2416:1: ( rule__Goal__Group__1__Impl )
            // InternalScSl.g:2417:2: rule__Goal__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Goal__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Goal__Group__1"


    // $ANTLR start "rule__Goal__Group__1__Impl"
    // InternalScSl.g:2423:1: rule__Goal__Group__1__Impl : ( ( ( rule__Goal__CondAssignment_1 ) ) ( ( rule__Goal__CondAssignment_1 )* ) ) ;
    public final void rule__Goal__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2427:1: ( ( ( ( rule__Goal__CondAssignment_1 ) ) ( ( rule__Goal__CondAssignment_1 )* ) ) )
            // InternalScSl.g:2428:1: ( ( ( rule__Goal__CondAssignment_1 ) ) ( ( rule__Goal__CondAssignment_1 )* ) )
            {
            // InternalScSl.g:2428:1: ( ( ( rule__Goal__CondAssignment_1 ) ) ( ( rule__Goal__CondAssignment_1 )* ) )
            // InternalScSl.g:2429:2: ( ( rule__Goal__CondAssignment_1 ) ) ( ( rule__Goal__CondAssignment_1 )* )
            {
            // InternalScSl.g:2429:2: ( ( rule__Goal__CondAssignment_1 ) )
            // InternalScSl.g:2430:3: ( rule__Goal__CondAssignment_1 )
            {
             before(grammarAccess.getGoalAccess().getCondAssignment_1()); 
            // InternalScSl.g:2431:3: ( rule__Goal__CondAssignment_1 )
            // InternalScSl.g:2431:4: rule__Goal__CondAssignment_1
            {
            pushFollow(FOLLOW_24);
            rule__Goal__CondAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getGoalAccess().getCondAssignment_1()); 

            }

            // InternalScSl.g:2434:2: ( ( rule__Goal__CondAssignment_1 )* )
            // InternalScSl.g:2435:3: ( rule__Goal__CondAssignment_1 )*
            {
             before(grammarAccess.getGoalAccess().getCondAssignment_1()); 
            // InternalScSl.g:2436:3: ( rule__Goal__CondAssignment_1 )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==14||(LA25_0>=53 && LA25_0<=57)) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalScSl.g:2436:4: rule__Goal__CondAssignment_1
            	    {
            	    pushFollow(FOLLOW_24);
            	    rule__Goal__CondAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

             after(grammarAccess.getGoalAccess().getCondAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Goal__Group__1__Impl"


    // $ANTLR start "rule__StartingCondition__Group__0"
    // InternalScSl.g:2446:1: rule__StartingCondition__Group__0 : rule__StartingCondition__Group__0__Impl rule__StartingCondition__Group__1 ;
    public final void rule__StartingCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2450:1: ( rule__StartingCondition__Group__0__Impl rule__StartingCondition__Group__1 )
            // InternalScSl.g:2451:2: rule__StartingCondition__Group__0__Impl rule__StartingCondition__Group__1
            {
            pushFollow(FOLLOW_23);
            rule__StartingCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StartingCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StartingCondition__Group__0"


    // $ANTLR start "rule__StartingCondition__Group__0__Impl"
    // InternalScSl.g:2458:1: rule__StartingCondition__Group__0__Impl : ( 'Start_if' ) ;
    public final void rule__StartingCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2462:1: ( ( 'Start_if' ) )
            // InternalScSl.g:2463:1: ( 'Start_if' )
            {
            // InternalScSl.g:2463:1: ( 'Start_if' )
            // InternalScSl.g:2464:2: 'Start_if'
            {
             before(grammarAccess.getStartingConditionAccess().getStart_ifKeyword_0()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getStartingConditionAccess().getStart_ifKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StartingCondition__Group__0__Impl"


    // $ANTLR start "rule__StartingCondition__Group__1"
    // InternalScSl.g:2473:1: rule__StartingCondition__Group__1 : rule__StartingCondition__Group__1__Impl ;
    public final void rule__StartingCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2477:1: ( rule__StartingCondition__Group__1__Impl )
            // InternalScSl.g:2478:2: rule__StartingCondition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StartingCondition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StartingCondition__Group__1"


    // $ANTLR start "rule__StartingCondition__Group__1__Impl"
    // InternalScSl.g:2484:1: rule__StartingCondition__Group__1__Impl : ( ( ( rule__StartingCondition__CondAssignment_1 ) ) ( ( rule__StartingCondition__CondAssignment_1 )* ) ) ;
    public final void rule__StartingCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2488:1: ( ( ( ( rule__StartingCondition__CondAssignment_1 ) ) ( ( rule__StartingCondition__CondAssignment_1 )* ) ) )
            // InternalScSl.g:2489:1: ( ( ( rule__StartingCondition__CondAssignment_1 ) ) ( ( rule__StartingCondition__CondAssignment_1 )* ) )
            {
            // InternalScSl.g:2489:1: ( ( ( rule__StartingCondition__CondAssignment_1 ) ) ( ( rule__StartingCondition__CondAssignment_1 )* ) )
            // InternalScSl.g:2490:2: ( ( rule__StartingCondition__CondAssignment_1 ) ) ( ( rule__StartingCondition__CondAssignment_1 )* )
            {
            // InternalScSl.g:2490:2: ( ( rule__StartingCondition__CondAssignment_1 ) )
            // InternalScSl.g:2491:3: ( rule__StartingCondition__CondAssignment_1 )
            {
             before(grammarAccess.getStartingConditionAccess().getCondAssignment_1()); 
            // InternalScSl.g:2492:3: ( rule__StartingCondition__CondAssignment_1 )
            // InternalScSl.g:2492:4: rule__StartingCondition__CondAssignment_1
            {
            pushFollow(FOLLOW_24);
            rule__StartingCondition__CondAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getStartingConditionAccess().getCondAssignment_1()); 

            }

            // InternalScSl.g:2495:2: ( ( rule__StartingCondition__CondAssignment_1 )* )
            // InternalScSl.g:2496:3: ( rule__StartingCondition__CondAssignment_1 )*
            {
             before(grammarAccess.getStartingConditionAccess().getCondAssignment_1()); 
            // InternalScSl.g:2497:3: ( rule__StartingCondition__CondAssignment_1 )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==14||(LA26_0>=53 && LA26_0<=57)) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalScSl.g:2497:4: rule__StartingCondition__CondAssignment_1
            	    {
            	    pushFollow(FOLLOW_24);
            	    rule__StartingCondition__CondAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

             after(grammarAccess.getStartingConditionAccess().getCondAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StartingCondition__Group__1__Impl"


    // $ANTLR start "rule__StoppingCondition__Group__0"
    // InternalScSl.g:2507:1: rule__StoppingCondition__Group__0 : rule__StoppingCondition__Group__0__Impl rule__StoppingCondition__Group__1 ;
    public final void rule__StoppingCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2511:1: ( rule__StoppingCondition__Group__0__Impl rule__StoppingCondition__Group__1 )
            // InternalScSl.g:2512:2: rule__StoppingCondition__Group__0__Impl rule__StoppingCondition__Group__1
            {
            pushFollow(FOLLOW_23);
            rule__StoppingCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StoppingCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StoppingCondition__Group__0"


    // $ANTLR start "rule__StoppingCondition__Group__0__Impl"
    // InternalScSl.g:2519:1: rule__StoppingCondition__Group__0__Impl : ( 'Stop_when' ) ;
    public final void rule__StoppingCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2523:1: ( ( 'Stop_when' ) )
            // InternalScSl.g:2524:1: ( 'Stop_when' )
            {
            // InternalScSl.g:2524:1: ( 'Stop_when' )
            // InternalScSl.g:2525:2: 'Stop_when'
            {
             before(grammarAccess.getStoppingConditionAccess().getStop_whenKeyword_0()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getStoppingConditionAccess().getStop_whenKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StoppingCondition__Group__0__Impl"


    // $ANTLR start "rule__StoppingCondition__Group__1"
    // InternalScSl.g:2534:1: rule__StoppingCondition__Group__1 : rule__StoppingCondition__Group__1__Impl ;
    public final void rule__StoppingCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2538:1: ( rule__StoppingCondition__Group__1__Impl )
            // InternalScSl.g:2539:2: rule__StoppingCondition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StoppingCondition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StoppingCondition__Group__1"


    // $ANTLR start "rule__StoppingCondition__Group__1__Impl"
    // InternalScSl.g:2545:1: rule__StoppingCondition__Group__1__Impl : ( ( ( rule__StoppingCondition__CondAssignment_1 ) ) ( ( rule__StoppingCondition__CondAssignment_1 )* ) ) ;
    public final void rule__StoppingCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2549:1: ( ( ( ( rule__StoppingCondition__CondAssignment_1 ) ) ( ( rule__StoppingCondition__CondAssignment_1 )* ) ) )
            // InternalScSl.g:2550:1: ( ( ( rule__StoppingCondition__CondAssignment_1 ) ) ( ( rule__StoppingCondition__CondAssignment_1 )* ) )
            {
            // InternalScSl.g:2550:1: ( ( ( rule__StoppingCondition__CondAssignment_1 ) ) ( ( rule__StoppingCondition__CondAssignment_1 )* ) )
            // InternalScSl.g:2551:2: ( ( rule__StoppingCondition__CondAssignment_1 ) ) ( ( rule__StoppingCondition__CondAssignment_1 )* )
            {
            // InternalScSl.g:2551:2: ( ( rule__StoppingCondition__CondAssignment_1 ) )
            // InternalScSl.g:2552:3: ( rule__StoppingCondition__CondAssignment_1 )
            {
             before(grammarAccess.getStoppingConditionAccess().getCondAssignment_1()); 
            // InternalScSl.g:2553:3: ( rule__StoppingCondition__CondAssignment_1 )
            // InternalScSl.g:2553:4: rule__StoppingCondition__CondAssignment_1
            {
            pushFollow(FOLLOW_24);
            rule__StoppingCondition__CondAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getStoppingConditionAccess().getCondAssignment_1()); 

            }

            // InternalScSl.g:2556:2: ( ( rule__StoppingCondition__CondAssignment_1 )* )
            // InternalScSl.g:2557:3: ( rule__StoppingCondition__CondAssignment_1 )*
            {
             before(grammarAccess.getStoppingConditionAccess().getCondAssignment_1()); 
            // InternalScSl.g:2558:3: ( rule__StoppingCondition__CondAssignment_1 )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==14||(LA27_0>=53 && LA27_0<=57)) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // InternalScSl.g:2558:4: rule__StoppingCondition__CondAssignment_1
            	    {
            	    pushFollow(FOLLOW_24);
            	    rule__StoppingCondition__CondAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

             after(grammarAccess.getStoppingConditionAccess().getCondAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StoppingCondition__Group__1__Impl"


    // $ANTLR start "rule__UntilCondition__Group__0"
    // InternalScSl.g:2568:1: rule__UntilCondition__Group__0 : rule__UntilCondition__Group__0__Impl rule__UntilCondition__Group__1 ;
    public final void rule__UntilCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2572:1: ( rule__UntilCondition__Group__0__Impl rule__UntilCondition__Group__1 )
            // InternalScSl.g:2573:2: rule__UntilCondition__Group__0__Impl rule__UntilCondition__Group__1
            {
            pushFollow(FOLLOW_23);
            rule__UntilCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UntilCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UntilCondition__Group__0"


    // $ANTLR start "rule__UntilCondition__Group__0__Impl"
    // InternalScSl.g:2580:1: rule__UntilCondition__Group__0__Impl : ( 'until' ) ;
    public final void rule__UntilCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2584:1: ( ( 'until' ) )
            // InternalScSl.g:2585:1: ( 'until' )
            {
            // InternalScSl.g:2585:1: ( 'until' )
            // InternalScSl.g:2586:2: 'until'
            {
             before(grammarAccess.getUntilConditionAccess().getUntilKeyword_0()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getUntilConditionAccess().getUntilKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UntilCondition__Group__0__Impl"


    // $ANTLR start "rule__UntilCondition__Group__1"
    // InternalScSl.g:2595:1: rule__UntilCondition__Group__1 : rule__UntilCondition__Group__1__Impl ;
    public final void rule__UntilCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2599:1: ( rule__UntilCondition__Group__1__Impl )
            // InternalScSl.g:2600:2: rule__UntilCondition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__UntilCondition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UntilCondition__Group__1"


    // $ANTLR start "rule__UntilCondition__Group__1__Impl"
    // InternalScSl.g:2606:1: rule__UntilCondition__Group__1__Impl : ( ( ( rule__UntilCondition__CondAssignment_1 ) ) ( ( rule__UntilCondition__CondAssignment_1 )* ) ) ;
    public final void rule__UntilCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2610:1: ( ( ( ( rule__UntilCondition__CondAssignment_1 ) ) ( ( rule__UntilCondition__CondAssignment_1 )* ) ) )
            // InternalScSl.g:2611:1: ( ( ( rule__UntilCondition__CondAssignment_1 ) ) ( ( rule__UntilCondition__CondAssignment_1 )* ) )
            {
            // InternalScSl.g:2611:1: ( ( ( rule__UntilCondition__CondAssignment_1 ) ) ( ( rule__UntilCondition__CondAssignment_1 )* ) )
            // InternalScSl.g:2612:2: ( ( rule__UntilCondition__CondAssignment_1 ) ) ( ( rule__UntilCondition__CondAssignment_1 )* )
            {
            // InternalScSl.g:2612:2: ( ( rule__UntilCondition__CondAssignment_1 ) )
            // InternalScSl.g:2613:3: ( rule__UntilCondition__CondAssignment_1 )
            {
             before(grammarAccess.getUntilConditionAccess().getCondAssignment_1()); 
            // InternalScSl.g:2614:3: ( rule__UntilCondition__CondAssignment_1 )
            // InternalScSl.g:2614:4: rule__UntilCondition__CondAssignment_1
            {
            pushFollow(FOLLOW_24);
            rule__UntilCondition__CondAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getUntilConditionAccess().getCondAssignment_1()); 

            }

            // InternalScSl.g:2617:2: ( ( rule__UntilCondition__CondAssignment_1 )* )
            // InternalScSl.g:2618:3: ( rule__UntilCondition__CondAssignment_1 )*
            {
             before(grammarAccess.getUntilConditionAccess().getCondAssignment_1()); 
            // InternalScSl.g:2619:3: ( rule__UntilCondition__CondAssignment_1 )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0==14||(LA28_0>=53 && LA28_0<=57)) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // InternalScSl.g:2619:4: rule__UntilCondition__CondAssignment_1
            	    {
            	    pushFollow(FOLLOW_24);
            	    rule__UntilCondition__CondAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);

             after(grammarAccess.getUntilConditionAccess().getCondAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UntilCondition__Group__1__Impl"


    // $ANTLR start "rule__Action__Group_0__0"
    // InternalScSl.g:2629:1: rule__Action__Group_0__0 : rule__Action__Group_0__0__Impl rule__Action__Group_0__1 ;
    public final void rule__Action__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2633:1: ( rule__Action__Group_0__0__Impl rule__Action__Group_0__1 )
            // InternalScSl.g:2634:2: rule__Action__Group_0__0__Impl rule__Action__Group_0__1
            {
            pushFollow(FOLLOW_25);
            rule__Action__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_0__0"


    // $ANTLR start "rule__Action__Group_0__0__Impl"
    // InternalScSl.g:2641:1: rule__Action__Group_0__0__Impl : ( 'Drive' ) ;
    public final void rule__Action__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2645:1: ( ( 'Drive' ) )
            // InternalScSl.g:2646:1: ( 'Drive' )
            {
            // InternalScSl.g:2646:1: ( 'Drive' )
            // InternalScSl.g:2647:2: 'Drive'
            {
             before(grammarAccess.getActionAccess().getDriveKeyword_0_0()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getDriveKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_0__0__Impl"


    // $ANTLR start "rule__Action__Group_0__1"
    // InternalScSl.g:2656:1: rule__Action__Group_0__1 : rule__Action__Group_0__1__Impl ;
    public final void rule__Action__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2660:1: ( rule__Action__Group_0__1__Impl )
            // InternalScSl.g:2661:2: rule__Action__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_0__1"


    // $ANTLR start "rule__Action__Group_0__1__Impl"
    // InternalScSl.g:2667:1: rule__Action__Group_0__1__Impl : ( ruleDriveAction ) ;
    public final void rule__Action__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2671:1: ( ( ruleDriveAction ) )
            // InternalScSl.g:2672:1: ( ruleDriveAction )
            {
            // InternalScSl.g:2672:1: ( ruleDriveAction )
            // InternalScSl.g:2673:2: ruleDriveAction
            {
             before(grammarAccess.getActionAccess().getDriveActionParserRuleCall_0_1()); 
            pushFollow(FOLLOW_2);
            ruleDriveAction();

            state._fsp--;

             after(grammarAccess.getActionAccess().getDriveActionParserRuleCall_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_0__1__Impl"


    // $ANTLR start "rule__Action__Group_1__0"
    // InternalScSl.g:2683:1: rule__Action__Group_1__0 : rule__Action__Group_1__0__Impl rule__Action__Group_1__1 ;
    public final void rule__Action__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2687:1: ( rule__Action__Group_1__0__Impl rule__Action__Group_1__1 )
            // InternalScSl.g:2688:2: rule__Action__Group_1__0__Impl rule__Action__Group_1__1
            {
            pushFollow(FOLLOW_26);
            rule__Action__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_1__0"


    // $ANTLR start "rule__Action__Group_1__0__Impl"
    // InternalScSl.g:2695:1: rule__Action__Group_1__0__Impl : ( 'Turn' ) ;
    public final void rule__Action__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2699:1: ( ( 'Turn' ) )
            // InternalScSl.g:2700:1: ( 'Turn' )
            {
            // InternalScSl.g:2700:1: ( 'Turn' )
            // InternalScSl.g:2701:2: 'Turn'
            {
             before(grammarAccess.getActionAccess().getTurnKeyword_1_0()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getTurnKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_1__0__Impl"


    // $ANTLR start "rule__Action__Group_1__1"
    // InternalScSl.g:2710:1: rule__Action__Group_1__1 : rule__Action__Group_1__1__Impl ;
    public final void rule__Action__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2714:1: ( rule__Action__Group_1__1__Impl )
            // InternalScSl.g:2715:2: rule__Action__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_1__1"


    // $ANTLR start "rule__Action__Group_1__1__Impl"
    // InternalScSl.g:2721:1: rule__Action__Group_1__1__Impl : ( ruleTurnAction ) ;
    public final void rule__Action__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2725:1: ( ( ruleTurnAction ) )
            // InternalScSl.g:2726:1: ( ruleTurnAction )
            {
            // InternalScSl.g:2726:1: ( ruleTurnAction )
            // InternalScSl.g:2727:2: ruleTurnAction
            {
             before(grammarAccess.getActionAccess().getTurnActionParserRuleCall_1_1()); 
            pushFollow(FOLLOW_2);
            ruleTurnAction();

            state._fsp--;

             after(grammarAccess.getActionAccess().getTurnActionParserRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_1__1__Impl"


    // $ANTLR start "rule__Action__Group_2__0"
    // InternalScSl.g:2737:1: rule__Action__Group_2__0 : rule__Action__Group_2__0__Impl rule__Action__Group_2__1 ;
    public final void rule__Action__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2741:1: ( rule__Action__Group_2__0__Impl rule__Action__Group_2__1 )
            // InternalScSl.g:2742:2: rule__Action__Group_2__0__Impl rule__Action__Group_2__1
            {
            pushFollow(FOLLOW_27);
            rule__Action__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_2__0"


    // $ANTLR start "rule__Action__Group_2__0__Impl"
    // InternalScSl.g:2749:1: rule__Action__Group_2__0__Impl : ( 'Wait' ) ;
    public final void rule__Action__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2753:1: ( ( 'Wait' ) )
            // InternalScSl.g:2754:1: ( 'Wait' )
            {
            // InternalScSl.g:2754:1: ( 'Wait' )
            // InternalScSl.g:2755:2: 'Wait'
            {
             before(grammarAccess.getActionAccess().getWaitKeyword_2_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getWaitKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_2__0__Impl"


    // $ANTLR start "rule__Action__Group_2__1"
    // InternalScSl.g:2764:1: rule__Action__Group_2__1 : rule__Action__Group_2__1__Impl ;
    public final void rule__Action__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2768:1: ( rule__Action__Group_2__1__Impl )
            // InternalScSl.g:2769:2: rule__Action__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_2__1"


    // $ANTLR start "rule__Action__Group_2__1__Impl"
    // InternalScSl.g:2775:1: rule__Action__Group_2__1__Impl : ( ruleWaitAction ) ;
    public final void rule__Action__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2779:1: ( ( ruleWaitAction ) )
            // InternalScSl.g:2780:1: ( ruleWaitAction )
            {
            // InternalScSl.g:2780:1: ( ruleWaitAction )
            // InternalScSl.g:2781:2: ruleWaitAction
            {
             before(grammarAccess.getActionAccess().getWaitActionParserRuleCall_2_1()); 
            pushFollow(FOLLOW_2);
            ruleWaitAction();

            state._fsp--;

             after(grammarAccess.getActionAccess().getWaitActionParserRuleCall_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_2__1__Impl"


    // $ANTLR start "rule__Action__Group_3__0"
    // InternalScSl.g:2791:1: rule__Action__Group_3__0 : rule__Action__Group_3__0__Impl rule__Action__Group_3__1 ;
    public final void rule__Action__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2795:1: ( rule__Action__Group_3__0__Impl rule__Action__Group_3__1 )
            // InternalScSl.g:2796:2: rule__Action__Group_3__0__Impl rule__Action__Group_3__1
            {
            pushFollow(FOLLOW_28);
            rule__Action__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_3__0"


    // $ANTLR start "rule__Action__Group_3__0__Impl"
    // InternalScSl.g:2803:1: rule__Action__Group_3__0__Impl : ( 'Mark' ) ;
    public final void rule__Action__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2807:1: ( ( 'Mark' ) )
            // InternalScSl.g:2808:1: ( 'Mark' )
            {
            // InternalScSl.g:2808:1: ( 'Mark' )
            // InternalScSl.g:2809:2: 'Mark'
            {
             before(grammarAccess.getActionAccess().getMarkKeyword_3_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getMarkKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_3__0__Impl"


    // $ANTLR start "rule__Action__Group_3__1"
    // InternalScSl.g:2818:1: rule__Action__Group_3__1 : rule__Action__Group_3__1__Impl ;
    public final void rule__Action__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2822:1: ( rule__Action__Group_3__1__Impl )
            // InternalScSl.g:2823:2: rule__Action__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_3__1"


    // $ANTLR start "rule__Action__Group_3__1__Impl"
    // InternalScSl.g:2829:1: rule__Action__Group_3__1__Impl : ( ruleMarkAction ) ;
    public final void rule__Action__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2833:1: ( ( ruleMarkAction ) )
            // InternalScSl.g:2834:1: ( ruleMarkAction )
            {
            // InternalScSl.g:2834:1: ( ruleMarkAction )
            // InternalScSl.g:2835:2: ruleMarkAction
            {
             before(grammarAccess.getActionAccess().getMarkActionParserRuleCall_3_1()); 
            pushFollow(FOLLOW_2);
            ruleMarkAction();

            state._fsp--;

             after(grammarAccess.getActionAccess().getMarkActionParserRuleCall_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_3__1__Impl"


    // $ANTLR start "rule__Action__Group_4__0"
    // InternalScSl.g:2845:1: rule__Action__Group_4__0 : rule__Action__Group_4__0__Impl rule__Action__Group_4__1 ;
    public final void rule__Action__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2849:1: ( rule__Action__Group_4__0__Impl rule__Action__Group_4__1 )
            // InternalScSl.g:2850:2: rule__Action__Group_4__0__Impl rule__Action__Group_4__1
            {
            pushFollow(FOLLOW_28);
            rule__Action__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_4__0"


    // $ANTLR start "rule__Action__Group_4__0__Impl"
    // InternalScSl.g:2857:1: rule__Action__Group_4__0__Impl : ( 'Clear' ) ;
    public final void rule__Action__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2861:1: ( ( 'Clear' ) )
            // InternalScSl.g:2862:1: ( 'Clear' )
            {
            // InternalScSl.g:2862:1: ( 'Clear' )
            // InternalScSl.g:2863:2: 'Clear'
            {
             before(grammarAccess.getActionAccess().getClearKeyword_4_0()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getClearKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_4__0__Impl"


    // $ANTLR start "rule__Action__Group_4__1"
    // InternalScSl.g:2872:1: rule__Action__Group_4__1 : rule__Action__Group_4__1__Impl ;
    public final void rule__Action__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2876:1: ( rule__Action__Group_4__1__Impl )
            // InternalScSl.g:2877:2: rule__Action__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_4__1"


    // $ANTLR start "rule__Action__Group_4__1__Impl"
    // InternalScSl.g:2883:1: rule__Action__Group_4__1__Impl : ( ruleClearAction ) ;
    public final void rule__Action__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2887:1: ( ( ruleClearAction ) )
            // InternalScSl.g:2888:1: ( ruleClearAction )
            {
            // InternalScSl.g:2888:1: ( ruleClearAction )
            // InternalScSl.g:2889:2: ruleClearAction
            {
             before(grammarAccess.getActionAccess().getClearActionParserRuleCall_4_1()); 
            pushFollow(FOLLOW_2);
            ruleClearAction();

            state._fsp--;

             after(grammarAccess.getActionAccess().getClearActionParserRuleCall_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_4__1__Impl"


    // $ANTLR start "rule__Action__Group_5__0"
    // InternalScSl.g:2899:1: rule__Action__Group_5__0 : rule__Action__Group_5__0__Impl rule__Action__Group_5__1 ;
    public final void rule__Action__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2903:1: ( rule__Action__Group_5__0__Impl rule__Action__Group_5__1 )
            // InternalScSl.g:2904:2: rule__Action__Group_5__0__Impl rule__Action__Group_5__1
            {
            pushFollow(FOLLOW_29);
            rule__Action__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_5__0"


    // $ANTLR start "rule__Action__Group_5__0__Impl"
    // InternalScSl.g:2911:1: rule__Action__Group_5__0__Impl : ( 'Show' ) ;
    public final void rule__Action__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2915:1: ( ( 'Show' ) )
            // InternalScSl.g:2916:1: ( 'Show' )
            {
            // InternalScSl.g:2916:1: ( 'Show' )
            // InternalScSl.g:2917:2: 'Show'
            {
             before(grammarAccess.getActionAccess().getShowKeyword_5_0()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getShowKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_5__0__Impl"


    // $ANTLR start "rule__Action__Group_5__1"
    // InternalScSl.g:2926:1: rule__Action__Group_5__1 : rule__Action__Group_5__1__Impl ;
    public final void rule__Action__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2930:1: ( rule__Action__Group_5__1__Impl )
            // InternalScSl.g:2931:2: rule__Action__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_5__1"


    // $ANTLR start "rule__Action__Group_5__1__Impl"
    // InternalScSl.g:2937:1: rule__Action__Group_5__1__Impl : ( ruleMessageAction ) ;
    public final void rule__Action__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2941:1: ( ( ruleMessageAction ) )
            // InternalScSl.g:2942:1: ( ruleMessageAction )
            {
            // InternalScSl.g:2942:1: ( ruleMessageAction )
            // InternalScSl.g:2943:2: ruleMessageAction
            {
             before(grammarAccess.getActionAccess().getMessageActionParserRuleCall_5_1()); 
            pushFollow(FOLLOW_2);
            ruleMessageAction();

            state._fsp--;

             after(grammarAccess.getActionAccess().getMessageActionParserRuleCall_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_5__1__Impl"


    // $ANTLR start "rule__Action__Group_6__0"
    // InternalScSl.g:2953:1: rule__Action__Group_6__0 : rule__Action__Group_6__0__Impl rule__Action__Group_6__1 ;
    public final void rule__Action__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2957:1: ( rule__Action__Group_6__0__Impl rule__Action__Group_6__1 )
            // InternalScSl.g:2958:2: rule__Action__Group_6__0__Impl rule__Action__Group_6__1
            {
            pushFollow(FOLLOW_30);
            rule__Action__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_6__0"


    // $ANTLR start "rule__Action__Group_6__0__Impl"
    // InternalScSl.g:2965:1: rule__Action__Group_6__0__Impl : ( 'Play' ) ;
    public final void rule__Action__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2969:1: ( ( 'Play' ) )
            // InternalScSl.g:2970:1: ( 'Play' )
            {
            // InternalScSl.g:2970:1: ( 'Play' )
            // InternalScSl.g:2971:2: 'Play'
            {
             before(grammarAccess.getActionAccess().getPlayKeyword_6_0()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getPlayKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_6__0__Impl"


    // $ANTLR start "rule__Action__Group_6__1"
    // InternalScSl.g:2980:1: rule__Action__Group_6__1 : rule__Action__Group_6__1__Impl ;
    public final void rule__Action__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2984:1: ( rule__Action__Group_6__1__Impl )
            // InternalScSl.g:2985:2: rule__Action__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_6__1"


    // $ANTLR start "rule__Action__Group_6__1__Impl"
    // InternalScSl.g:2991:1: rule__Action__Group_6__1__Impl : ( ruleSoundAction ) ;
    public final void rule__Action__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:2995:1: ( ( ruleSoundAction ) )
            // InternalScSl.g:2996:1: ( ruleSoundAction )
            {
            // InternalScSl.g:2996:1: ( ruleSoundAction )
            // InternalScSl.g:2997:2: ruleSoundAction
            {
             before(grammarAccess.getActionAccess().getSoundActionParserRuleCall_6_1()); 
            pushFollow(FOLLOW_2);
            ruleSoundAction();

            state._fsp--;

             after(grammarAccess.getActionAccess().getSoundActionParserRuleCall_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group_6__1__Impl"


    // $ANTLR start "rule__MessageAction__Group__0"
    // InternalScSl.g:3007:1: rule__MessageAction__Group__0 : rule__MessageAction__Group__0__Impl rule__MessageAction__Group__1 ;
    public final void rule__MessageAction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3011:1: ( rule__MessageAction__Group__0__Impl rule__MessageAction__Group__1 )
            // InternalScSl.g:3012:2: rule__MessageAction__Group__0__Impl rule__MessageAction__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__MessageAction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MessageAction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MessageAction__Group__0"


    // $ANTLR start "rule__MessageAction__Group__0__Impl"
    // InternalScSl.g:3019:1: rule__MessageAction__Group__0__Impl : ( 'message' ) ;
    public final void rule__MessageAction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3023:1: ( ( 'message' ) )
            // InternalScSl.g:3024:1: ( 'message' )
            {
            // InternalScSl.g:3024:1: ( 'message' )
            // InternalScSl.g:3025:2: 'message'
            {
             before(grammarAccess.getMessageActionAccess().getMessageKeyword_0()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getMessageActionAccess().getMessageKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MessageAction__Group__0__Impl"


    // $ANTLR start "rule__MessageAction__Group__1"
    // InternalScSl.g:3034:1: rule__MessageAction__Group__1 : rule__MessageAction__Group__1__Impl ;
    public final void rule__MessageAction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3038:1: ( rule__MessageAction__Group__1__Impl )
            // InternalScSl.g:3039:2: rule__MessageAction__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MessageAction__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MessageAction__Group__1"


    // $ANTLR start "rule__MessageAction__Group__1__Impl"
    // InternalScSl.g:3045:1: rule__MessageAction__Group__1__Impl : ( ( rule__MessageAction__MAssignment_1 ) ) ;
    public final void rule__MessageAction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3049:1: ( ( ( rule__MessageAction__MAssignment_1 ) ) )
            // InternalScSl.g:3050:1: ( ( rule__MessageAction__MAssignment_1 ) )
            {
            // InternalScSl.g:3050:1: ( ( rule__MessageAction__MAssignment_1 ) )
            // InternalScSl.g:3051:2: ( rule__MessageAction__MAssignment_1 )
            {
             before(grammarAccess.getMessageActionAccess().getMAssignment_1()); 
            // InternalScSl.g:3052:2: ( rule__MessageAction__MAssignment_1 )
            // InternalScSl.g:3052:3: rule__MessageAction__MAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__MessageAction__MAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getMessageActionAccess().getMAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MessageAction__Group__1__Impl"


    // $ANTLR start "rule__SoundAction__Group__0"
    // InternalScSl.g:3061:1: rule__SoundAction__Group__0 : rule__SoundAction__Group__0__Impl rule__SoundAction__Group__1 ;
    public final void rule__SoundAction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3065:1: ( rule__SoundAction__Group__0__Impl rule__SoundAction__Group__1 )
            // InternalScSl.g:3066:2: rule__SoundAction__Group__0__Impl rule__SoundAction__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__SoundAction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoundAction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__0"


    // $ANTLR start "rule__SoundAction__Group__0__Impl"
    // InternalScSl.g:3073:1: rule__SoundAction__Group__0__Impl : ( 'note' ) ;
    public final void rule__SoundAction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3077:1: ( ( 'note' ) )
            // InternalScSl.g:3078:1: ( 'note' )
            {
            // InternalScSl.g:3078:1: ( 'note' )
            // InternalScSl.g:3079:2: 'note'
            {
             before(grammarAccess.getSoundActionAccess().getNoteKeyword_0()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getSoundActionAccess().getNoteKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__0__Impl"


    // $ANTLR start "rule__SoundAction__Group__1"
    // InternalScSl.g:3088:1: rule__SoundAction__Group__1 : rule__SoundAction__Group__1__Impl rule__SoundAction__Group__2 ;
    public final void rule__SoundAction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3092:1: ( rule__SoundAction__Group__1__Impl rule__SoundAction__Group__2 )
            // InternalScSl.g:3093:2: rule__SoundAction__Group__1__Impl rule__SoundAction__Group__2
            {
            pushFollow(FOLLOW_31);
            rule__SoundAction__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoundAction__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__1"


    // $ANTLR start "rule__SoundAction__Group__1__Impl"
    // InternalScSl.g:3100:1: rule__SoundAction__Group__1__Impl : ( ( rule__SoundAction__NAssignment_1 ) ) ;
    public final void rule__SoundAction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3104:1: ( ( ( rule__SoundAction__NAssignment_1 ) ) )
            // InternalScSl.g:3105:1: ( ( rule__SoundAction__NAssignment_1 ) )
            {
            // InternalScSl.g:3105:1: ( ( rule__SoundAction__NAssignment_1 ) )
            // InternalScSl.g:3106:2: ( rule__SoundAction__NAssignment_1 )
            {
             before(grammarAccess.getSoundActionAccess().getNAssignment_1()); 
            // InternalScSl.g:3107:2: ( rule__SoundAction__NAssignment_1 )
            // InternalScSl.g:3107:3: rule__SoundAction__NAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__SoundAction__NAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getSoundActionAccess().getNAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__1__Impl"


    // $ANTLR start "rule__SoundAction__Group__2"
    // InternalScSl.g:3115:1: rule__SoundAction__Group__2 : rule__SoundAction__Group__2__Impl rule__SoundAction__Group__3 ;
    public final void rule__SoundAction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3119:1: ( rule__SoundAction__Group__2__Impl rule__SoundAction__Group__3 )
            // InternalScSl.g:3120:2: rule__SoundAction__Group__2__Impl rule__SoundAction__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__SoundAction__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoundAction__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__2"


    // $ANTLR start "rule__SoundAction__Group__2__Impl"
    // InternalScSl.g:3127:1: rule__SoundAction__Group__2__Impl : ( 'for' ) ;
    public final void rule__SoundAction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3131:1: ( ( 'for' ) )
            // InternalScSl.g:3132:1: ( 'for' )
            {
            // InternalScSl.g:3132:1: ( 'for' )
            // InternalScSl.g:3133:2: 'for'
            {
             before(grammarAccess.getSoundActionAccess().getForKeyword_2()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getSoundActionAccess().getForKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__2__Impl"


    // $ANTLR start "rule__SoundAction__Group__3"
    // InternalScSl.g:3142:1: rule__SoundAction__Group__3 : rule__SoundAction__Group__3__Impl rule__SoundAction__Group__4 ;
    public final void rule__SoundAction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3146:1: ( rule__SoundAction__Group__3__Impl rule__SoundAction__Group__4 )
            // InternalScSl.g:3147:2: rule__SoundAction__Group__3__Impl rule__SoundAction__Group__4
            {
            pushFollow(FOLLOW_32);
            rule__SoundAction__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoundAction__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__3"


    // $ANTLR start "rule__SoundAction__Group__3__Impl"
    // InternalScSl.g:3154:1: rule__SoundAction__Group__3__Impl : ( ( rule__SoundAction__TAssignment_3 ) ) ;
    public final void rule__SoundAction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3158:1: ( ( ( rule__SoundAction__TAssignment_3 ) ) )
            // InternalScSl.g:3159:1: ( ( rule__SoundAction__TAssignment_3 ) )
            {
            // InternalScSl.g:3159:1: ( ( rule__SoundAction__TAssignment_3 ) )
            // InternalScSl.g:3160:2: ( rule__SoundAction__TAssignment_3 )
            {
             before(grammarAccess.getSoundActionAccess().getTAssignment_3()); 
            // InternalScSl.g:3161:2: ( rule__SoundAction__TAssignment_3 )
            // InternalScSl.g:3161:3: rule__SoundAction__TAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__SoundAction__TAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getSoundActionAccess().getTAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__3__Impl"


    // $ANTLR start "rule__SoundAction__Group__4"
    // InternalScSl.g:3169:1: rule__SoundAction__Group__4 : rule__SoundAction__Group__4__Impl ;
    public final void rule__SoundAction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3173:1: ( rule__SoundAction__Group__4__Impl )
            // InternalScSl.g:3174:2: rule__SoundAction__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SoundAction__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__4"


    // $ANTLR start "rule__SoundAction__Group__4__Impl"
    // InternalScSl.g:3180:1: rule__SoundAction__Group__4__Impl : ( 'ms' ) ;
    public final void rule__SoundAction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3184:1: ( ( 'ms' ) )
            // InternalScSl.g:3185:1: ( 'ms' )
            {
            // InternalScSl.g:3185:1: ( 'ms' )
            // InternalScSl.g:3186:2: 'ms'
            {
             before(grammarAccess.getSoundActionAccess().getMsKeyword_4()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getSoundActionAccess().getMsKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__Group__4__Impl"


    // $ANTLR start "rule__MarkAction__Group__0"
    // InternalScSl.g:3196:1: rule__MarkAction__Group__0 : rule__MarkAction__Group__0__Impl rule__MarkAction__Group__1 ;
    public final void rule__MarkAction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3200:1: ( rule__MarkAction__Group__0__Impl rule__MarkAction__Group__1 )
            // InternalScSl.g:3201:2: rule__MarkAction__Group__0__Impl rule__MarkAction__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__MarkAction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MarkAction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MarkAction__Group__0"


    // $ANTLR start "rule__MarkAction__Group__0__Impl"
    // InternalScSl.g:3208:1: rule__MarkAction__Group__0__Impl : ( 'achievement' ) ;
    public final void rule__MarkAction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3212:1: ( ( 'achievement' ) )
            // InternalScSl.g:3213:1: ( 'achievement' )
            {
            // InternalScSl.g:3213:1: ( 'achievement' )
            // InternalScSl.g:3214:2: 'achievement'
            {
             before(grammarAccess.getMarkActionAccess().getAchievementKeyword_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getMarkActionAccess().getAchievementKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MarkAction__Group__0__Impl"


    // $ANTLR start "rule__MarkAction__Group__1"
    // InternalScSl.g:3223:1: rule__MarkAction__Group__1 : rule__MarkAction__Group__1__Impl ;
    public final void rule__MarkAction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3227:1: ( rule__MarkAction__Group__1__Impl )
            // InternalScSl.g:3228:2: rule__MarkAction__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MarkAction__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MarkAction__Group__1"


    // $ANTLR start "rule__MarkAction__Group__1__Impl"
    // InternalScSl.g:3234:1: rule__MarkAction__Group__1__Impl : ( ( rule__MarkAction__AAssignment_1 ) ) ;
    public final void rule__MarkAction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3238:1: ( ( ( rule__MarkAction__AAssignment_1 ) ) )
            // InternalScSl.g:3239:1: ( ( rule__MarkAction__AAssignment_1 ) )
            {
            // InternalScSl.g:3239:1: ( ( rule__MarkAction__AAssignment_1 ) )
            // InternalScSl.g:3240:2: ( rule__MarkAction__AAssignment_1 )
            {
             before(grammarAccess.getMarkActionAccess().getAAssignment_1()); 
            // InternalScSl.g:3241:2: ( rule__MarkAction__AAssignment_1 )
            // InternalScSl.g:3241:3: rule__MarkAction__AAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__MarkAction__AAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getMarkActionAccess().getAAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MarkAction__Group__1__Impl"


    // $ANTLR start "rule__ClearAction__Group__0"
    // InternalScSl.g:3250:1: rule__ClearAction__Group__0 : rule__ClearAction__Group__0__Impl rule__ClearAction__Group__1 ;
    public final void rule__ClearAction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3254:1: ( rule__ClearAction__Group__0__Impl rule__ClearAction__Group__1 )
            // InternalScSl.g:3255:2: rule__ClearAction__Group__0__Impl rule__ClearAction__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__ClearAction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClearAction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClearAction__Group__0"


    // $ANTLR start "rule__ClearAction__Group__0__Impl"
    // InternalScSl.g:3262:1: rule__ClearAction__Group__0__Impl : ( 'achievement' ) ;
    public final void rule__ClearAction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3266:1: ( ( 'achievement' ) )
            // InternalScSl.g:3267:1: ( 'achievement' )
            {
            // InternalScSl.g:3267:1: ( 'achievement' )
            // InternalScSl.g:3268:2: 'achievement'
            {
             before(grammarAccess.getClearActionAccess().getAchievementKeyword_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getClearActionAccess().getAchievementKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClearAction__Group__0__Impl"


    // $ANTLR start "rule__ClearAction__Group__1"
    // InternalScSl.g:3277:1: rule__ClearAction__Group__1 : rule__ClearAction__Group__1__Impl ;
    public final void rule__ClearAction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3281:1: ( rule__ClearAction__Group__1__Impl )
            // InternalScSl.g:3282:2: rule__ClearAction__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClearAction__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClearAction__Group__1"


    // $ANTLR start "rule__ClearAction__Group__1__Impl"
    // InternalScSl.g:3288:1: rule__ClearAction__Group__1__Impl : ( ( rule__ClearAction__AAssignment_1 ) ) ;
    public final void rule__ClearAction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3292:1: ( ( ( rule__ClearAction__AAssignment_1 ) ) )
            // InternalScSl.g:3293:1: ( ( rule__ClearAction__AAssignment_1 ) )
            {
            // InternalScSl.g:3293:1: ( ( rule__ClearAction__AAssignment_1 ) )
            // InternalScSl.g:3294:2: ( rule__ClearAction__AAssignment_1 )
            {
             before(grammarAccess.getClearActionAccess().getAAssignment_1()); 
            // InternalScSl.g:3295:2: ( rule__ClearAction__AAssignment_1 )
            // InternalScSl.g:3295:3: rule__ClearAction__AAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ClearAction__AAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClearActionAccess().getAAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClearAction__Group__1__Impl"


    // $ANTLR start "rule__DriveAction__Group__0"
    // InternalScSl.g:3304:1: rule__DriveAction__Group__0 : rule__DriveAction__Group__0__Impl rule__DriveAction__Group__1 ;
    public final void rule__DriveAction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3308:1: ( rule__DriveAction__Group__0__Impl rule__DriveAction__Group__1 )
            // InternalScSl.g:3309:2: rule__DriveAction__Group__0__Impl rule__DriveAction__Group__1
            {
            pushFollow(FOLLOW_27);
            rule__DriveAction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DriveAction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DriveAction__Group__0"


    // $ANTLR start "rule__DriveAction__Group__0__Impl"
    // InternalScSl.g:3316:1: rule__DriveAction__Group__0__Impl : ( ( rule__DriveAction__DirectionAssignment_0 ) ) ;
    public final void rule__DriveAction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3320:1: ( ( ( rule__DriveAction__DirectionAssignment_0 ) ) )
            // InternalScSl.g:3321:1: ( ( rule__DriveAction__DirectionAssignment_0 ) )
            {
            // InternalScSl.g:3321:1: ( ( rule__DriveAction__DirectionAssignment_0 ) )
            // InternalScSl.g:3322:2: ( rule__DriveAction__DirectionAssignment_0 )
            {
             before(grammarAccess.getDriveActionAccess().getDirectionAssignment_0()); 
            // InternalScSl.g:3323:2: ( rule__DriveAction__DirectionAssignment_0 )
            // InternalScSl.g:3323:3: rule__DriveAction__DirectionAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__DriveAction__DirectionAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getDriveActionAccess().getDirectionAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DriveAction__Group__0__Impl"


    // $ANTLR start "rule__DriveAction__Group__1"
    // InternalScSl.g:3331:1: rule__DriveAction__Group__1 : rule__DriveAction__Group__1__Impl ;
    public final void rule__DriveAction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3335:1: ( rule__DriveAction__Group__1__Impl )
            // InternalScSl.g:3336:2: rule__DriveAction__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DriveAction__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DriveAction__Group__1"


    // $ANTLR start "rule__DriveAction__Group__1__Impl"
    // InternalScSl.g:3342:1: rule__DriveAction__Group__1__Impl : ( ( ( rule__DriveAction__Until_condAssignment_1 ) ) ( ( rule__DriveAction__Until_condAssignment_1 )* ) ) ;
    public final void rule__DriveAction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3346:1: ( ( ( ( rule__DriveAction__Until_condAssignment_1 ) ) ( ( rule__DriveAction__Until_condAssignment_1 )* ) ) )
            // InternalScSl.g:3347:1: ( ( ( rule__DriveAction__Until_condAssignment_1 ) ) ( ( rule__DriveAction__Until_condAssignment_1 )* ) )
            {
            // InternalScSl.g:3347:1: ( ( ( rule__DriveAction__Until_condAssignment_1 ) ) ( ( rule__DriveAction__Until_condAssignment_1 )* ) )
            // InternalScSl.g:3348:2: ( ( rule__DriveAction__Until_condAssignment_1 ) ) ( ( rule__DriveAction__Until_condAssignment_1 )* )
            {
            // InternalScSl.g:3348:2: ( ( rule__DriveAction__Until_condAssignment_1 ) )
            // InternalScSl.g:3349:3: ( rule__DriveAction__Until_condAssignment_1 )
            {
             before(grammarAccess.getDriveActionAccess().getUntil_condAssignment_1()); 
            // InternalScSl.g:3350:3: ( rule__DriveAction__Until_condAssignment_1 )
            // InternalScSl.g:3350:4: rule__DriveAction__Until_condAssignment_1
            {
            pushFollow(FOLLOW_3);
            rule__DriveAction__Until_condAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDriveActionAccess().getUntil_condAssignment_1()); 

            }

            // InternalScSl.g:3353:2: ( ( rule__DriveAction__Until_condAssignment_1 )* )
            // InternalScSl.g:3354:3: ( rule__DriveAction__Until_condAssignment_1 )*
            {
             before(grammarAccess.getDriveActionAccess().getUntil_condAssignment_1()); 
            // InternalScSl.g:3355:3: ( rule__DriveAction__Until_condAssignment_1 )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==41) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // InternalScSl.g:3355:4: rule__DriveAction__Until_condAssignment_1
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__DriveAction__Until_condAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);

             after(grammarAccess.getDriveActionAccess().getUntil_condAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DriveAction__Group__1__Impl"


    // $ANTLR start "rule__TurnAction__Group__0"
    // InternalScSl.g:3365:1: rule__TurnAction__Group__0 : rule__TurnAction__Group__0__Impl rule__TurnAction__Group__1 ;
    public final void rule__TurnAction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3369:1: ( rule__TurnAction__Group__0__Impl rule__TurnAction__Group__1 )
            // InternalScSl.g:3370:2: rule__TurnAction__Group__0__Impl rule__TurnAction__Group__1
            {
            pushFollow(FOLLOW_27);
            rule__TurnAction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TurnAction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TurnAction__Group__0"


    // $ANTLR start "rule__TurnAction__Group__0__Impl"
    // InternalScSl.g:3377:1: rule__TurnAction__Group__0__Impl : ( ( rule__TurnAction__DirectionAssignment_0 ) ) ;
    public final void rule__TurnAction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3381:1: ( ( ( rule__TurnAction__DirectionAssignment_0 ) ) )
            // InternalScSl.g:3382:1: ( ( rule__TurnAction__DirectionAssignment_0 ) )
            {
            // InternalScSl.g:3382:1: ( ( rule__TurnAction__DirectionAssignment_0 ) )
            // InternalScSl.g:3383:2: ( rule__TurnAction__DirectionAssignment_0 )
            {
             before(grammarAccess.getTurnActionAccess().getDirectionAssignment_0()); 
            // InternalScSl.g:3384:2: ( rule__TurnAction__DirectionAssignment_0 )
            // InternalScSl.g:3384:3: rule__TurnAction__DirectionAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__TurnAction__DirectionAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getTurnActionAccess().getDirectionAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TurnAction__Group__0__Impl"


    // $ANTLR start "rule__TurnAction__Group__1"
    // InternalScSl.g:3392:1: rule__TurnAction__Group__1 : rule__TurnAction__Group__1__Impl ;
    public final void rule__TurnAction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3396:1: ( rule__TurnAction__Group__1__Impl )
            // InternalScSl.g:3397:2: rule__TurnAction__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TurnAction__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TurnAction__Group__1"


    // $ANTLR start "rule__TurnAction__Group__1__Impl"
    // InternalScSl.g:3403:1: rule__TurnAction__Group__1__Impl : ( ( ( rule__TurnAction__Until_condAssignment_1 ) ) ( ( rule__TurnAction__Until_condAssignment_1 )* ) ) ;
    public final void rule__TurnAction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3407:1: ( ( ( ( rule__TurnAction__Until_condAssignment_1 ) ) ( ( rule__TurnAction__Until_condAssignment_1 )* ) ) )
            // InternalScSl.g:3408:1: ( ( ( rule__TurnAction__Until_condAssignment_1 ) ) ( ( rule__TurnAction__Until_condAssignment_1 )* ) )
            {
            // InternalScSl.g:3408:1: ( ( ( rule__TurnAction__Until_condAssignment_1 ) ) ( ( rule__TurnAction__Until_condAssignment_1 )* ) )
            // InternalScSl.g:3409:2: ( ( rule__TurnAction__Until_condAssignment_1 ) ) ( ( rule__TurnAction__Until_condAssignment_1 )* )
            {
            // InternalScSl.g:3409:2: ( ( rule__TurnAction__Until_condAssignment_1 ) )
            // InternalScSl.g:3410:3: ( rule__TurnAction__Until_condAssignment_1 )
            {
             before(grammarAccess.getTurnActionAccess().getUntil_condAssignment_1()); 
            // InternalScSl.g:3411:3: ( rule__TurnAction__Until_condAssignment_1 )
            // InternalScSl.g:3411:4: rule__TurnAction__Until_condAssignment_1
            {
            pushFollow(FOLLOW_3);
            rule__TurnAction__Until_condAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getTurnActionAccess().getUntil_condAssignment_1()); 

            }

            // InternalScSl.g:3414:2: ( ( rule__TurnAction__Until_condAssignment_1 )* )
            // InternalScSl.g:3415:3: ( rule__TurnAction__Until_condAssignment_1 )*
            {
             before(grammarAccess.getTurnActionAccess().getUntil_condAssignment_1()); 
            // InternalScSl.g:3416:3: ( rule__TurnAction__Until_condAssignment_1 )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==41) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalScSl.g:3416:4: rule__TurnAction__Until_condAssignment_1
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__TurnAction__Until_condAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

             after(grammarAccess.getTurnActionAccess().getUntil_condAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TurnAction__Group__1__Impl"


    // $ANTLR start "rule__ColorCondition__Group__0"
    // InternalScSl.g:3426:1: rule__ColorCondition__Group__0 : rule__ColorCondition__Group__0__Impl rule__ColorCondition__Group__1 ;
    public final void rule__ColorCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3430:1: ( rule__ColorCondition__Group__0__Impl rule__ColorCondition__Group__1 )
            // InternalScSl.g:3431:2: rule__ColorCondition__Group__0__Impl rule__ColorCondition__Group__1
            {
            pushFollow(FOLLOW_33);
            rule__ColorCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ColorCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorCondition__Group__0"


    // $ANTLR start "rule__ColorCondition__Group__0__Impl"
    // InternalScSl.g:3438:1: rule__ColorCondition__Group__0__Impl : ( 'color' ) ;
    public final void rule__ColorCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3442:1: ( ( 'color' ) )
            // InternalScSl.g:3443:1: ( 'color' )
            {
            // InternalScSl.g:3443:1: ( 'color' )
            // InternalScSl.g:3444:2: 'color'
            {
             before(grammarAccess.getColorConditionAccess().getColorKeyword_0()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getColorConditionAccess().getColorKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorCondition__Group__0__Impl"


    // $ANTLR start "rule__ColorCondition__Group__1"
    // InternalScSl.g:3453:1: rule__ColorCondition__Group__1 : rule__ColorCondition__Group__1__Impl ;
    public final void rule__ColorCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3457:1: ( rule__ColorCondition__Group__1__Impl )
            // InternalScSl.g:3458:2: rule__ColorCondition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ColorCondition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorCondition__Group__1"


    // $ANTLR start "rule__ColorCondition__Group__1__Impl"
    // InternalScSl.g:3464:1: rule__ColorCondition__Group__1__Impl : ( ( rule__ColorCondition__CAssignment_1 ) ) ;
    public final void rule__ColorCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3468:1: ( ( ( rule__ColorCondition__CAssignment_1 ) ) )
            // InternalScSl.g:3469:1: ( ( rule__ColorCondition__CAssignment_1 ) )
            {
            // InternalScSl.g:3469:1: ( ( rule__ColorCondition__CAssignment_1 ) )
            // InternalScSl.g:3470:2: ( rule__ColorCondition__CAssignment_1 )
            {
             before(grammarAccess.getColorConditionAccess().getCAssignment_1()); 
            // InternalScSl.g:3471:2: ( rule__ColorCondition__CAssignment_1 )
            // InternalScSl.g:3471:3: rule__ColorCondition__CAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ColorCondition__CAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getColorConditionAccess().getCAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorCondition__Group__1__Impl"


    // $ANTLR start "rule__ObjectFrontCondition__Group__0"
    // InternalScSl.g:3480:1: rule__ObjectFrontCondition__Group__0 : rule__ObjectFrontCondition__Group__0__Impl rule__ObjectFrontCondition__Group__1 ;
    public final void rule__ObjectFrontCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3484:1: ( rule__ObjectFrontCondition__Group__0__Impl rule__ObjectFrontCondition__Group__1 )
            // InternalScSl.g:3485:2: rule__ObjectFrontCondition__Group__0__Impl rule__ObjectFrontCondition__Group__1
            {
            pushFollow(FOLLOW_34);
            rule__ObjectFrontCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectFrontCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectFrontCondition__Group__0"


    // $ANTLR start "rule__ObjectFrontCondition__Group__0__Impl"
    // InternalScSl.g:3492:1: rule__ObjectFrontCondition__Group__0__Impl : ( 'front' ) ;
    public final void rule__ObjectFrontCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3496:1: ( ( 'front' ) )
            // InternalScSl.g:3497:1: ( 'front' )
            {
            // InternalScSl.g:3497:1: ( 'front' )
            // InternalScSl.g:3498:2: 'front'
            {
             before(grammarAccess.getObjectFrontConditionAccess().getFrontKeyword_0()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getObjectFrontConditionAccess().getFrontKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectFrontCondition__Group__0__Impl"


    // $ANTLR start "rule__ObjectFrontCondition__Group__1"
    // InternalScSl.g:3507:1: rule__ObjectFrontCondition__Group__1 : rule__ObjectFrontCondition__Group__1__Impl ;
    public final void rule__ObjectFrontCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3511:1: ( rule__ObjectFrontCondition__Group__1__Impl )
            // InternalScSl.g:3512:2: rule__ObjectFrontCondition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectFrontCondition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectFrontCondition__Group__1"


    // $ANTLR start "rule__ObjectFrontCondition__Group__1__Impl"
    // InternalScSl.g:3518:1: rule__ObjectFrontCondition__Group__1__Impl : ( ( rule__ObjectFrontCondition__SAssignment_1 ) ) ;
    public final void rule__ObjectFrontCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3522:1: ( ( ( rule__ObjectFrontCondition__SAssignment_1 ) ) )
            // InternalScSl.g:3523:1: ( ( rule__ObjectFrontCondition__SAssignment_1 ) )
            {
            // InternalScSl.g:3523:1: ( ( rule__ObjectFrontCondition__SAssignment_1 ) )
            // InternalScSl.g:3524:2: ( rule__ObjectFrontCondition__SAssignment_1 )
            {
             before(grammarAccess.getObjectFrontConditionAccess().getSAssignment_1()); 
            // InternalScSl.g:3525:2: ( rule__ObjectFrontCondition__SAssignment_1 )
            // InternalScSl.g:3525:3: rule__ObjectFrontCondition__SAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ObjectFrontCondition__SAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getObjectFrontConditionAccess().getSAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectFrontCondition__Group__1__Impl"


    // $ANTLR start "rule__ObjectRightCondition__Group__0"
    // InternalScSl.g:3534:1: rule__ObjectRightCondition__Group__0 : rule__ObjectRightCondition__Group__0__Impl rule__ObjectRightCondition__Group__1 ;
    public final void rule__ObjectRightCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3538:1: ( rule__ObjectRightCondition__Group__0__Impl rule__ObjectRightCondition__Group__1 )
            // InternalScSl.g:3539:2: rule__ObjectRightCondition__Group__0__Impl rule__ObjectRightCondition__Group__1
            {
            pushFollow(FOLLOW_34);
            rule__ObjectRightCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectRightCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectRightCondition__Group__0"


    // $ANTLR start "rule__ObjectRightCondition__Group__0__Impl"
    // InternalScSl.g:3546:1: rule__ObjectRightCondition__Group__0__Impl : ( 'right' ) ;
    public final void rule__ObjectRightCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3550:1: ( ( 'right' ) )
            // InternalScSl.g:3551:1: ( 'right' )
            {
            // InternalScSl.g:3551:1: ( 'right' )
            // InternalScSl.g:3552:2: 'right'
            {
             before(grammarAccess.getObjectRightConditionAccess().getRightKeyword_0()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getObjectRightConditionAccess().getRightKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectRightCondition__Group__0__Impl"


    // $ANTLR start "rule__ObjectRightCondition__Group__1"
    // InternalScSl.g:3561:1: rule__ObjectRightCondition__Group__1 : rule__ObjectRightCondition__Group__1__Impl ;
    public final void rule__ObjectRightCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3565:1: ( rule__ObjectRightCondition__Group__1__Impl )
            // InternalScSl.g:3566:2: rule__ObjectRightCondition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectRightCondition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectRightCondition__Group__1"


    // $ANTLR start "rule__ObjectRightCondition__Group__1__Impl"
    // InternalScSl.g:3572:1: rule__ObjectRightCondition__Group__1__Impl : ( ( rule__ObjectRightCondition__SAssignment_1 ) ) ;
    public final void rule__ObjectRightCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3576:1: ( ( ( rule__ObjectRightCondition__SAssignment_1 ) ) )
            // InternalScSl.g:3577:1: ( ( rule__ObjectRightCondition__SAssignment_1 ) )
            {
            // InternalScSl.g:3577:1: ( ( rule__ObjectRightCondition__SAssignment_1 ) )
            // InternalScSl.g:3578:2: ( rule__ObjectRightCondition__SAssignment_1 )
            {
             before(grammarAccess.getObjectRightConditionAccess().getSAssignment_1()); 
            // InternalScSl.g:3579:2: ( rule__ObjectRightCondition__SAssignment_1 )
            // InternalScSl.g:3579:3: rule__ObjectRightCondition__SAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ObjectRightCondition__SAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getObjectRightConditionAccess().getSAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectRightCondition__Group__1__Impl"


    // $ANTLR start "rule__TimeCondition__Group__0"
    // InternalScSl.g:3588:1: rule__TimeCondition__Group__0 : rule__TimeCondition__Group__0__Impl rule__TimeCondition__Group__1 ;
    public final void rule__TimeCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3592:1: ( rule__TimeCondition__Group__0__Impl rule__TimeCondition__Group__1 )
            // InternalScSl.g:3593:2: rule__TimeCondition__Group__0__Impl rule__TimeCondition__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__TimeCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeCondition__Group__0"


    // $ANTLR start "rule__TimeCondition__Group__0__Impl"
    // InternalScSl.g:3600:1: rule__TimeCondition__Group__0__Impl : ( 'time' ) ;
    public final void rule__TimeCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3604:1: ( ( 'time' ) )
            // InternalScSl.g:3605:1: ( 'time' )
            {
            // InternalScSl.g:3605:1: ( 'time' )
            // InternalScSl.g:3606:2: 'time'
            {
             before(grammarAccess.getTimeConditionAccess().getTimeKeyword_0()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getTimeConditionAccess().getTimeKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeCondition__Group__0__Impl"


    // $ANTLR start "rule__TimeCondition__Group__1"
    // InternalScSl.g:3615:1: rule__TimeCondition__Group__1 : rule__TimeCondition__Group__1__Impl rule__TimeCondition__Group__2 ;
    public final void rule__TimeCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3619:1: ( rule__TimeCondition__Group__1__Impl rule__TimeCondition__Group__2 )
            // InternalScSl.g:3620:2: rule__TimeCondition__Group__1__Impl rule__TimeCondition__Group__2
            {
            pushFollow(FOLLOW_32);
            rule__TimeCondition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeCondition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeCondition__Group__1"


    // $ANTLR start "rule__TimeCondition__Group__1__Impl"
    // InternalScSl.g:3627:1: rule__TimeCondition__Group__1__Impl : ( ( rule__TimeCondition__TAssignment_1 ) ) ;
    public final void rule__TimeCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3631:1: ( ( ( rule__TimeCondition__TAssignment_1 ) ) )
            // InternalScSl.g:3632:1: ( ( rule__TimeCondition__TAssignment_1 ) )
            {
            // InternalScSl.g:3632:1: ( ( rule__TimeCondition__TAssignment_1 ) )
            // InternalScSl.g:3633:2: ( rule__TimeCondition__TAssignment_1 )
            {
             before(grammarAccess.getTimeConditionAccess().getTAssignment_1()); 
            // InternalScSl.g:3634:2: ( rule__TimeCondition__TAssignment_1 )
            // InternalScSl.g:3634:3: rule__TimeCondition__TAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__TimeCondition__TAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getTimeConditionAccess().getTAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeCondition__Group__1__Impl"


    // $ANTLR start "rule__TimeCondition__Group__2"
    // InternalScSl.g:3642:1: rule__TimeCondition__Group__2 : rule__TimeCondition__Group__2__Impl ;
    public final void rule__TimeCondition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3646:1: ( rule__TimeCondition__Group__2__Impl )
            // InternalScSl.g:3647:2: rule__TimeCondition__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TimeCondition__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeCondition__Group__2"


    // $ANTLR start "rule__TimeCondition__Group__2__Impl"
    // InternalScSl.g:3653:1: rule__TimeCondition__Group__2__Impl : ( 'ms' ) ;
    public final void rule__TimeCondition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3657:1: ( ( 'ms' ) )
            // InternalScSl.g:3658:1: ( 'ms' )
            {
            // InternalScSl.g:3658:1: ( 'ms' )
            // InternalScSl.g:3659:2: 'ms'
            {
             before(grammarAccess.getTimeConditionAccess().getMsKeyword_2()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getTimeConditionAccess().getMsKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeCondition__Group__2__Impl"


    // $ANTLR start "rule__AchievementCondition__Group__0"
    // InternalScSl.g:3669:1: rule__AchievementCondition__Group__0 : rule__AchievementCondition__Group__0__Impl rule__AchievementCondition__Group__1 ;
    public final void rule__AchievementCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3673:1: ( rule__AchievementCondition__Group__0__Impl rule__AchievementCondition__Group__1 )
            // InternalScSl.g:3674:2: rule__AchievementCondition__Group__0__Impl rule__AchievementCondition__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__AchievementCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AchievementCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AchievementCondition__Group__0"


    // $ANTLR start "rule__AchievementCondition__Group__0__Impl"
    // InternalScSl.g:3681:1: rule__AchievementCondition__Group__0__Impl : ( 'achievement' ) ;
    public final void rule__AchievementCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3685:1: ( ( 'achievement' ) )
            // InternalScSl.g:3686:1: ( 'achievement' )
            {
            // InternalScSl.g:3686:1: ( 'achievement' )
            // InternalScSl.g:3687:2: 'achievement'
            {
             before(grammarAccess.getAchievementConditionAccess().getAchievementKeyword_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getAchievementConditionAccess().getAchievementKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AchievementCondition__Group__0__Impl"


    // $ANTLR start "rule__AchievementCondition__Group__1"
    // InternalScSl.g:3696:1: rule__AchievementCondition__Group__1 : rule__AchievementCondition__Group__1__Impl ;
    public final void rule__AchievementCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3700:1: ( rule__AchievementCondition__Group__1__Impl )
            // InternalScSl.g:3701:2: rule__AchievementCondition__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__AchievementCondition__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AchievementCondition__Group__1"


    // $ANTLR start "rule__AchievementCondition__Group__1__Impl"
    // InternalScSl.g:3707:1: rule__AchievementCondition__Group__1__Impl : ( ( rule__AchievementCondition__AAssignment_1 ) ) ;
    public final void rule__AchievementCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3711:1: ( ( ( rule__AchievementCondition__AAssignment_1 ) ) )
            // InternalScSl.g:3712:1: ( ( rule__AchievementCondition__AAssignment_1 ) )
            {
            // InternalScSl.g:3712:1: ( ( rule__AchievementCondition__AAssignment_1 ) )
            // InternalScSl.g:3713:2: ( rule__AchievementCondition__AAssignment_1 )
            {
             before(grammarAccess.getAchievementConditionAccess().getAAssignment_1()); 
            // InternalScSl.g:3714:2: ( rule__AchievementCondition__AAssignment_1 )
            // InternalScSl.g:3714:3: rule__AchievementCondition__AAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__AchievementCondition__AAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getAchievementConditionAccess().getAAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AchievementCondition__Group__1__Impl"


    // $ANTLR start "rule__MemoryCondition__Group_0__0"
    // InternalScSl.g:3723:1: rule__MemoryCondition__Group_0__0 : rule__MemoryCondition__Group_0__0__Impl rule__MemoryCondition__Group_0__1 ;
    public final void rule__MemoryCondition__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3727:1: ( rule__MemoryCondition__Group_0__0__Impl rule__MemoryCondition__Group_0__1 )
            // InternalScSl.g:3728:2: rule__MemoryCondition__Group_0__0__Impl rule__MemoryCondition__Group_0__1
            {
            pushFollow(FOLLOW_35);
            rule__MemoryCondition__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MemoryCondition__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_0__0"


    // $ANTLR start "rule__MemoryCondition__Group_0__0__Impl"
    // InternalScSl.g:3735:1: rule__MemoryCondition__Group_0__0__Impl : ( 'memory' ) ;
    public final void rule__MemoryCondition__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3739:1: ( ( 'memory' ) )
            // InternalScSl.g:3740:1: ( 'memory' )
            {
            // InternalScSl.g:3740:1: ( 'memory' )
            // InternalScSl.g:3741:2: 'memory'
            {
             before(grammarAccess.getMemoryConditionAccess().getMemoryKeyword_0_0()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getMemoryConditionAccess().getMemoryKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_0__0__Impl"


    // $ANTLR start "rule__MemoryCondition__Group_0__1"
    // InternalScSl.g:3750:1: rule__MemoryCondition__Group_0__1 : rule__MemoryCondition__Group_0__1__Impl ;
    public final void rule__MemoryCondition__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3754:1: ( rule__MemoryCondition__Group_0__1__Impl )
            // InternalScSl.g:3755:2: rule__MemoryCondition__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MemoryCondition__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_0__1"


    // $ANTLR start "rule__MemoryCondition__Group_0__1__Impl"
    // InternalScSl.g:3761:1: rule__MemoryCondition__Group_0__1__Impl : ( ( rule__MemoryCondition__CAssignment_0_1 ) ) ;
    public final void rule__MemoryCondition__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3765:1: ( ( ( rule__MemoryCondition__CAssignment_0_1 ) ) )
            // InternalScSl.g:3766:1: ( ( rule__MemoryCondition__CAssignment_0_1 ) )
            {
            // InternalScSl.g:3766:1: ( ( rule__MemoryCondition__CAssignment_0_1 ) )
            // InternalScSl.g:3767:2: ( rule__MemoryCondition__CAssignment_0_1 )
            {
             before(grammarAccess.getMemoryConditionAccess().getCAssignment_0_1()); 
            // InternalScSl.g:3768:2: ( rule__MemoryCondition__CAssignment_0_1 )
            // InternalScSl.g:3768:3: rule__MemoryCondition__CAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__MemoryCondition__CAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getMemoryConditionAccess().getCAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_0__1__Impl"


    // $ANTLR start "rule__MemoryCondition__Group_1__0"
    // InternalScSl.g:3777:1: rule__MemoryCondition__Group_1__0 : rule__MemoryCondition__Group_1__0__Impl rule__MemoryCondition__Group_1__1 ;
    public final void rule__MemoryCondition__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3781:1: ( rule__MemoryCondition__Group_1__0__Impl rule__MemoryCondition__Group_1__1 )
            // InternalScSl.g:3782:2: rule__MemoryCondition__Group_1__0__Impl rule__MemoryCondition__Group_1__1
            {
            pushFollow(FOLLOW_36);
            rule__MemoryCondition__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MemoryCondition__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_1__0"


    // $ANTLR start "rule__MemoryCondition__Group_1__0__Impl"
    // InternalScSl.g:3789:1: rule__MemoryCondition__Group_1__0__Impl : ( 'memory' ) ;
    public final void rule__MemoryCondition__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3793:1: ( ( 'memory' ) )
            // InternalScSl.g:3794:1: ( 'memory' )
            {
            // InternalScSl.g:3794:1: ( 'memory' )
            // InternalScSl.g:3795:2: 'memory'
            {
             before(grammarAccess.getMemoryConditionAccess().getMemoryKeyword_1_0()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getMemoryConditionAccess().getMemoryKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_1__0__Impl"


    // $ANTLR start "rule__MemoryCondition__Group_1__1"
    // InternalScSl.g:3804:1: rule__MemoryCondition__Group_1__1 : rule__MemoryCondition__Group_1__1__Impl ;
    public final void rule__MemoryCondition__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3808:1: ( rule__MemoryCondition__Group_1__1__Impl )
            // InternalScSl.g:3809:2: rule__MemoryCondition__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MemoryCondition__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_1__1"


    // $ANTLR start "rule__MemoryCondition__Group_1__1__Impl"
    // InternalScSl.g:3815:1: rule__MemoryCondition__Group_1__1__Impl : ( ( rule__MemoryCondition__CAssignment_1_1 ) ) ;
    public final void rule__MemoryCondition__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3819:1: ( ( ( rule__MemoryCondition__CAssignment_1_1 ) ) )
            // InternalScSl.g:3820:1: ( ( rule__MemoryCondition__CAssignment_1_1 ) )
            {
            // InternalScSl.g:3820:1: ( ( rule__MemoryCondition__CAssignment_1_1 ) )
            // InternalScSl.g:3821:2: ( rule__MemoryCondition__CAssignment_1_1 )
            {
             before(grammarAccess.getMemoryConditionAccess().getCAssignment_1_1()); 
            // InternalScSl.g:3822:2: ( rule__MemoryCondition__CAssignment_1_1 )
            // InternalScSl.g:3822:3: rule__MemoryCondition__CAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__MemoryCondition__CAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getMemoryConditionAccess().getCAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_1__1__Impl"


    // $ANTLR start "rule__MemoryCondition__Group_2__0"
    // InternalScSl.g:3831:1: rule__MemoryCondition__Group_2__0 : rule__MemoryCondition__Group_2__0__Impl rule__MemoryCondition__Group_2__1 ;
    public final void rule__MemoryCondition__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3835:1: ( rule__MemoryCondition__Group_2__0__Impl rule__MemoryCondition__Group_2__1 )
            // InternalScSl.g:3836:2: rule__MemoryCondition__Group_2__0__Impl rule__MemoryCondition__Group_2__1
            {
            pushFollow(FOLLOW_37);
            rule__MemoryCondition__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MemoryCondition__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_2__0"


    // $ANTLR start "rule__MemoryCondition__Group_2__0__Impl"
    // InternalScSl.g:3843:1: rule__MemoryCondition__Group_2__0__Impl : ( 'memory' ) ;
    public final void rule__MemoryCondition__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3847:1: ( ( 'memory' ) )
            // InternalScSl.g:3848:1: ( 'memory' )
            {
            // InternalScSl.g:3848:1: ( 'memory' )
            // InternalScSl.g:3849:2: 'memory'
            {
             before(grammarAccess.getMemoryConditionAccess().getMemoryKeyword_2_0()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getMemoryConditionAccess().getMemoryKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_2__0__Impl"


    // $ANTLR start "rule__MemoryCondition__Group_2__1"
    // InternalScSl.g:3858:1: rule__MemoryCondition__Group_2__1 : rule__MemoryCondition__Group_2__1__Impl ;
    public final void rule__MemoryCondition__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3862:1: ( rule__MemoryCondition__Group_2__1__Impl )
            // InternalScSl.g:3863:2: rule__MemoryCondition__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MemoryCondition__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_2__1"


    // $ANTLR start "rule__MemoryCondition__Group_2__1__Impl"
    // InternalScSl.g:3869:1: rule__MemoryCondition__Group_2__1__Impl : ( ( rule__MemoryCondition__CAssignment_2_1 ) ) ;
    public final void rule__MemoryCondition__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3873:1: ( ( ( rule__MemoryCondition__CAssignment_2_1 ) ) )
            // InternalScSl.g:3874:1: ( ( rule__MemoryCondition__CAssignment_2_1 ) )
            {
            // InternalScSl.g:3874:1: ( ( rule__MemoryCondition__CAssignment_2_1 ) )
            // InternalScSl.g:3875:2: ( rule__MemoryCondition__CAssignment_2_1 )
            {
             before(grammarAccess.getMemoryConditionAccess().getCAssignment_2_1()); 
            // InternalScSl.g:3876:2: ( rule__MemoryCondition__CAssignment_2_1 )
            // InternalScSl.g:3876:3: rule__MemoryCondition__CAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__MemoryCondition__CAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getMemoryConditionAccess().getCAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__Group_2__1__Impl"


    // $ANTLR start "rule__ColorDetection__Group__0"
    // InternalScSl.g:3885:1: rule__ColorDetection__Group__0 : rule__ColorDetection__Group__0__Impl rule__ColorDetection__Group__1 ;
    public final void rule__ColorDetection__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3889:1: ( rule__ColorDetection__Group__0__Impl rule__ColorDetection__Group__1 )
            // InternalScSl.g:3890:2: rule__ColorDetection__Group__0__Impl rule__ColorDetection__Group__1
            {
            pushFollow(FOLLOW_38);
            rule__ColorDetection__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ColorDetection__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorDetection__Group__0"


    // $ANTLR start "rule__ColorDetection__Group__0__Impl"
    // InternalScSl.g:3897:1: rule__ColorDetection__Group__0__Impl : ( ( rule__ColorDetection__SensorAssignment_0 ) ) ;
    public final void rule__ColorDetection__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3901:1: ( ( ( rule__ColorDetection__SensorAssignment_0 ) ) )
            // InternalScSl.g:3902:1: ( ( rule__ColorDetection__SensorAssignment_0 ) )
            {
            // InternalScSl.g:3902:1: ( ( rule__ColorDetection__SensorAssignment_0 ) )
            // InternalScSl.g:3903:2: ( rule__ColorDetection__SensorAssignment_0 )
            {
             before(grammarAccess.getColorDetectionAccess().getSensorAssignment_0()); 
            // InternalScSl.g:3904:2: ( rule__ColorDetection__SensorAssignment_0 )
            // InternalScSl.g:3904:3: rule__ColorDetection__SensorAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ColorDetection__SensorAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getColorDetectionAccess().getSensorAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorDetection__Group__0__Impl"


    // $ANTLR start "rule__ColorDetection__Group__1"
    // InternalScSl.g:3912:1: rule__ColorDetection__Group__1 : rule__ColorDetection__Group__1__Impl ;
    public final void rule__ColorDetection__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3916:1: ( rule__ColorDetection__Group__1__Impl )
            // InternalScSl.g:3917:2: rule__ColorDetection__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ColorDetection__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorDetection__Group__1"


    // $ANTLR start "rule__ColorDetection__Group__1__Impl"
    // InternalScSl.g:3923:1: rule__ColorDetection__Group__1__Impl : ( ( rule__ColorDetection__ColorAssignment_1 ) ) ;
    public final void rule__ColorDetection__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3927:1: ( ( ( rule__ColorDetection__ColorAssignment_1 ) ) )
            // InternalScSl.g:3928:1: ( ( rule__ColorDetection__ColorAssignment_1 ) )
            {
            // InternalScSl.g:3928:1: ( ( rule__ColorDetection__ColorAssignment_1 ) )
            // InternalScSl.g:3929:2: ( rule__ColorDetection__ColorAssignment_1 )
            {
             before(grammarAccess.getColorDetectionAccess().getColorAssignment_1()); 
            // InternalScSl.g:3930:2: ( rule__ColorDetection__ColorAssignment_1 )
            // InternalScSl.g:3930:3: rule__ColorDetection__ColorAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ColorDetection__ColorAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getColorDetectionAccess().getColorAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorDetection__Group__1__Impl"


    // $ANTLR start "rule__Mission__NameAssignment_1"
    // InternalScSl.g:3939:1: rule__Mission__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Mission__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3943:1: ( ( RULE_ID ) )
            // InternalScSl.g:3944:2: ( RULE_ID )
            {
            // InternalScSl.g:3944:2: ( RULE_ID )
            // InternalScSl.g:3945:3: RULE_ID
            {
             before(grammarAccess.getMissionAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__NameAssignment_1"


    // $ANTLR start "rule__Mission__AchievementsAssignment_2_1"
    // InternalScSl.g:3954:1: rule__Mission__AchievementsAssignment_2_1 : ( RULE_INT ) ;
    public final void rule__Mission__AchievementsAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3958:1: ( ( RULE_INT ) )
            // InternalScSl.g:3959:2: ( RULE_INT )
            {
            // InternalScSl.g:3959:2: ( RULE_INT )
            // InternalScSl.g:3960:3: RULE_INT
            {
             before(grammarAccess.getMissionAccess().getAchievementsINTTerminalRuleCall_2_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getMissionAccess().getAchievementsINTTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__AchievementsAssignment_2_1"


    // $ANTLR start "rule__Mission__GoalsAssignment_3"
    // InternalScSl.g:3969:1: rule__Mission__GoalsAssignment_3 : ( ruleGoal ) ;
    public final void rule__Mission__GoalsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3973:1: ( ( ruleGoal ) )
            // InternalScSl.g:3974:2: ( ruleGoal )
            {
            // InternalScSl.g:3974:2: ( ruleGoal )
            // InternalScSl.g:3975:3: ruleGoal
            {
             before(grammarAccess.getMissionAccess().getGoalsGoalParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleGoal();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getGoalsGoalParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__GoalsAssignment_3"


    // $ANTLR start "rule__Mission__Drive_speedAssignment_4_1"
    // InternalScSl.g:3984:1: rule__Mission__Drive_speedAssignment_4_1 : ( ruleSpeed ) ;
    public final void rule__Mission__Drive_speedAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:3988:1: ( ( ruleSpeed ) )
            // InternalScSl.g:3989:2: ( ruleSpeed )
            {
            // InternalScSl.g:3989:2: ( ruleSpeed )
            // InternalScSl.g:3990:3: ruleSpeed
            {
             before(grammarAccess.getMissionAccess().getDrive_speedSpeedParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleSpeed();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getDrive_speedSpeedParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Drive_speedAssignment_4_1"


    // $ANTLR start "rule__Mission__Turn_speedAssignment_5_1"
    // InternalScSl.g:3999:1: rule__Mission__Turn_speedAssignment_5_1 : ( ruleSpeed ) ;
    public final void rule__Mission__Turn_speedAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4003:1: ( ( ruleSpeed ) )
            // InternalScSl.g:4004:2: ( ruleSpeed )
            {
            // InternalScSl.g:4004:2: ( ruleSpeed )
            // InternalScSl.g:4005:3: ruleSpeed
            {
             before(grammarAccess.getMissionAccess().getTurn_speedSpeedParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleSpeed();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getTurn_speedSpeedParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Turn_speedAssignment_5_1"


    // $ANTLR start "rule__Mission__Sensor_dist_frontAssignment_6_1"
    // InternalScSl.g:4014:1: rule__Mission__Sensor_dist_frontAssignment_6_1 : ( ruleDistance_Pins ) ;
    public final void rule__Mission__Sensor_dist_frontAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4018:1: ( ( ruleDistance_Pins ) )
            // InternalScSl.g:4019:2: ( ruleDistance_Pins )
            {
            // InternalScSl.g:4019:2: ( ruleDistance_Pins )
            // InternalScSl.g:4020:3: ruleDistance_Pins
            {
             before(grammarAccess.getMissionAccess().getSensor_dist_frontDistance_PinsParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDistance_Pins();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getSensor_dist_frontDistance_PinsParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Sensor_dist_frontAssignment_6_1"


    // $ANTLR start "rule__Mission__Sensor_dist_rightAssignment_7_1"
    // InternalScSl.g:4029:1: rule__Mission__Sensor_dist_rightAssignment_7_1 : ( ruleDistance_Pins ) ;
    public final void rule__Mission__Sensor_dist_rightAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4033:1: ( ( ruleDistance_Pins ) )
            // InternalScSl.g:4034:2: ( ruleDistance_Pins )
            {
            // InternalScSl.g:4034:2: ( ruleDistance_Pins )
            // InternalScSl.g:4035:3: ruleDistance_Pins
            {
             before(grammarAccess.getMissionAccess().getSensor_dist_rightDistance_PinsParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDistance_Pins();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getSensor_dist_rightDistance_PinsParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Sensor_dist_rightAssignment_7_1"


    // $ANTLR start "rule__Mission__Sensor_color_leftAssignment_8_1"
    // InternalScSl.g:4044:1: rule__Mission__Sensor_color_leftAssignment_8_1 : ( ruleColor_Pin ) ;
    public final void rule__Mission__Sensor_color_leftAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4048:1: ( ( ruleColor_Pin ) )
            // InternalScSl.g:4049:2: ( ruleColor_Pin )
            {
            // InternalScSl.g:4049:2: ( ruleColor_Pin )
            // InternalScSl.g:4050:3: ruleColor_Pin
            {
             before(grammarAccess.getMissionAccess().getSensor_color_leftColor_PinParserRuleCall_8_1_0()); 
            pushFollow(FOLLOW_2);
            ruleColor_Pin();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getSensor_color_leftColor_PinParserRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Sensor_color_leftAssignment_8_1"


    // $ANTLR start "rule__Mission__Sensor_color_rightAssignment_9_1"
    // InternalScSl.g:4059:1: rule__Mission__Sensor_color_rightAssignment_9_1 : ( ruleColor_Pin ) ;
    public final void rule__Mission__Sensor_color_rightAssignment_9_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4063:1: ( ( ruleColor_Pin ) )
            // InternalScSl.g:4064:2: ( ruleColor_Pin )
            {
            // InternalScSl.g:4064:2: ( ruleColor_Pin )
            // InternalScSl.g:4065:3: ruleColor_Pin
            {
             before(grammarAccess.getMissionAccess().getSensor_color_rightColor_PinParserRuleCall_9_1_0()); 
            pushFollow(FOLLOW_2);
            ruleColor_Pin();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getSensor_color_rightColor_PinParserRuleCall_9_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Sensor_color_rightAssignment_9_1"


    // $ANTLR start "rule__Mission__Motor_leftAssignment_10_1"
    // InternalScSl.g:4074:1: rule__Mission__Motor_leftAssignment_10_1 : ( ruleMotor_Pins ) ;
    public final void rule__Mission__Motor_leftAssignment_10_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4078:1: ( ( ruleMotor_Pins ) )
            // InternalScSl.g:4079:2: ( ruleMotor_Pins )
            {
            // InternalScSl.g:4079:2: ( ruleMotor_Pins )
            // InternalScSl.g:4080:3: ruleMotor_Pins
            {
             before(grammarAccess.getMissionAccess().getMotor_leftMotor_PinsParserRuleCall_10_1_0()); 
            pushFollow(FOLLOW_2);
            ruleMotor_Pins();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getMotor_leftMotor_PinsParserRuleCall_10_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Motor_leftAssignment_10_1"


    // $ANTLR start "rule__Mission__Motor_rightAssignment_11_1"
    // InternalScSl.g:4089:1: rule__Mission__Motor_rightAssignment_11_1 : ( ruleMotor_Pins ) ;
    public final void rule__Mission__Motor_rightAssignment_11_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4093:1: ( ( ruleMotor_Pins ) )
            // InternalScSl.g:4094:2: ( ruleMotor_Pins )
            {
            // InternalScSl.g:4094:2: ( ruleMotor_Pins )
            // InternalScSl.g:4095:3: ruleMotor_Pins
            {
             before(grammarAccess.getMissionAccess().getMotor_rightMotor_PinsParserRuleCall_11_1_0()); 
            pushFollow(FOLLOW_2);
            ruleMotor_Pins();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getMotor_rightMotor_PinsParserRuleCall_11_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__Motor_rightAssignment_11_1"


    // $ANTLR start "rule__Mission__TasksAssignment_13"
    // InternalScSl.g:4104:1: rule__Mission__TasksAssignment_13 : ( ruleTask ) ;
    public final void rule__Mission__TasksAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4108:1: ( ( ruleTask ) )
            // InternalScSl.g:4109:2: ( ruleTask )
            {
            // InternalScSl.g:4109:2: ( ruleTask )
            // InternalScSl.g:4110:3: ruleTask
            {
             before(grammarAccess.getMissionAccess().getTasksTaskParserRuleCall_13_0()); 
            pushFollow(FOLLOW_2);
            ruleTask();

            state._fsp--;

             after(grammarAccess.getMissionAccess().getTasksTaskParserRuleCall_13_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mission__TasksAssignment_13"


    // $ANTLR start "rule__Speed__SAssignment"
    // InternalScSl.g:4119:1: rule__Speed__SAssignment : ( RULE_INT ) ;
    public final void rule__Speed__SAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4123:1: ( ( RULE_INT ) )
            // InternalScSl.g:4124:2: ( RULE_INT )
            {
            // InternalScSl.g:4124:2: ( RULE_INT )
            // InternalScSl.g:4125:3: RULE_INT
            {
             before(grammarAccess.getSpeedAccess().getSINTTerminalRuleCall_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getSpeedAccess().getSINTTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Speed__SAssignment"


    // $ANTLR start "rule__Distance_Pins__TriggerpinAssignment_1"
    // InternalScSl.g:4134:1: rule__Distance_Pins__TriggerpinAssignment_1 : ( rulePind ) ;
    public final void rule__Distance_Pins__TriggerpinAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4138:1: ( ( rulePind ) )
            // InternalScSl.g:4139:2: ( rulePind )
            {
            // InternalScSl.g:4139:2: ( rulePind )
            // InternalScSl.g:4140:3: rulePind
            {
             before(grammarAccess.getDistance_PinsAccess().getTriggerpinPindParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            rulePind();

            state._fsp--;

             after(grammarAccess.getDistance_PinsAccess().getTriggerpinPindParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__TriggerpinAssignment_1"


    // $ANTLR start "rule__Distance_Pins__EchopinAssignment_3"
    // InternalScSl.g:4149:1: rule__Distance_Pins__EchopinAssignment_3 : ( rulePind ) ;
    public final void rule__Distance_Pins__EchopinAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4153:1: ( ( rulePind ) )
            // InternalScSl.g:4154:2: ( rulePind )
            {
            // InternalScSl.g:4154:2: ( rulePind )
            // InternalScSl.g:4155:3: rulePind
            {
             before(grammarAccess.getDistance_PinsAccess().getEchopinPindParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            rulePind();

            state._fsp--;

             after(grammarAccess.getDistance_PinsAccess().getEchopinPindParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distance_Pins__EchopinAssignment_3"


    // $ANTLR start "rule__Color_Pin__PinAssignment_1"
    // InternalScSl.g:4164:1: rule__Color_Pin__PinAssignment_1 : ( RULE_STRING ) ;
    public final void rule__Color_Pin__PinAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4168:1: ( ( RULE_STRING ) )
            // InternalScSl.g:4169:2: ( RULE_STRING )
            {
            // InternalScSl.g:4169:2: ( RULE_STRING )
            // InternalScSl.g:4170:3: RULE_STRING
            {
             before(grammarAccess.getColor_PinAccess().getPinSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getColor_PinAccess().getPinSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Color_Pin__PinAssignment_1"


    // $ANTLR start "rule__Motor_Pins__In1_pinAssignment_1"
    // InternalScSl.g:4179:1: rule__Motor_Pins__In1_pinAssignment_1 : ( rulePind ) ;
    public final void rule__Motor_Pins__In1_pinAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4183:1: ( ( rulePind ) )
            // InternalScSl.g:4184:2: ( rulePind )
            {
            // InternalScSl.g:4184:2: ( rulePind )
            // InternalScSl.g:4185:3: rulePind
            {
             before(grammarAccess.getMotor_PinsAccess().getIn1_pinPindParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            rulePind();

            state._fsp--;

             after(grammarAccess.getMotor_PinsAccess().getIn1_pinPindParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__In1_pinAssignment_1"


    // $ANTLR start "rule__Motor_Pins__In2_pinAssignment_3"
    // InternalScSl.g:4194:1: rule__Motor_Pins__In2_pinAssignment_3 : ( rulePind ) ;
    public final void rule__Motor_Pins__In2_pinAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4198:1: ( ( rulePind ) )
            // InternalScSl.g:4199:2: ( rulePind )
            {
            // InternalScSl.g:4199:2: ( rulePind )
            // InternalScSl.g:4200:3: rulePind
            {
             before(grammarAccess.getMotor_PinsAccess().getIn2_pinPindParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            rulePind();

            state._fsp--;

             after(grammarAccess.getMotor_PinsAccess().getIn2_pinPindParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Motor_Pins__In2_pinAssignment_3"


    // $ANTLR start "rule__Pind__PinAssignment"
    // InternalScSl.g:4209:1: rule__Pind__PinAssignment : ( RULE_INT ) ;
    public final void rule__Pind__PinAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4213:1: ( ( RULE_INT ) )
            // InternalScSl.g:4214:2: ( RULE_INT )
            {
            // InternalScSl.g:4214:2: ( RULE_INT )
            // InternalScSl.g:4215:3: RULE_INT
            {
             before(grammarAccess.getPindAccess().getPinINTTerminalRuleCall_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getPindAccess().getPinINTTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Pind__PinAssignment"


    // $ANTLR start "rule__Task__NameAssignment_1"
    // InternalScSl.g:4224:1: rule__Task__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Task__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4228:1: ( ( RULE_ID ) )
            // InternalScSl.g:4229:2: ( RULE_ID )
            {
            // InternalScSl.g:4229:2: ( RULE_ID )
            // InternalScSl.g:4230:3: RULE_ID
            {
             before(grammarAccess.getTaskAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTaskAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__NameAssignment_1"


    // $ANTLR start "rule__Task__PriorityAssignment_3"
    // InternalScSl.g:4239:1: rule__Task__PriorityAssignment_3 : ( RULE_INT ) ;
    public final void rule__Task__PriorityAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4243:1: ( ( RULE_INT ) )
            // InternalScSl.g:4244:2: ( RULE_INT )
            {
            // InternalScSl.g:4244:2: ( RULE_INT )
            // InternalScSl.g:4245:3: RULE_INT
            {
             before(grammarAccess.getTaskAccess().getPriorityINTTerminalRuleCall_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTaskAccess().getPriorityINTTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__PriorityAssignment_3"


    // $ANTLR start "rule__Task__Starting_condsAssignment_4"
    // InternalScSl.g:4254:1: rule__Task__Starting_condsAssignment_4 : ( ruleStartingCondition ) ;
    public final void rule__Task__Starting_condsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4258:1: ( ( ruleStartingCondition ) )
            // InternalScSl.g:4259:2: ( ruleStartingCondition )
            {
            // InternalScSl.g:4259:2: ( ruleStartingCondition )
            // InternalScSl.g:4260:3: ruleStartingCondition
            {
             before(grammarAccess.getTaskAccess().getStarting_condsStartingConditionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleStartingCondition();

            state._fsp--;

             after(grammarAccess.getTaskAccess().getStarting_condsStartingConditionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Starting_condsAssignment_4"


    // $ANTLR start "rule__Task__Stopping_condsAssignment_5"
    // InternalScSl.g:4269:1: rule__Task__Stopping_condsAssignment_5 : ( ruleStoppingCondition ) ;
    public final void rule__Task__Stopping_condsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4273:1: ( ( ruleStoppingCondition ) )
            // InternalScSl.g:4274:2: ( ruleStoppingCondition )
            {
            // InternalScSl.g:4274:2: ( ruleStoppingCondition )
            // InternalScSl.g:4275:3: ruleStoppingCondition
            {
             before(grammarAccess.getTaskAccess().getStopping_condsStoppingConditionParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleStoppingCondition();

            state._fsp--;

             after(grammarAccess.getTaskAccess().getStopping_condsStoppingConditionParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__Stopping_condsAssignment_5"


    // $ANTLR start "rule__Task__ActionsAssignment_6"
    // InternalScSl.g:4284:1: rule__Task__ActionsAssignment_6 : ( ruleAction ) ;
    public final void rule__Task__ActionsAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4288:1: ( ( ruleAction ) )
            // InternalScSl.g:4289:2: ( ruleAction )
            {
            // InternalScSl.g:4289:2: ( ruleAction )
            // InternalScSl.g:4290:3: ruleAction
            {
             before(grammarAccess.getTaskAccess().getActionsActionParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleAction();

            state._fsp--;

             after(grammarAccess.getTaskAccess().getActionsActionParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Task__ActionsAssignment_6"


    // $ANTLR start "rule__Goal__CondAssignment_1"
    // InternalScSl.g:4299:1: rule__Goal__CondAssignment_1 : ( ruleCondition ) ;
    public final void rule__Goal__CondAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4303:1: ( ( ruleCondition ) )
            // InternalScSl.g:4304:2: ( ruleCondition )
            {
            // InternalScSl.g:4304:2: ( ruleCondition )
            // InternalScSl.g:4305:3: ruleCondition
            {
             before(grammarAccess.getGoalAccess().getCondConditionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getGoalAccess().getCondConditionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Goal__CondAssignment_1"


    // $ANTLR start "rule__StartingCondition__CondAssignment_1"
    // InternalScSl.g:4314:1: rule__StartingCondition__CondAssignment_1 : ( ruleCondition ) ;
    public final void rule__StartingCondition__CondAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4318:1: ( ( ruleCondition ) )
            // InternalScSl.g:4319:2: ( ruleCondition )
            {
            // InternalScSl.g:4319:2: ( ruleCondition )
            // InternalScSl.g:4320:3: ruleCondition
            {
             before(grammarAccess.getStartingConditionAccess().getCondConditionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getStartingConditionAccess().getCondConditionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StartingCondition__CondAssignment_1"


    // $ANTLR start "rule__StoppingCondition__CondAssignment_1"
    // InternalScSl.g:4329:1: rule__StoppingCondition__CondAssignment_1 : ( ruleCondition ) ;
    public final void rule__StoppingCondition__CondAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4333:1: ( ( ruleCondition ) )
            // InternalScSl.g:4334:2: ( ruleCondition )
            {
            // InternalScSl.g:4334:2: ( ruleCondition )
            // InternalScSl.g:4335:3: ruleCondition
            {
             before(grammarAccess.getStoppingConditionAccess().getCondConditionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getStoppingConditionAccess().getCondConditionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StoppingCondition__CondAssignment_1"


    // $ANTLR start "rule__UntilCondition__CondAssignment_1"
    // InternalScSl.g:4344:1: rule__UntilCondition__CondAssignment_1 : ( ruleCondition ) ;
    public final void rule__UntilCondition__CondAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4348:1: ( ( ruleCondition ) )
            // InternalScSl.g:4349:2: ( ruleCondition )
            {
            // InternalScSl.g:4349:2: ( ruleCondition )
            // InternalScSl.g:4350:3: ruleCondition
            {
             before(grammarAccess.getUntilConditionAccess().getCondConditionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getUntilConditionAccess().getCondConditionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UntilCondition__CondAssignment_1"


    // $ANTLR start "rule__MessageAction__MAssignment_1"
    // InternalScSl.g:4359:1: rule__MessageAction__MAssignment_1 : ( RULE_STRING ) ;
    public final void rule__MessageAction__MAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4363:1: ( ( RULE_STRING ) )
            // InternalScSl.g:4364:2: ( RULE_STRING )
            {
            // InternalScSl.g:4364:2: ( RULE_STRING )
            // InternalScSl.g:4365:3: RULE_STRING
            {
             before(grammarAccess.getMessageActionAccess().getMSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getMessageActionAccess().getMSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MessageAction__MAssignment_1"


    // $ANTLR start "rule__SoundAction__NAssignment_1"
    // InternalScSl.g:4374:1: rule__SoundAction__NAssignment_1 : ( RULE_STRING ) ;
    public final void rule__SoundAction__NAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4378:1: ( ( RULE_STRING ) )
            // InternalScSl.g:4379:2: ( RULE_STRING )
            {
            // InternalScSl.g:4379:2: ( RULE_STRING )
            // InternalScSl.g:4380:3: RULE_STRING
            {
             before(grammarAccess.getSoundActionAccess().getNSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getSoundActionAccess().getNSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__NAssignment_1"


    // $ANTLR start "rule__SoundAction__TAssignment_3"
    // InternalScSl.g:4389:1: rule__SoundAction__TAssignment_3 : ( RULE_INT ) ;
    public final void rule__SoundAction__TAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4393:1: ( ( RULE_INT ) )
            // InternalScSl.g:4394:2: ( RULE_INT )
            {
            // InternalScSl.g:4394:2: ( RULE_INT )
            // InternalScSl.g:4395:3: RULE_INT
            {
             before(grammarAccess.getSoundActionAccess().getTINTTerminalRuleCall_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getSoundActionAccess().getTINTTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoundAction__TAssignment_3"


    // $ANTLR start "rule__MarkAction__AAssignment_1"
    // InternalScSl.g:4404:1: rule__MarkAction__AAssignment_1 : ( RULE_INT ) ;
    public final void rule__MarkAction__AAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4408:1: ( ( RULE_INT ) )
            // InternalScSl.g:4409:2: ( RULE_INT )
            {
            // InternalScSl.g:4409:2: ( RULE_INT )
            // InternalScSl.g:4410:3: RULE_INT
            {
             before(grammarAccess.getMarkActionAccess().getAINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getMarkActionAccess().getAINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MarkAction__AAssignment_1"


    // $ANTLR start "rule__ClearAction__AAssignment_1"
    // InternalScSl.g:4419:1: rule__ClearAction__AAssignment_1 : ( RULE_INT ) ;
    public final void rule__ClearAction__AAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4423:1: ( ( RULE_INT ) )
            // InternalScSl.g:4424:2: ( RULE_INT )
            {
            // InternalScSl.g:4424:2: ( RULE_INT )
            // InternalScSl.g:4425:3: RULE_INT
            {
             before(grammarAccess.getClearActionAccess().getAINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getClearActionAccess().getAINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClearAction__AAssignment_1"


    // $ANTLR start "rule__WaitAction__Until_condAssignment"
    // InternalScSl.g:4434:1: rule__WaitAction__Until_condAssignment : ( ruleUntilCondition ) ;
    public final void rule__WaitAction__Until_condAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4438:1: ( ( ruleUntilCondition ) )
            // InternalScSl.g:4439:2: ( ruleUntilCondition )
            {
            // InternalScSl.g:4439:2: ( ruleUntilCondition )
            // InternalScSl.g:4440:3: ruleUntilCondition
            {
             before(grammarAccess.getWaitActionAccess().getUntil_condUntilConditionParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleUntilCondition();

            state._fsp--;

             after(grammarAccess.getWaitActionAccess().getUntil_condUntilConditionParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WaitAction__Until_condAssignment"


    // $ANTLR start "rule__DriveAction__DirectionAssignment_0"
    // InternalScSl.g:4449:1: rule__DriveAction__DirectionAssignment_0 : ( ruleDriveDirection ) ;
    public final void rule__DriveAction__DirectionAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4453:1: ( ( ruleDriveDirection ) )
            // InternalScSl.g:4454:2: ( ruleDriveDirection )
            {
            // InternalScSl.g:4454:2: ( ruleDriveDirection )
            // InternalScSl.g:4455:3: ruleDriveDirection
            {
             before(grammarAccess.getDriveActionAccess().getDirectionDriveDirectionEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleDriveDirection();

            state._fsp--;

             after(grammarAccess.getDriveActionAccess().getDirectionDriveDirectionEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DriveAction__DirectionAssignment_0"


    // $ANTLR start "rule__DriveAction__Until_condAssignment_1"
    // InternalScSl.g:4464:1: rule__DriveAction__Until_condAssignment_1 : ( ruleUntilCondition ) ;
    public final void rule__DriveAction__Until_condAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4468:1: ( ( ruleUntilCondition ) )
            // InternalScSl.g:4469:2: ( ruleUntilCondition )
            {
            // InternalScSl.g:4469:2: ( ruleUntilCondition )
            // InternalScSl.g:4470:3: ruleUntilCondition
            {
             before(grammarAccess.getDriveActionAccess().getUntil_condUntilConditionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleUntilCondition();

            state._fsp--;

             after(grammarAccess.getDriveActionAccess().getUntil_condUntilConditionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DriveAction__Until_condAssignment_1"


    // $ANTLR start "rule__TurnAction__DirectionAssignment_0"
    // InternalScSl.g:4479:1: rule__TurnAction__DirectionAssignment_0 : ( ruleTurnDirection ) ;
    public final void rule__TurnAction__DirectionAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4483:1: ( ( ruleTurnDirection ) )
            // InternalScSl.g:4484:2: ( ruleTurnDirection )
            {
            // InternalScSl.g:4484:2: ( ruleTurnDirection )
            // InternalScSl.g:4485:3: ruleTurnDirection
            {
             before(grammarAccess.getTurnActionAccess().getDirectionTurnDirectionEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleTurnDirection();

            state._fsp--;

             after(grammarAccess.getTurnActionAccess().getDirectionTurnDirectionEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TurnAction__DirectionAssignment_0"


    // $ANTLR start "rule__TurnAction__Until_condAssignment_1"
    // InternalScSl.g:4494:1: rule__TurnAction__Until_condAssignment_1 : ( ruleUntilCondition ) ;
    public final void rule__TurnAction__Until_condAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4498:1: ( ( ruleUntilCondition ) )
            // InternalScSl.g:4499:2: ( ruleUntilCondition )
            {
            // InternalScSl.g:4499:2: ( ruleUntilCondition )
            // InternalScSl.g:4500:3: ruleUntilCondition
            {
             before(grammarAccess.getTurnActionAccess().getUntil_condUntilConditionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleUntilCondition();

            state._fsp--;

             after(grammarAccess.getTurnActionAccess().getUntil_condUntilConditionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TurnAction__Until_condAssignment_1"


    // $ANTLR start "rule__ColorCondition__CAssignment_1"
    // InternalScSl.g:4509:1: rule__ColorCondition__CAssignment_1 : ( ruleColorDetection ) ;
    public final void rule__ColorCondition__CAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4513:1: ( ( ruleColorDetection ) )
            // InternalScSl.g:4514:2: ( ruleColorDetection )
            {
            // InternalScSl.g:4514:2: ( ruleColorDetection )
            // InternalScSl.g:4515:3: ruleColorDetection
            {
             before(grammarAccess.getColorConditionAccess().getCColorDetectionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleColorDetection();

            state._fsp--;

             after(grammarAccess.getColorConditionAccess().getCColorDetectionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorCondition__CAssignment_1"


    // $ANTLR start "rule__ObjectFrontCondition__SAssignment_1"
    // InternalScSl.g:4524:1: rule__ObjectFrontCondition__SAssignment_1 : ( ruleObjectState ) ;
    public final void rule__ObjectFrontCondition__SAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4528:1: ( ( ruleObjectState ) )
            // InternalScSl.g:4529:2: ( ruleObjectState )
            {
            // InternalScSl.g:4529:2: ( ruleObjectState )
            // InternalScSl.g:4530:3: ruleObjectState
            {
             before(grammarAccess.getObjectFrontConditionAccess().getSObjectStateEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleObjectState();

            state._fsp--;

             after(grammarAccess.getObjectFrontConditionAccess().getSObjectStateEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectFrontCondition__SAssignment_1"


    // $ANTLR start "rule__ObjectRightCondition__SAssignment_1"
    // InternalScSl.g:4539:1: rule__ObjectRightCondition__SAssignment_1 : ( ruleObjectState ) ;
    public final void rule__ObjectRightCondition__SAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4543:1: ( ( ruleObjectState ) )
            // InternalScSl.g:4544:2: ( ruleObjectState )
            {
            // InternalScSl.g:4544:2: ( ruleObjectState )
            // InternalScSl.g:4545:3: ruleObjectState
            {
             before(grammarAccess.getObjectRightConditionAccess().getSObjectStateEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleObjectState();

            state._fsp--;

             after(grammarAccess.getObjectRightConditionAccess().getSObjectStateEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectRightCondition__SAssignment_1"


    // $ANTLR start "rule__TimeCondition__TAssignment_1"
    // InternalScSl.g:4554:1: rule__TimeCondition__TAssignment_1 : ( RULE_INT ) ;
    public final void rule__TimeCondition__TAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4558:1: ( ( RULE_INT ) )
            // InternalScSl.g:4559:2: ( RULE_INT )
            {
            // InternalScSl.g:4559:2: ( RULE_INT )
            // InternalScSl.g:4560:3: RULE_INT
            {
             before(grammarAccess.getTimeConditionAccess().getTINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTimeConditionAccess().getTINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeCondition__TAssignment_1"


    // $ANTLR start "rule__AchievementCondition__AAssignment_1"
    // InternalScSl.g:4569:1: rule__AchievementCondition__AAssignment_1 : ( RULE_INT ) ;
    public final void rule__AchievementCondition__AAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4573:1: ( ( RULE_INT ) )
            // InternalScSl.g:4574:2: ( RULE_INT )
            {
            // InternalScSl.g:4574:2: ( RULE_INT )
            // InternalScSl.g:4575:3: RULE_INT
            {
             before(grammarAccess.getAchievementConditionAccess().getAINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getAchievementConditionAccess().getAINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AchievementCondition__AAssignment_1"


    // $ANTLR start "rule__MemoryCondition__CAssignment_0_1"
    // InternalScSl.g:4584:1: rule__MemoryCondition__CAssignment_0_1 : ( ruleColorCondition ) ;
    public final void rule__MemoryCondition__CAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4588:1: ( ( ruleColorCondition ) )
            // InternalScSl.g:4589:2: ( ruleColorCondition )
            {
            // InternalScSl.g:4589:2: ( ruleColorCondition )
            // InternalScSl.g:4590:3: ruleColorCondition
            {
             before(grammarAccess.getMemoryConditionAccess().getCColorConditionParserRuleCall_0_1_0()); 
            pushFollow(FOLLOW_2);
            ruleColorCondition();

            state._fsp--;

             after(grammarAccess.getMemoryConditionAccess().getCColorConditionParserRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__CAssignment_0_1"


    // $ANTLR start "rule__MemoryCondition__CAssignment_1_1"
    // InternalScSl.g:4599:1: rule__MemoryCondition__CAssignment_1_1 : ( ruleObjectFrontCondition ) ;
    public final void rule__MemoryCondition__CAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4603:1: ( ( ruleObjectFrontCondition ) )
            // InternalScSl.g:4604:2: ( ruleObjectFrontCondition )
            {
            // InternalScSl.g:4604:2: ( ruleObjectFrontCondition )
            // InternalScSl.g:4605:3: ruleObjectFrontCondition
            {
             before(grammarAccess.getMemoryConditionAccess().getCObjectFrontConditionParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleObjectFrontCondition();

            state._fsp--;

             after(grammarAccess.getMemoryConditionAccess().getCObjectFrontConditionParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__CAssignment_1_1"


    // $ANTLR start "rule__MemoryCondition__CAssignment_2_1"
    // InternalScSl.g:4614:1: rule__MemoryCondition__CAssignment_2_1 : ( ruleObjectRightCondition ) ;
    public final void rule__MemoryCondition__CAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4618:1: ( ( ruleObjectRightCondition ) )
            // InternalScSl.g:4619:2: ( ruleObjectRightCondition )
            {
            // InternalScSl.g:4619:2: ( ruleObjectRightCondition )
            // InternalScSl.g:4620:3: ruleObjectRightCondition
            {
             before(grammarAccess.getMemoryConditionAccess().getCObjectRightConditionParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleObjectRightCondition();

            state._fsp--;

             after(grammarAccess.getMemoryConditionAccess().getCObjectRightConditionParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MemoryCondition__CAssignment_2_1"


    // $ANTLR start "rule__ColorDetection__SensorAssignment_0"
    // InternalScSl.g:4629:1: rule__ColorDetection__SensorAssignment_0 : ( ruleColorSensor ) ;
    public final void rule__ColorDetection__SensorAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4633:1: ( ( ruleColorSensor ) )
            // InternalScSl.g:4634:2: ( ruleColorSensor )
            {
            // InternalScSl.g:4634:2: ( ruleColorSensor )
            // InternalScSl.g:4635:3: ruleColorSensor
            {
             before(grammarAccess.getColorDetectionAccess().getSensorColorSensorEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleColorSensor();

            state._fsp--;

             after(grammarAccess.getColorDetectionAccess().getSensorColorSensorEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorDetection__SensorAssignment_0"


    // $ANTLR start "rule__ColorDetection__ColorAssignment_1"
    // InternalScSl.g:4644:1: rule__ColorDetection__ColorAssignment_1 : ( ruleColor ) ;
    public final void rule__ColorDetection__ColorAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalScSl.g:4648:1: ( ( ruleColor ) )
            // InternalScSl.g:4649:2: ( ruleColor )
            {
            // InternalScSl.g:4649:2: ( ruleColor )
            // InternalScSl.g:4650:3: ruleColor
            {
             before(grammarAccess.getColorDetectionAccess().getColorColorEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleColor();

            state._fsp--;

             after(grammarAccess.getColorDetectionAccess().getColorColorEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ColorDetection__ColorAssignment_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000020000000002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000004000400000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000007FA00000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000004000400002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0001FD8000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000008000000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000010000000002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0001FC0000000002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x03E0000000004000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x03E0000000004002L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000006000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000086000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000060000L});

}